import os
import sys
import shutil
from dotenv import load_dotenv
load_dotenv()
from docx_to_pdf import convert_docx_to_pdf
from detect_loss_runs import detect_loss_runs
from pdf_to_images import turn_pdf_to_images
from determine_pdf_cutoff import determine_page_cutoffs
from extract import extract_claims
from clean_extraction_output import process_claims_df
from detect_duplicates import detect_duplicate_claims_across_files
from metrics import save_metrics_json, reset_metrics

sys.stdout.reconfigure(encoding='utf-8')

def prepare_excel_csv_files(input_data_dir, output_data_dir, company_names):
    """
    Finds Excel and CSV files in the input_data folder and copies them
    to the output_data folder under excel_sheets/ and csvs/ subfolders
    as expected by the downstream detection and extraction steps.
    """
    for company in company_names:
        company_input_dir = os.path.join(input_data_dir, company)
        if not os.path.isdir(company_input_dir):
            continue
            
        company_output_dir = os.path.join(output_data_dir, company)
        excel_out_dir = os.path.join(company_output_dir, "excel_sheets")
        csv_out_dir = os.path.join(company_output_dir, "csvs")
        
        for root, _, files in os.walk(company_input_dir):
            for file in files:
                file_lower = file.lower()
                src_path = os.path.join(root, file)
                
                if file_lower.endswith((".xls", ".xlsx", ".xlsm", ".xlsb")):
                    os.makedirs(excel_out_dir, exist_ok=True)
                    shutil.copy2(src_path, os.path.join(excel_out_dir, file))
                    print(f"Copied Excel: {file} to output_data")
                elif file_lower.endswith(".csv"):
                    os.makedirs(csv_out_dir, exist_ok=True)
                    shutil.copy2(src_path, os.path.join(csv_out_dir, file))
                    print(f"Copied CSV: {file} to output_data")

import hashlib
import json

def calculate_input_hash(input_dir):
    """
    Computes a single MD5 hash representing all files in the input directory.
    Includes filenames and file contents to ensure uniqueness.
    """
    hasher = hashlib.md5()
    all_files = []
    for root, _, files in os.walk(input_dir):
        for file in files:
            all_files.append(os.path.join(root, file))
    all_files.sort()
    
    if not all_files:
        return "empty"
        
    for file_path in all_files:
        hasher.update(os.path.relpath(file_path, input_dir).encode('utf-8'))
        try:
            with open(file_path, "rb") as f:
                while chunk := f.read(8192):
                    hasher.update(chunk)
        except Exception:
            pass
    return hasher.hexdigest()

def serialize_loss_run_dict(d):
    """Converts tuple keys (company, file) to string keys for JSON serialization."""
    return {f"{k[0]}|||{k[1]}": v for k, v in d.items()}

def deserialize_loss_run_dict(d):
    """Converts string keys back to tuple keys after loading from JSON."""
    result = {}
    for k, v in d.items():
        parts = k.split("|||")
        if len(parts) == 2:
            result[(parts[0], parts[1])] = v
    return result

def main():
    print("MAIN STARTED", flush=True)
    reset_metrics()
    input_data_dir = "input_data"
    output_data_dir = "output_data"
    extraction_data_dir = "extraction_output"
    
    # Configure the folder name under input_data and the output prefix
    company_names = ["sample"]
    file_path_prefix = "sample_"
    
    # Compute input hash for caching pre-processing stages
    input_hash = calculate_input_hash(input_data_dir)
    script_dir = os.path.dirname(os.path.abspath(__file__))
    cache_base_dir = os.path.join(script_dir, "pipeline_cache", input_hash)
    
    is_file_loss_run_dict = {}
    cache_hit = False
    
    if input_hash != "empty":
        cached_output_dir = os.path.join(cache_base_dir, "output_data")
        cached_dict_path = os.path.join(cache_base_dir, "is_file_loss_run.json")
        
        if os.path.exists(cached_output_dir) and os.path.exists(cached_dict_path):
            print(f"[PIPELINE CACHE HIT] Found cached pre-processed data for dataset hash: {input_hash}", flush=True)
            print("[PIPELINE CACHE] Restoring cached OCR, images, and files...", flush=True)
            
            # Restore output_data directory
            if os.path.exists(output_data_dir):
                try:
                    shutil.rmtree(output_data_dir)
                except Exception:
                    pass
            try:
                shutil.copytree(cached_output_dir, output_data_dir)
                
                # Load cached loss run dict
                with open(cached_dict_path, "r", encoding="utf-8") as f:
                    serialized_dict = json.load(f)
                is_file_loss_run_dict = deserialize_loss_run_dict(serialized_dict)
                cache_hit = True
                print("[PIPELINE CACHE] Pre-processed data restored successfully. Bypassing DOCX, PDF conversion, and OCR stages.", flush=True)
            except Exception as e:
                print(f"[PIPELINE CACHE WARN] Failed to restore cache: {e}. Running full pipeline.", flush=True)
                cache_hit = False

    if not cache_hit:
        # 1. Convert Word (.docx) documents to PDF
        print("DOCX CONVERSION STARTED", flush=True)
        convert_docx_to_pdf(input_data_dir, company_names)
        print("DOCX CONVERSION COMPLETED", flush=True)
        
        # 2. Copy raw Excel/CSV files to output folders
        print("EXCEL COPY STARTED", flush=True)
        prepare_excel_csv_files(input_data_dir, output_data_dir, company_names)
        print("EXCEL COPY COMPLETED", flush=True)
        
        # 3. Detect which documents are loss runs
        print("LOSS RUN DETECTION STARTED", flush=True)
        is_file_loss_run_dict = detect_loss_runs(output_data_dir, company_names)
        print("LOSS RUN DETECTION COMPLETED", flush=True)
        
        # 4. Convert PDF pages to image sheets (handles rotation check)
        print("PDF TO IMAGE CONVERSION STARTED", flush=True)
        turn_pdf_to_images(company_names, input_data_dir, output_data_dir, is_file_loss_run_dict)
        print("PDF TO IMAGE CONVERSION COMPLETED", flush=True)
        
        # 4.5 Image to Text OCR
        print("OCR STARTED", flush=True)
        from image_to_text import extract_text_from_images
        extract_text_from_images(company_names, output_data_dir, is_file_loss_run_dict)
        print("OCR COMPLETED", flush=True)
        
        # Save pre-processed outputs to cache for next time
        if input_hash != "empty":
            print(f"[PIPELINE CACHE] Saving pre-processed outputs to cache for hash: {input_hash}...", flush=True)
            try:
                os.makedirs(cache_base_dir, exist_ok=True)
                
                # Cache output_data folder
                cached_output_dir = os.path.join(cache_base_dir, "output_data")
                if os.path.exists(cached_output_dir):
                    try:
                        shutil.rmtree(cached_output_dir)
                    except Exception:
                        pass
                shutil.copytree(output_data_dir, cached_output_dir)
                
                # Cache is_file_loss_run_dict
                serialized_dict = serialize_loss_run_dict(is_file_loss_run_dict)
                with open(cached_dict_path, "w", encoding="utf-8") as f:
                    json.dump(serialized_dict, f, indent=2, ensure_ascii=False)
                    
                print(f"[PIPELINE CACHE] Successfully cached pre-processed outputs for hash: {input_hash}", flush=True)
            except Exception as e:
                print(f"[PIPELINE CACHE WARN] Failed to save pre-processed cache: {e}", flush=True)

    # 5. Calculate page cutoff boundaries
    print("PAGE CUTOFF CALCULATION STARTED", flush=True)
    pages_to_join_dict = determine_page_cutoffs(output_data_dir, company_names, is_file_loss_run_dict)
    print("PAGE CUTOFF CALCULATION COMPLETED", flush=True)
    
    # 6. Extract structured claims JSON
    print("CLAIM EXTRACTION STARTED", flush=True)
    claims_df = extract_claims(output_data_dir, company_names, pages_to_join_dict, is_file_loss_run_dict)
    print("CLAIM EXTRACTION COMPLETED", flush=True)
    
    # 7. Clean and normalize the output DataFrame
    print("CLEANING STARTED", flush=True)
    claims_df = process_claims_df(claims_df)
    print("CLEANING COMPLETED", flush=True)
    
    # 9. Save CSV output
    print("OUTPUT GENERATION STARTED", flush=True)
    os.makedirs(extraction_data_dir, exist_ok=True)
    
    print(f"[CLEANING] Rows before CSV save: {len(claims_df)}", flush=True)

    claims_df.to_csv(f"{extraction_data_dir}/{file_path_prefix}claims.csv", index=False)
    
    # 10. Save metrics JSON
    metrics_output_path = f"{extraction_data_dir}/{file_path_prefix}metrics.json"
    save_metrics_json(metrics_output_path)
    print("OUTPUT GENERATION COMPLETED", flush=True)

if __name__ == "__main__":
    main()
