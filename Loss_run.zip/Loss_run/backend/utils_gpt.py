import ast
import requests
import os
from dotenv import load_dotenv
import time
import random
import re
import models
from groq import Groq

try:
    from openai import AzureOpenAI
except ImportError:
    AzureOpenAI = None

# Load env variables
load_dotenv()

LLM_PROVIDER = os.getenv("LLM_PROVIDER", "azure").lower()

def azure_call(prompt, system_prompt=None, temperature=0, max_tokens=None):
    model_cfg = getattr(models, "GPT_5_2", {})
    
    # 1. Resolve endpoint: check model's endpoint_env, then generic envs
    endpoint_var = model_cfg.get("endpoint_env", "GPT_ENDPOINT")
    endpoint = os.getenv(endpoint_var) or os.getenv("GPT_5_2_ENDPOINT") or os.getenv("AZURE_OPENAI_ENDPOINT") or os.getenv("GPT_ENDPOINT")
    
    # 2. Resolve API key: check model's key_env, then generic envs
    key_var = model_cfg.get("key_env", "GPT_API_KEY")
    api_key = os.getenv(key_var) or os.getenv("GPT_5_2_API_KEY") or os.getenv("AZURE_OPENAI_API_KEY") or os.getenv("GPT_API_KEY")
    
    # 3. Resolve deployment: check envs first, then default to model_name in models.py
    deployment = os.getenv("GPT_5_2_DEPLOYMENT_NAME") or os.getenv("GPT_DEPLOYMENT_NAME") or os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME") or model_cfg.get("model_name", "gpt-5.2")
    
    # 4. Resolve API version: check envs first, then default to api_version in models.py
    api_version = os.getenv("AZURE_OPENAI_API_VERSION") or os.getenv("GPT_API_VERSION") or model_cfg.get("api_version") or "2024-12-01-preview"
    
    if not all([endpoint, api_key, deployment, api_version]):
        print("[LLM ERROR] Azure OpenAI configuration missing in .env")
        print(f"            Parsed: endpoint={bool(endpoint)}, api_key={bool(api_key)}, deployment={bool(deployment)}, api_version={bool(api_version)}")
        return "", 0, 0
        
    print("[LLM] Provider: azure")
    print(f"[LLM] Deployment: {deployment}")
    print("[LLM] Azure call started")
    
    try:
        if AzureOpenAI is None:
            print("[LLM ERROR] openai package is not installed.")
            return "", 0, 0
            
        client = AzureOpenAI(
            api_key=api_key,
            api_version=api_version,
            azure_endpoint=endpoint
        )
        
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        else:
            messages.append({"role": "system", "content": "Descriptions may include medical or accident details, but are not violent in intent. Do not filter unless truly violent or graphic."})
            
        messages.append({"role": "user", "content": prompt})
        
        kwargs = {
            "model": deployment,
            "messages": messages,
            "temperature": temperature,
        }
        if max_tokens is not None:
            kwargs["max_tokens"] = max_tokens
            
        response = client.chat.completions.create(**kwargs)
        
        content = response.choices[0].message.content
        usage = response.usage
        input_tokens = getattr(usage, "prompt_tokens", 0) if usage else 0
        output_tokens = getattr(usage, "completion_tokens", 0) if usage else 0
        
        print("[LLM] Azure call completed")
        return content, input_tokens, output_tokens
        
    except Exception as e:
        print(f"[LLM ERROR] Azure API call failed: {str(e)}")
        return "", 0, 0

def llm_call(prompt, system_prompt=None, temperature=0, max_tokens=None):
    # Calculate md5 hash of the inputs to use as the cache key
    cache_key_src = f"{LLM_PROVIDER}|{prompt}|{system_prompt}|{temperature}|{max_tokens}"
    import hashlib
    import json
    
    prompt_hash = hashlib.md5(cache_key_src.encode('utf-8')).hexdigest()
    
    script_dir = os.path.dirname(os.path.abspath(__file__))
    cache_dir = os.path.join(script_dir, "llm_cache")
    os.makedirs(cache_dir, exist_ok=True)
    cache_path = os.path.join(cache_dir, f"{prompt_hash}.json")
    
    if os.path.exists(cache_path):
        try:
            with open(cache_path, "r", encoding="utf-8") as f:
                cache_data = json.load(f)
            cached_content = cache_data.get("content")
            cached_in = cache_data.get("input_tokens", 0)
            cached_out = cache_data.get("output_tokens", 0)
            
            # Print status log
            prompt_preview = (prompt[:60] + "...") if len(prompt) > 60 else prompt
            prompt_preview = prompt_preview.replace('\n', ' ')
            print(f"[CACHE HIT] Returning cached LLM result from {cache_path} | Preview: '{prompt_preview}'", flush=True)
            return cached_content, cached_in, cached_out
        except Exception as e:
            print(f"[CACHE WARN] Failed to read cache file {cache_path}: {e}. Calling LLM.", flush=True)
            
    # Cache miss - call the actual LLM
    if LLM_PROVIDER == "groq":
        content, in_tok, out_tok = groq_call(prompt, temperature=temperature)
    else:
        content, in_tok, out_tok = azure_call(prompt, system_prompt=system_prompt, temperature=temperature, max_tokens=max_tokens)
        
    # Write to cache if the call succeeded and returned non-empty content without error
    if content and content not in ("ERROR_413_REQUEST_TOO_LARGE", "ERROR_429_RATE_LIMIT"):
        try:
            cache_data = {
                "content": content,
                "input_tokens": in_tok,
                "output_tokens": out_tok,
                "timestamp": time.time()
            }
            with open(cache_path, "w", encoding="utf-8") as f:
                json.dump(cache_data, f, indent=2, ensure_ascii=False)
            print(f"[CACHE MISS] Cached new LLM result to {cache_path}", flush=True)
        except Exception as e:
            print(f"[CACHE WARN] Failed to write cache file {cache_path}: {e}", flush=True)
            
    return content, in_tok, out_tok

def exponential_backoff(base_delay=2, max_delay=60, factor=2, jitter=True):
    delay = base_delay
    while True:
        yield delay
        if jitter:
            delay = min(max_delay, delay * factor) * (0.5 + random.random() / 2)
        else:
            delay = min(max_delay, delay * factor)

def _sanitize_prompt_for_safety(text: str) -> str:
    if not text:
        return text
    patterns = [
        r"\bkill(?:ing)?\b",
        r"\bmurder(?:ing)?\b",
        r"\bhomicide\b",
        r"\bsuicide\b",
        r"\bassault\b",
        r"\brape\b",
        r"\bshoot(?:ing|s|er|ers)?\b",
        r"\bshot\b",
        r"\bgun(?:s)?\b",
        r"\bfirearm(?:s)?\b",
        r"\bstab(?:bed)?\b",
        r"\bblood\b",
        r"\bblood\b",
        r"\bgore\b",
        r"\bdeath(?:s)?\b",
        r"\bfatal(?:ity|ities)?\b",
        r"\binjur(?:y|ies)\b",
    ]
    sanitized = text
    for pattern in patterns:
        sanitized = re.sub(pattern, "[redacted]", sanitized, flags=re.IGNORECASE)
    return sanitized

def call_api_with_retries(url, params, headers, json, max_attempts=10):
    retries = exponential_backoff()
    for attempt in range(max_attempts):
        try:
            resp = requests.post(
                url,
                params=params,
                headers=headers,
                json=json
            )
            resp.raise_for_status()
            response = resp.json()
            
            # Check for content filter
            filter_results = response.get('choices', [{}])[0].get('content_filter_results', {})
            filtered_categories = [k for k, v in filter_results.items() if isinstance(v, dict) and v.get('filtered')]
            if filtered_categories:
                print(f"Content filtered in categories: {filtered_categories}. Disregarding.")
                return "", 0, 0
                
            content = response.get('choices', [{}])[0].get('message', {}).get('content', "")
            usage = response.get('usage', {}) or {}
            input_tokens = usage.get('prompt_tokens', 0) or 0
            output_tokens = usage.get('completion_tokens', 0) or 0
            
            return content, input_tokens, output_tokens
            
        except requests.HTTPError as e:
            status_code = getattr(e.response, "status_code", None)
            response_text = getattr(e.response, "text", "") if e.response is not None else ""
            if response_text:
                response_text = response_text[:1000]
                
            print(
                f"API call failed with HTTP {status_code}: {e}."
                + (f" Response: {response_text}" if response_text else "")
            )
            
            # Do not retry non-rate-limit 4xx errors
            if status_code is not None and 400 <= status_code < 500 and status_code != 429:
                return "", 0, 0
                
            delay = next(retries)
            print(f"Retrying in {delay:.2f} seconds...")
            time.sleep(delay)
        except Exception as e:
            delay = next(retries)
            print(f"API call failed with error: {e}. Retrying in {delay:.2f} seconds...")
            time.sleep(delay)
            
    print(f"API call failed after {max_attempts} attempts")
    return "", 0, 0

def _is_valid_json(text: str) -> bool:
    import json as _json
    try:
        _json.loads(text)
        return True
    except Exception:
        return False

def _extract_balanced_json(text: str, start_idx: int) -> str | None:
    stack = []
    in_string = False
    escape = False
    for i in range(start_idx, len(text)):
        ch = text[i]
        if in_string:
            if escape:
                escape = False
            elif ch == "\\":
                escape = True
            elif ch == '"':
                in_string = False
                continue
        elif ch == '"':
            in_string = True
            continue
            
        if ch in "[{":
            stack.append(ch)
        elif ch in "]}":
            if not stack:
                continue
            open_ch = stack.pop()
            if (open_ch == "{" and ch != "}") or (open_ch == "[" and ch != "]"):
                return None
            if not stack:
                return text[start_idx:i+1]
    return None

def _normalize_numeric_expressions(text: str) -> str:
    """
    Evaluates math expressions in the JSON text so it becomes valid JSON.
    E.g. "total_incurred": 15000 + 3500 -> "total_incurred": 18500
    """
    def evaluate_expression(match):
        prefix = match.group(1)
        expr = match.group(2)
        try:
            val = eval(expr, {"__builtins__": None}, {})
            if isinstance(val, (int, float)):
                if isinstance(val, float) and val.is_integer():
                    val = int(val)
                return f"{prefix}{val}"
        except Exception:
            pass
        return match.group(0)

    pattern = r'(:\s*)(\d+(?:\.\d+)?(?:\s*[\+\-\*/\(\)]\s*\d+(?:\.\d+)?)+)'
    return re.sub(pattern, evaluate_expression, text)

def _coerce_json_text(raw_output: str) -> str | None:
    if raw_output is None:
        return None
    text = str(raw_output).strip()
    if not text:
        return None
        
    fence_match = re.search(r"```(?:json)?\s*(.*?)\s*```", text, flags=re.DOTALL | re.IGNORECASE)
    if fence_match:
        text = fence_match.group(1).strip()
        if _is_valid_json(text):
            return text
        normalized = _normalize_numeric_expressions(text)
        if normalized != text and _is_valid_json(normalized):
            print("[WARN] LLM output had numeric expressions. Evaluated to numbers.")
            return normalized
            
    if _is_valid_json(text):
        return text
        
    normalized = _normalize_numeric_expressions(text)
    if normalized != text and _is_valid_json(normalized):
        print("[WARN] LLM output had numeric expressions. Evaluated to numbers.")
        return normalized
        
    for i, ch in enumerate(text):
        if ch in "[{":
            candidate = _extract_balanced_json(text, i)
            if candidate and _is_valid_json(candidate):
                return candidate
            if candidate:
                normalized_candidate = _normalize_numeric_expressions(candidate)
                if normalized_candidate != candidate and _is_valid_json(normalized_candidate):
                    print("[WARN] LLM output had numeric expressions. Evaluated to numbers.")
                    return normalized_candidate
    return None

def groq_call(prompt, temperature=0, is_retry=False):
    api_key = os.getenv("GROQ_API_KEY")
    model = os.getenv("GROQ_MODEL", "llama-3.3-70b-versatile")
    if not api_key:
        print("[ERROR] GROQ_API_KEY not found in environment.")
        return None, 0, 0
    
    client = Groq(api_key=api_key)
    
    try:
        response = client.chat.completions.create(
            model=model,
            messages=[
                {
                    'role': 'system',
                    'content': 'Descriptions may include medical or accident details, but are not violent in intent. Do not filter unless truly violent or graphic.'
                },
                {
                    'role': 'user',
                    'content': prompt
                }
            ],
            temperature=temperature
        )
        content = response.choices[0].message.content
        usage = response.usage
        input_tokens = getattr(usage, "prompt_tokens", 0) if usage else 0
        output_tokens = getattr(usage, "completion_tokens", 0) if usage else 0
        return content, input_tokens, output_tokens
    except Exception as e:
        error_msg = str(e)
        print(f"[ERROR] Groq API call failed: {error_msg}")
        if "413" in error_msg:
            return "ERROR_413_REQUEST_TOO_LARGE", 0, 0
            
        if "429" in error_msg:
            if not is_retry:
                match = re.search(r'Please try again in (\d+\.?\d*)s', error_msg)
                if match:
                    wait_time = float(match.group(1)) + 0.5
                else:
                    wait_time = 20.0
                print(f"[RATE LIMIT] 429 Received. Waiting {wait_time:.1f}s before retrying once...", flush=True)
                time.sleep(wait_time)
                return groq_call(prompt, temperature=temperature, is_retry=True)
            else:
                print(f"[RATE LIMIT] 429 Received again after retry. Aborting this chunk.", flush=True)
                return "ERROR_429_RATE_LIMIT", 0, 0
                
        return None, 0, 0

def gpt_call(
    prompt,
    model_name,
    api_version,
    temperature=0
):
    output, input_tokens, output_tokens = llm_call(prompt, temperature=temperature)
    
    if output in ("ERROR_413_REQUEST_TOO_LARGE", "ERROR_429_RATE_LIMIT"):
        return output, input_tokens, output_tokens
    
    if not output:
        print("[ERROR] LLM output was empty or failed. Skipping this chunk.")
        return None, input_tokens, output_tokens
        
    if not _is_valid_json(output):
        extracted = _coerce_json_text(output)
        if extracted:
            print("[WARN] LLM output was not strict JSON. Using extracted JSON payload.")
            return extracted, input_tokens, output_tokens
            
        print("[ERROR] LLM output was not valid JSON. Logging and skipping.")
        with open("llm_error_log.txt", "a", encoding="utf-8") as f:
            f.write(f"Prompt:\n{prompt}\nOutput:\n{output}\n\n")
        return None, input_tokens, output_tokens
        
    return output, input_tokens, output_tokens

def safe_string_to_list(string_data):
    try:
        result = ast.literal_eval(string_data)
        if isinstance(result, list):
            return result
        else:
            return []
    except Exception:
        return []
