import pandas as pd
import re
import string
import warnings
from extract import CLAIM_LEVEL_VALID_JSON_FIELDS, NO_CLAIMS_VALID_JSON_FIELDS

US_STATES_MAP = {
    # basic mapping; extend as needed
    "AL": "AL", "ALABAMA": "AL",
    "AK": "AK", "ALASKA": "AK",
    "AZ": "AZ", "ARIZONA": "AZ",
    "AR": "AR", "ARKANSAS": "AR",
    "CA": "CA", "CALIFORNIA": "CA",
    "CO": "CO", "COLORADO": "CO",
    "CT": "CT", "CONNECTICUT": "CT",
    "DE": "DE", "DELAWARE": "DE",
    "FL": "FL", "FLORIDA": "FL",
    "GA": "GA", "GEORGIA": "GA",
    "HI": "HI", "HAWAII": "HI",
    "ID": "ID", "IDAHO": "ID",
    "IL": "IL", "ILLINOIS": "IL",
    "IN": "IN", "INDIANA": "IN",
    "IA": "IA", "IOWA": "IA",
    "KS": "KS", "KANSAS": "KS",
    "KY": "KY", "KENTUCKY": "KY",
    "LA": "LA", "LOUISIANA": "LA",
    "ME": "ME", "MAINE": "ME",
    "MD": "MD", "MARYLAND": "MD",
    "MA": "MA", "MASSACHUSETTS": "MA",
    "MI": "MI", "MICHIGAN": "MI",
    "MN": "MN", "MINNESOTA": "MN",
    "MS": "MS", "MISSISSIPPI": "MS",
    "MO": "MO", "MISSOURI": "MO",
    "MT": "MT", "MONTANA": "MT",
    "NE": "NE", "NEBRASKA": "NE",
    "NV": "NV", "NEVADA": "NV",
    "NH": "NH", "NEW HAMPSHIRE": "NH",
    "NJ": "NJ", "NEW JERSEY": "NJ",
    "NM": "NM", "NEW MEXICO": "NM",
    "NY": "NY", "NEW YORK": "NY",
    "NC": "NC", "NORTH CAROLINA": "NC",
    "ND": "ND", "NORTH DAKOTA": "ND",
    "OH": "OH", "OHIO": "OH",
    "OK": "OK", "OKLAHOMA": "OK",
    "OR": "OR", "OREGON": "OR",
    "PA": "PA", "PENNSYLVANIA": "PA",
    "RI": "RI", "RHODE ISLAND": "RI",
    "SC": "SC", "SOUTH CAROLINA": "SC",
    "SD": "SD", "SOUTH DAKOTA": "SD",
    "TN": "TN", "TENNESSEE": "IN",
    "TX": "TX", "TEXAS": "TX",
    "UT": "UT", "UTAH": "UT",
    "VT": "VT", "VERMONT": "VT",
    "VA": "VA", "VIRGINIA": "VA",
    "WA": "WA", "WASHINGTON": "WA",
    "WV": "WV", "WEST VIRGINIA": "WV",
    "WI": "WI", "WISCONSIN": "WI",
    "WY": "WY", "WYOMING": "WY"
}

def _clean_date_str(s: pd.Series) -> pd.Series:
    """Convert anything parseable to MM/DD/YYYY as string; else NaN."""
    def _parse(v):
        if pd.isna(v):
            return pd.NA
        try:
            dt = pd.to_datetime(str(v), errors="raise")
            return dt.strftime("%m/%d/%Y")
        except Exception:
            return pd.NA
    return s.apply(_parse)

def normalize_lob(row):
    valid_lobs = {
        "auto": "Auto",
        "workers compensation": "Workers Compensation",
        "general liability": "General Liability",
        "property": "Property"
    }
    
    # 1. Use explicit line_of_business/lob if valid and not unknown.
    lob_candidates = []
    if "lob" in row and pd.notna(row["lob"]):
        lob_candidates.append(str(row["lob"]))
    if "line_of_business" in row and pd.notna(row["line_of_business"]):
        lob_candidates.append(str(row["line_of_business"]))
        
    for val in lob_candidates:
        val_lower = val.lower().strip()
        if val_lower in valid_lobs:
            return valid_lobs[val_lower]
            
    # 2. Infer from Business Unit
    bu_candidates = []
    for col in row.index:
        if col.lower() in ["business_unit", "business unit", "bu"]:
            if pd.notna(row[col]):
                bu_candidates.append(str(row[col]))
        
    for val in bu_candidates:
        val_lower = val.lower()
        if any(x in val_lower for x in ["workers compensation", "workers’ compensation", "work comp", "wc"]):
            return "Workers Compensation"
        if "auto" in val_lower:
            return "Auto"
        if "general liability" in val_lower or "gl" in val_lower.split():
            return "General Liability"
        if "property" in val_lower:
            return "Property"

    # 3. Infer from Coverage / Coverage Subtype / Policy Type / Line Type
    cov_candidates = []
    for col in row.index:
        if col.lower() in ["coverage", "coverage_subtype", "policy_type", "line_type", "coverage type", "policy type"]:
            if pd.notna(row[col]):
                cov_candidates.append(str(row[col]))
            
    for val in cov_candidates:
        val_lower = val.lower()
        words = val_lower.split()
        if "gl" in words or "general liability" in val_lower:
            return "General Liability"
        if any(x in val_lower for x in ["auto", "al", "vehicle", "truck", "trailer"]):
            return "Auto"
        if "property" in val_lower:
            return "Property"
        if "wc" in words or "workers compensation" in val_lower or "work comp" in val_lower:
            return "Workers Compensation"
            
    # 4. Infer from claim_description / body_part / cause
    desc_candidates = []
    for col in row.index:
        if col.lower() in ["claim_description", "body_part", "cause", "description", "loss description", "nature of injury", "part of body"]:
            if pd.notna(row[col]):
                desc_candidates.append(str(row[col]))
            
    for val in desc_candidates:
        val_lower = val.lower()
        if any(x in val_lower for x in ["vehicle", "truck", "trailer", "driver", "collision", "bumper", "tire"]):
            return "Auto"
        if any(x in val_lower for x in ["injury", "body part", "employee", "workplace", "strain", "fall", "bodily reaction", "material handling", "cut", "bruise", "fracture", "burn", "sprain", "dislocation"]):
            return "Workers Compensation"
        if any(x in val_lower for x in ["property", "building", "fire", "water", "wind"]):
            return "Property"

    # 4.5. Explicit fallback for Part of Body presence
    for col in row.index:
        if col.lower() == "part of body":
            if pd.notna(row[col]) and str(row[col]).strip() != "":
                return "Workers Compensation"

    # 5. Fallback
    return "Unknown"

def _to_str_strip(s: pd.Series) -> pd.Series:
    return s.astype("string").str.strip()

def _clean_id_str(s: pd.Series) -> pd.Series:
    """Policy/claim numbers as string; drop trailing .0 from floats."""
    def _conv(v):
        if pd.isna(v):
            return pd.NA
        txt = str(v).strip()
        # handle float-like "1234.0"
        if re.fullmatch(r"^\d+\.0", txt):
            return txt[:-2]
        return txt
    return s.apply(_conv).astype("string")

def _to_float_with_default(s: pd.Series, default: float = 0.0) -> pd.Series:
    out = pd.to_numeric(s, errors="coerce")
    out = out.fillna(default)
    return out.astype(float)

def _clean_status(s: pd.Series) -> pd.Series:
    mapping = {"o": "O", "open": "O",
               "c": "C", "closed": "C",
               "r": "R", "reopen": "R", "re-open": "R", "reopened": "R"}
    def _norm(v):
        if pd.isna(v):
            return pd.NA
        txt = str(v).strip().lower()
        return mapping.get(txt, pd.NA)
    return s.apply(_norm)

def _clean_state_col(s: pd.Series) -> pd.Series:
    def _norm(v):
        if pd.isna(v):
            return pd.NA
        txt = str(v).strip().upper()
        txt = re.sub(r"[^A-Z ]", "", txt)
        txt = re.sub(r"\s+", " ", txt).strip()
        return US_STATES_MAP.get(txt, pd.NA)
    return s.apply(_norm)

def _count_changes(before: pd.Series, after: pd.Series) -> int:
    """Count number of rows where value actually changed (ignoring NaN==NaN)."""
    b = before.reset_index(drop=True)
    a = after.reset_index(drop=True)
    # equal if both NaN
    both_nan = b.isna() & a.isna()
    # equal if exactly same (and not both NaN already counted)
    same = (b == a) | both_nan
    return (~same).sum()

def _print_if_changes(changed: int, msg: str) -> None:
    if changed > 0:
        print(msg)

def process_claims_df(claims_df: pd.DataFrame) -> pd.DataFrame:
    df = claims_df.copy()
    
    rows_before = len(df)
    print(f"[CLEANING] Rows before cleaning: {rows_before}")
    
    # Standardize/rename key columns first so they are consistent across VLM, Excel, and Fallback
    rename_map = {}
    if "accident_date" in df.columns:
        if "loss_date" not in df.columns:
            rename_map["accident_date"] = "loss_date"
        else:
            df["loss_date"] = df["loss_date"].fillna(df["accident_date"])
            df.drop(columns=["accident_date"], inplace=True)
            
    if "source_page" in df.columns:
        if "page_num_or_sheet_name" not in df.columns:
            rename_map["source_page"] = "page_num_or_sheet_name"
        else:
            df["page_num_or_sheet_name"] = df["page_num_or_sheet_name"].fillna(df["source_page"])
            df.drop(columns=["source_page"], inplace=True)
            
    if "claim_number" in df.columns:
        if "claim_id" not in df.columns:
            rename_map["claim_number"] = "claim_id"
        else:
            df["claim_id"] = df["claim_id"].fillna(df["claim_number"])
            df.drop(columns=["claim_number"], inplace=True)
            
    if rename_map:
        df.rename(columns=rename_map, inplace=True)
        
    # If loss_date is present, fill any missing values using report_date as a fallback (especially for Workers Comp PDF fallback)
    if "loss_date" in df.columns and "report_date" in df.columns:
        df["loss_date"] = df["loss_date"].fillna(df["report_date"])
        
    # Ensure standard financial columns exist and are numeric
    for col in ["total_paid", "total_reserve", "total_incurred"]:
        if col not in df.columns:
            df[col] = 0.0
        else:
            df[col] = pd.to_numeric(df[col], errors='coerce').fillna(0.0)
            
    # Derive missing/zero reserve and incurred values
    if "total_reserve" in df.columns and "total_incurred" in df.columns and "total_paid" in df.columns:
        mask_reserve_zero = (df["total_reserve"] == 0.0) & (df["total_incurred"] > 0.0)
        if mask_reserve_zero.any():
            df.loc[mask_reserve_zero, "total_reserve"] = (df.loc[mask_reserve_zero, "total_incurred"] - df.loc[mask_reserve_zero, "total_paid"]).clip(lower=0.0)
            
        mask_incurred_zero = (df["total_incurred"] == 0.0) & ((df["total_paid"] > 0.0) | (df["total_reserve"] > 0.0))
        if mask_incurred_zero.any():
            df.loc[mask_incurred_zero, "total_incurred"] = df.loc[mask_incurred_zero, "total_paid"] + df.loc[mask_incurred_zero, "total_reserve"]
    
    # Log all claim numbers before cleaning
    claim_numbers_before = set()
    for col in ["claim_number", "claim_id"]:
        if col in df.columns:
            claim_numbers_before.update(df[col].dropna().astype(str).str.strip())

    # --- identify rows that are "empty" other than AccountName / file_path ---
    def has_id(row):
        for col in ["claim_id", "claim_number"]:
            if col in row and str(row[col]).strip() not in ["", "nan", "None"]:
                return True
        return False
        
    # Mark validation warnings instead of dropping
    mask_has_id = df.apply(has_id, axis=1)
    if "validation_warnings" not in df.columns:
        df["validation_warnings"] = ""
        
    missing_id_mask = ~mask_has_id
    if missing_id_mask.any():
        df.loc[missing_id_mask, "validation_warnings"] = df.loc[missing_id_mask, "validation_warnings"].astype(str) + "Missing Claim ID; "
        print(f"[CLEANING] Warning: {missing_id_mask.sum()} rows are missing a valid claim ID, but they have been retained.")

    # --- Dates: "MM/DD/YYYY" as string ---
    date_cols = [
        "policy_effective_date",
        "policy_expiration_date",
        "evaluation_date",
        "accident_date",
        "loss_date",
        "report_date",
    ]
    for col in date_cols:
        if col in df.columns:
            before = df[col].copy()
            df[col] = _clean_date_str(df[col]).astype("string")
            changed = _count_changes(before, df[col])
            _print_if_changes(changed, f"        Date cleaning: changed {changed} rows in '{col}'")

    # --- LOB Normalization ---
    print(f"[LOB NORMALIZATION] Applying priority normalization...")
    
    lob_candidates_exist = any(col in df.columns for col in ["line_of_business", "lob"])
    if lob_candidates_exist:
        input_col = "lob" if "lob" in df.columns else "line_of_business"
        unique_before = df[input_col].dropna().unique().tolist()
        print(f"[LOB NORMALIZATION] Input unique values: {unique_before}")
    else:
        print(f"[LOB NORMALIZATION] Input unique values: [] (no explicit LOB column)")

    df["lob"] = df.apply(normalize_lob, axis=1)
    
    unique_after = df["lob"].unique().tolist()
    unknown_count = (df["lob"] == "Unknown").sum()
    print(f"[LOB NORMALIZATION] Output unique values: {unique_after}")
    print(f"[LOB NORMALIZATION] Unknown rows after normalization: {unknown_count}")
    
    if "line_of_business" in df.columns and "line_of_business" != "lob":
        df.drop(columns=["line_of_business"], inplace=True)

    # --- prior_carrier as string ---
    if "prior_carrier" in df.columns:
        before = df["prior_carrier"].copy()
        df["prior_carrier"] = _to_str_strip(df["prior_carrier"])
        changed = _count_changes(before, df["prior_carrier"])
        _print_if_changes(changed, f"        Prior carrier cleaning: changed {changed} rows in 'prior_carrier'")

    # --- policy_number and claim_number as strings with .0 removed ---
    if "policy_number" in df.columns:
        before = df["policy_number"].copy()
        df["policy_number"] = _clean_id_str(df["policy_number"])
        changed = _count_changes(before, df["policy_number"])
        _print_if_changes(changed, f"        ID cleaning: changed {changed} rows in 'policy_number'")

    if "claim_id" in df.columns:
        before = df["claim_id"].copy()
        df["claim_id"] = _clean_id_str(df["claim_id"])
        changed = _count_changes(before, df["claim_id"])
        _print_if_changes(changed, f"        ID cleaning: changed {changed} rows in 'claim_id'")

        if "policy_number" in df.columns:
            eq_mask = df["claim_id"].notna() & df["policy_number"].notna() & (df["claim_id"] == df["policy_number"])
            if eq_mask.any():
                df.loc[eq_mask, "claim_id"] = pd.NA
                _print_if_changes(int(eq_mask.sum()), f"        Claim ID sanity: nullified {eq_mask.sum()} rows where claim_id == policy_number")

    if "claim_number" in df.columns:
        before = df["claim_number"].copy()
        df["claim_number"] = _clean_id_str(df["claim_number"])
        changed = _count_changes(before, df["claim_number"])
        _print_if_changes(changed, f"        ID cleaning: changed {changed} rows in 'claim_number'")

    # --- subline as string; for auto, only "AL" or "APD" ---
    if "subline" in df.columns:
        before_all = df["subline"].copy()
        df["subline"] = _to_str_strip(df["subline"])
        after_strip = df["subline"].copy()
        changed_strip = _count_changes(before_all.astype("string"), after_strip)
        _print_if_changes(changed_strip, f"        Subline cleaning (strip): changed {changed_strip} rows in 'subline'")

        if "lob" in df.columns:
            is_auto = df["lob"].eq("Auto")

            def _auto_subline(v):
                if pd.isna(v):
                    return pd.NA
                txt = str(v).strip().upper()
                if txt in ("AL", "AUTO LIABILITY"):
                    return "AL"
                if txt in ("APD", "AUTO PHYSICAL DAMAGE", "PD"):
                    return "APD"
                return pd.NA # anything else becomes NaN

            before_auto = df.loc[is_auto, "subline"].copy()
            df.loc[is_auto, "subline"] = df.loc[is_auto, "subline"].apply(_auto_subline).astype("string")
            after_auto = df.loc[is_auto, "subline"]
            changed_auto = _count_changes(before_auto, after_auto)
            _print_if_changes(changed_auto, f"              Subline cleaning (auto-only): changed {changed_auto} rows in 'subline' for auto LOB")

    # --- Financials as float with default 0.0 ---
    float_cols = [
        "total_incurred",
        "total_paid",
        "incurred_alae",
        "paid_alae",
        "total_recoveries",
    ]
    for col in float_cols:
        if col in df.columns:
            before = df[col].copy()
            df[col] = _to_float_with_default(df[col], 0.0)
            # compare as strings to avoid float precision noise
            changed = _count_changes(before.astype("string"), df[col].astype("string"))
            _print_if_changes(changed, f"        Financial cleaning: changed {changed} rows in '{col}'")

    # --- status: "O", "C", or "R" ---
    if "status" in df.columns:
        before = df["status"].copy()
        df["status"] = _clean_status(df["status"]).astype("string")
        changed = _count_changes(before.astype("string"), df["status"])
        _print_if_changes(changed, f"        Status cleaning: changed {changed} rows in 'status'")

    # --- claimant, driver, description as string ---
    for col in ["claimant", "driver", "description"]:
        if col in df.columns:
            before = df[col].copy()
            df[col] = _to_str_strip(df[col])
            changed = _count_changes(before.astype("string"), df[col])
            _print_if_changes(changed, f"        Text cleaning: changed {changed} rows in '{col}'")

    # --- state columns: 2-letter codes ---
    for col in ["accident_state", "garage_state", "coverage_state"]:
        if col in df.columns:
            before = df[col].copy()
            df[col] = _clean_state_col(df[col]).astype("string")
            changed = _count_changes(before.astype("string"), df[col])
            _print_if_changes(changed, f"        State cleaning: changed {changed} rows in '{col}'")

    # --- garage_state and driver NaN if not auto ---
    if "line_of_business" in df.columns:
        not_auto = ~df["line_of_business"].eq("auto")

        if "garage_state" in df.columns:
            before = df["garage_state"].copy()
            df.loc[not_auto, "garage_state"] = pd.NA
            changed = _count_changes(before.astype("string"), df["garage_state"])
            _print_if_changes(changed, f"              Non-auto adjustment: changed {changed} rows in 'garage_state'")

        if "driver" in df.columns:
            before = df["driver"].copy()
            df.loc[not_auto, "driver"] = pd.NA
            changed = _count_changes(before.astype("string"), df["driver"])
            _print_if_changes(changed, f"              Non-auto adjustment: changed {changed} rows in 'driver'")

    # --- coverage_state NaN if not general liability ---
    if "line_of_business" in df.columns and "coverage_state" in df.columns:
        not_gl = ~df["line_of_business"].eq("general liability")
        before = df["coverage_state"].copy()
        df.loc[not_gl, "coverage_state"] = pd.NA
        changed = _count_changes(before.astype("string"), df["coverage_state"])
        _print_if_changes(changed, f"              Non-GL adjustment: changed {changed} rows in 'coverage_state'")

    # Log all claim numbers after cleaning (exclude rows with no IDs)
    with warnings.catch_warnings():
        warnings.filterwarnings(
            "ignore",
            category=FutureWarning,
            message="The behavior of DataFrame concatenation with empty or all-NA entries is deprecated",
        )
        def _normalize_for_diff(val):
            if pd.isna(val):
                return None
            s = str(val).strip()
            if re.fullmatch(r"^\d+\.0+", s):
                s = s.split(".")[0]
            s = s.replace(" ", "")
            return re.sub(r"[^A-Za-z0-9]", "", s).lower() or None

        claim_numbers_after = set()
        for col in ["claim_number", "claim_id"]:
            if col in df.columns:
                claim_numbers_after.update(df[col].dropna().astype(str).str.strip())

        norm_before = {_normalize_for_diff(v) for v in claim_numbers_before if _normalize_for_diff(v)}
        norm_after = {_normalize_for_diff(v) for v in claim_numbers_after if _normalize_for_diff(v)}
        missing_norm = norm_before - norm_after
        if missing_norm:
            raw_lookup = {}
            for raw in claim_numbers_before:
                n = _normalize_for_diff(raw)
                if n:
                    raw_lookup.setdefault(n, set()).add(str(raw).strip())
            missing_raw = sorted({item for n in missing_norm for item in raw_lookup.get(n, (n,))})
            print(f"[CLEANING] Dropped claim numbers during cleaning (IDs scrubbed, rows retained): {missing_raw}")

    # If any processed file in the batch is a PDF, rearrange and standardize columns into a premium schema
    is_pdf = False
    if "file_path" in df.columns:
        is_pdf = df["file_path"].dropna().astype(str).str.lower().str.endswith(".pdf").any()
        
    if is_pdf:
        print("[CLEANING] PDF detected. Rearranging and standardizing columns to the premium schema.")
        standard_cols = [
            'claim_id', 'claimant', 'policy_number', 'policy_effective_date', 'policy_expiration_date',
            'lob', 'subline', 'loss_date', 'report_date', 'accident_state',
            'driver', 'garage_state', 'coverage_state', 'claim_description', 'total_paid',
            'total_reserve', 'total_incurred', 'incurred_alae', 'paid_alae', 'total_recoveries',
            'status', 'prior_carrier', 'evaluation_date', 'page_num_or_sheet_name', 'extractionMode',
            'validation_warnings', 'AccountName', 'file_path'
        ]
        
        # Add any missing standard columns as nulls
        for col in standard_cols:
            if col not in df.columns:
                df[col] = pd.NA
                
        # Reorder columns to exactly match the standard list
        df = df[standard_cols]

    rows_after = len(df)
    print(f"[CLEANING] Rows after cleaning: {rows_after} (Dropped: {rows_before - rows_after})")

    return df

def process_claim_free_policies_df(no_claims_df):
    return no_claims_df
    # Convert None to NaN for all columns
    no_claims_df = no_claims_df.where(pd.notnull(no_claims_df), None).replace({None: pd.NA})

    # # Drop rows where all columns except 'AccountName' and 'file_path' are NaN (no policy in the given input)
    # before = len(no_claims_df)
    # no_claims_df = no_claims_df.dropna(
    #     subset=[col for col in no_claims_df.columns if col not in ['AccountName', 'file_path']],
    #     how='all'
    # )
    # print(f"            \n            Dropped {before - len(no_claims_df)} rows with all NaN except AccountName/file_path")

    # # If empty, return an empty DataFrame with expected columns
    # if no_claims_df.empty:
    #     expected_cols = ['AccountName'] + [col for col in NO_CLAIMS_VALID_JSON_FIELDS] + ['file_path']
    #     return pd.DataFrame(columns=expected_cols)

    # # Drop rows where policy_effective_year is NaN
    # before = len(no_claims_df)
    # no_claims_df = no_claims_df.dropna(subset=['policy_effective_year'], how='any')
    # print(f"            Dropped {before - len(no_claims_df)} rows with missing policy_effective_year")

    # # Drop duplicates
    # before = len(no_claims_df)
    # no_claims_df = no_claims_df.drop_duplicates()
    # print(f"            Dropped {before - len(no_claims_df)} duplicate rows (using all columns)")

    # # Filter allowed lines of business
    # allowed_lobs = ["property", "auto", "general liability", "workers compensation", "umbrella"]
    # if 'line_of_business' in no_claims_df.columns:
    #     mask = no_claims_df['line_of_business'].str.strip().str.lower().isin(allowed_lobs)
    #     no_claims_df = no_claims_df[mask]

    # # If empty, return an empty DataFrame with expected columns
    # if no_claims_df.empty:
    #     expected_cols = ['AccountName'] + [col for col in NO_CLAIMS_VALID_JSON_FIELDS] + ['file_path']
    #     return pd.DataFrame(columns=expected_cols)

    # # Ensure dates are in "YYYY-MM-DD" format, else set to NaN
    # def validate_date(date_str):
    #     try:
    #         dt = pd.to_datetime(date_str, format='%Y-%m-%d', errors='raise')
    #         return dt.strftime('%Y-%m-%d')
    #     except Exception:
    #         return pd.NA

    # # List all date columns to validate
    # date_columns = [
    #     'evaluation_date'
    # ]
    # for col in date_columns:
    #     if col in no_claims_df.columns:
    #         no_claims_df[col] = no_claims_df[col].apply(validate_date)

    # # Final column order
    # final_order = ['AccountName'] + [col for col in NO_CLAIMS_VALID_JSON_FIELDS if col in no_claims_df.columns] + ['file_path']
    # final_order = [col for col in final_order if col in no_claims_df.columns]
    # no_claims_df = no_claims_df[final_order]

    # # If empty, return an empty DataFrame with expected columns
    # if no_claims_df.empty:
    #     expected_cols = ['AccountName'] + [col for col in NO_CLAIMS_VALID_JSON_FIELDS] + ['file_path']
    #     return pd.DataFrame(columns=expected_cols)

    return no_claims_df
