import React, { useState } from 'react';
import { Sidebar } from './components/Sidebar';
import { FileUploadPanel } from './components/MetricsAndUpload';
import { AgentWorkflowView } from './components/AgentComponents';
import { VerificationView, PreprocessingView, ExtractionView, RollupView } from './components/DataViews';
import { normalizeBackendResult } from './utils/backendNormalizer';
import { useWorkflowSimulation } from './hooks/useWorkflowSimulation';
import './index.css';

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }
  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }
  componentDidCatch(error, errorInfo) {
    console.error("ErrorBoundary caught an error:", error, errorInfo);
  }
  render() {
    if (this.state.hasError) {
      return (
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: '100%', gap: '16px', background: 'var(--bg-main)' }}>
          <h2 style={{ color: 'var(--status-red)' }}>Something went wrong. Restart Pipeline</h2>
          <p style={{ color: 'var(--text-muted)', maxWidth: '600px', textAlign: 'center' }}>{this.state.error?.toString()}</p>
          <button className="btn-primary" onClick={() => window.location.reload()}>Restart Application</button>
        </div>
      );
    }
    return this.props.children;
  }
}

export const DEMO_MODE = false;

function App() {
  const { isProcessing, isComplete, agents, logs, startSimulation, restart } = useWorkflowSimulation();
  
  // Local storage state initialization
  const [backendResult, setBackendResult] = useState(() => {
    const saved = localStorage.getItem('loss_run_backendResult');
    return saved ? JSON.parse(saved) : null;
  });
  
  const [normalizedResult, setNormalizedResult] = useState(() => {
    const saved = localStorage.getItem('loss_run_normalizedResult');
    return saved ? JSON.parse(saved) : null;
  });
  
  const [apiError, setApiError] = useState(null);
  
  const [fileStats, setFileStats] = useState(() => {
    const saved = localStorage.getItem('loss_run_fileStats');
    return saved ? JSON.parse(saved) : { total: 0, pdf: 0, excel: 0, csv: 0, docx: 0, rejected: 0 };
  });
  
  const [cacheProgress, setCacheProgress] = useState(null);
  
  const [isRolledUp, setIsRolledUp] = useState(() => {
    const saved = localStorage.getItem('loss_run_isRolledUp');
    try {
      return saved ? JSON.parse(saved) : 'idle';
    } catch {
      return saved || 'idle';
    }
  });

  const tabs = ['upload', 'verification', 'preprocessing', 'extraction', 'rollup'];
  const [currentTab, setCurrentTab] = useState(() => {
    return localStorage.getItem('loss_run_currentTab') || 'upload';
  });

  // Save states on change
  React.useEffect(() => {
    if (backendResult) {
      localStorage.setItem('loss_run_backendResult', JSON.stringify(backendResult));
    } else {
      localStorage.removeItem('loss_run_backendResult');
    }
  }, [backendResult]);

  React.useEffect(() => {
    if (normalizedResult) {
      localStorage.setItem('loss_run_normalizedResult', JSON.stringify(normalizedResult));
    } else {
      localStorage.removeItem('loss_run_normalizedResult');
    }
  }, [normalizedResult]);

  React.useEffect(() => {
    if (fileStats) {
      localStorage.setItem('loss_run_fileStats', JSON.stringify(fileStats));
    }
  }, [fileStats]);

  React.useEffect(() => {
    localStorage.setItem('loss_run_isRolledUp', JSON.stringify(isRolledUp));
  }, [isRolledUp]);

  React.useEffect(() => {
    localStorage.setItem('loss_run_currentTab', currentTab);
  }, [currentTab]);

  // Derive step completion statuses
  const isStep2Completed = !!normalizedResult && (!isProcessing || agents.find(a => a.id === 'detection')?.status === 'completed');
  const isStep3Completed = !!normalizedResult && (!isProcessing || agents.find(a => a.id === 'excelText')?.status === 'completed');
  const isStep4Completed = !!normalizedResult && (!isProcessing || agents.find(a => a.id === 'validation')?.status === 'completed');
  const isStep5Completed = (isRolledUp === 'completed' || isRolledUp === true);

  // Derive display agents with completed status if backendResult is saved and not processing
  const displayAgents = React.useMemo(() => {
    if (normalizedResult && !isProcessing) {
      return agents.map(a => {
        let input = a.input;
        let output = a.output;
        let recordsProcessed = a.recordsProcessed;
        let status = 'completed';
        
        const filesUploaded = normalizedResult.filesUploaded || 0;
        const claims = normalizedResult.claimsExtracted || 0;
        
        if (a.id === 'intake') {
          input = `${filesUploaded} files`;
          output = `${filesUploaded} files`;
          recordsProcessed = filesUploaded;
        } else if (a.id === 'detection') {
          input = `${filesUploaded} files`;
          output = `${filesUploaded} valid, 0 rejected`;
          recordsProcessed = filesUploaded;
        } else if (a.id === 'router') {
          input = `${filesUploaded} files`;
          output = `Routed files`;
          recordsProcessed = filesUploaded;
        } else if (a.id === 'finalExtract' || a.id === 'transform' || a.id === 'validation') {
          input = `Claims Data`;
          output = `${claims} claims`;
          recordsProcessed = claims;
        } else if (a.id === 'rollup' || a.id === 'report') {
          if (isRolledUp !== 'completed' && isRolledUp !== true) {
            status = 'waiting';
            input = '-';
            output = '-';
            recordsProcessed = 0;
          } else {
            input = `${claims} claims`;
            output = `Consolidated`;
            recordsProcessed = claims;
          }
        } else {
          status = 'completed';
        }
        
        return {
          ...a,
          status,
          input,
          output,
          recordsProcessed,
          time: a.time === '-' ? '0.5s' : a.time,
          score: a.score || '98%'
        };
      });
    }
    return agents;
  }, [agents, normalizedResult, isProcessing, isRolledUp]);

  const handleStartProcessing = async (files, stats) => {
    setFileStats(stats);
    startSimulation(stats);
    setCurrentTab('verification');
    setApiError(null);
    setBackendResult(null);
    setNormalizedResult(null);
    setCacheProgress(null);
    setIsRolledUp('idle');
    
    // Clear old localStorage values to start fresh
    localStorage.removeItem('loss_run_backendResult');
    localStorage.removeItem('loss_run_normalizedResult');
    localStorage.setItem('loss_run_isRolledUp', JSON.stringify('idle'));
    
    const formData = new FormData();
    for (let i = 0; i < files.length; i++) {
      formData.append('files', files[i]);
    }

    try {
      const response = await fetch('http://localhost:8000/api/process-loss-run', {
        method: 'POST',
        body: formData,
      });
      if (!response.ok) {
        const errData = await response.json().catch(() => null);
        throw new Error(errData?.detail || `Backend error: ${response.statusText}`);
      }
      const data = await response.json();
      console.log("REAL BACKEND RESULT:", data);
      const normResult = normalizeBackendResult(data, stats);
      
      if (data.cached) {
        // Cache hit: simulate completion progress bar from 0% to 100%
        setCacheProgress(0);
        let progress = 0;
        const interval = setInterval(() => {
          progress += 5;
          if (progress >= 100) {
            clearInterval(interval);
            setCacheProgress(null);
            setBackendResult(data);
            setNormalizedResult(normResult);
          } else {
            setCacheProgress(progress);
          }
        }, 60); // 20 steps * 60ms = 1.2s total progress simulation time
      } else {
        setBackendResult(data);
        setNormalizedResult(normResult);
      }
      console.log("Normalized Backend Result:", normResult);
    } catch (err) {
      console.error('API Error:', err);
      setApiError(`Failed to process files: ${err.message}`);
      setCacheProgress(null);
      restart(); // Stop the mock simulation on error
    }
  };

  const handleRunRollup = () => {
    setIsRolledUp('processing');
    setCurrentTab('rollup');
  };

  const handleRollupComplete = () => {
    setIsRolledUp('completed');
  };

  const currentIndex = tabs.indexOf(currentTab);
  
  const handleNext = () => {
    if (currentIndex < tabs.length - 1) {
      setCurrentTab(tabs[currentIndex + 1]);
    }
  };

  const handleBack = () => {
    if (currentIndex > 0) {
      setCurrentTab(tabs[currentIndex - 1]);
    }
  };

  let nextDisabled = false;
  if (currentIndex === tabs.length - 1) {
    nextDisabled = true;
  } else if (currentIndex === 0 && !isProcessing && !normalizedResult) {
    nextDisabled = true;
  } else if (currentTab === 'extraction' && (isRolledUp === 'idle' || !isRolledUp)) {
    nextDisabled = true;
  } else if (!isProcessing && !normalizedResult) {
    nextDisabled = true;
  }

  return (
    <div className="app-container">
      <Sidebar 
        isProcessing={isProcessing} 
        isComplete={isComplete} 
        currentTab={currentTab} 
        setCurrentTab={setCurrentTab} 
        backendResult={normalizedResult} 
        isRolledUp={isRolledUp}
        agents={agents}
      />
      <main className="main-content" style={{ padding: 0, gap: 0, height: '100vh', display: 'flex', flexDirection: 'column' }}>
        <div style={{ height: '230px', borderBottom: '1px solid var(--border-color)', background: 'var(--bg-main)', position: 'relative', overflow: 'hidden', flexShrink: 0 }}>
          <AgentWorkflowView agents={displayAgents} />
        </div>

        <div style={{ flex: 1, overflow: 'hidden', display: 'flex', flexDirection: 'column', position: 'relative' }}>
          <ErrorBoundary>
          {apiError && (
            <div style={{ position: 'absolute', top: 20, left: 40, right: 40, background: 'rgba(239, 68, 68, 0.1)', border: '1px solid var(--status-red)', color: 'var(--status-red)', padding: '12px 16px', borderRadius: '8px', zIndex: 100 }}>
              {apiError}
            </div>
          )}

          {currentTab === 'upload' && (
            <div style={{ padding: '40px', display: 'flex', flexDirection: 'column', justifyContent: 'center', height: '100%', animation: 'fadeIn 0.5s ease-out', overflow: 'hidden' }}>
              <FileUploadPanel startProcessing={handleStartProcessing} isProcessing={isProcessing} isComplete={isComplete} fileStats={fileStats} setFileStats={setFileStats} />
            </div>
          )}

          {currentTab === 'verification' && (
            <div style={{ padding: '24px 40px', display: 'flex', flexDirection: 'column', height: '100%', animation: 'fadeIn 0.5s ease-out', overflow: 'hidden' }}>
              <VerificationView 
                backendResult={normalizedResult} 
                fileStats={fileStats} 
                cacheProgress={cacheProgress} 
                logs={logs}
                isProcessing={isProcessing}
                isStep2Completed={isStep2Completed}
              />
            </div>
          )}

          {currentTab === 'preprocessing' && (
            <div style={{ padding: '24px 40px', display: 'flex', flexDirection: 'column', height: '100%', animation: 'fadeIn 0.5s ease-out', overflow: 'hidden' }}>
              <PreprocessingView 
                backendResult={normalizedResult} 
                fileStats={fileStats} 
                cacheProgress={cacheProgress} 
                logs={logs}
                isProcessing={isProcessing}
                isStep3Completed={isStep3Completed}
              />
            </div>
          )}

          {currentTab === 'extraction' && (
            <div style={{ padding: '24px 40px', display: 'flex', flexDirection: 'column', height: '100%', animation: 'fadeIn 0.5s ease-out', overflow: 'hidden' }}>
              <ExtractionView 
                backendResult={normalizedResult} 
                fileStats={fileStats} 
                isRolledUp={isRolledUp} 
                onRunRollup={handleRunRollup} 
                cacheProgress={cacheProgress} 
                logs={logs}
                isProcessing={isProcessing}
                isStep4Completed={isStep4Completed}
              />
            </div>
          )}

          {currentTab === 'rollup' && (
            <div style={{ padding: '24px 40px', display: 'flex', flexDirection: 'column', height: '100%', animation: 'fadeIn 0.5s ease-out', overflow: 'hidden' }}>
              <RollupView 
                backendResult={(isRolledUp === 'completed' || isRolledUp === true) ? normalizedResult : null} 
                fileStats={fileStats} 
                cacheProgress={cacheProgress} 
                isRolledUp={isRolledUp}
                onRunRollup={handleRunRollup}
                onRollupComplete={handleRollupComplete}
              />
            </div>
          )}

          {!tabs.includes(currentTab) && (
            <div style={{ padding: '40px', display: 'flex', flexDirection: 'column', height: '100%', justifyContent: 'center', alignItems: 'center' }}>
               <h2 style={{ color: 'var(--text-main)' }}>Loading view...</h2>
            </div>
          )}
          </ErrorBoundary>
        </div>

        <div style={{ padding: '20px 40px', background: 'rgba(11, 11, 11, 0.8)', backdropFilter: 'blur(16px)', borderTop: '1px solid var(--border-color)', display: 'flex', justifyContent: 'space-between', zIndex: 10 }}>
          <button className="btn-secondary" onClick={handleBack} disabled={currentIndex === 0} style={{ opacity: currentIndex === 0 ? 0.3 : 1 }}>
            Back
          </button>
          <button className="btn-primary" onClick={handleNext} disabled={nextDisabled} style={{ opacity: nextDisabled ? 0.3 : 1 }}>
            Next Step
          </button>
        </div>
      </main>
      <style dangerouslySetInnerHTML={{__html: `
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(10px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}} />
    </div>
  );
}

export default App;
