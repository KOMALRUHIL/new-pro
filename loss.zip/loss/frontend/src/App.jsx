import React, { useState } from 'react';
import { Sidebar } from './components/Sidebar';
import { FileUploadPanel } from './components/MetricsAndUpload';
import { AgentWorkflowView } from './components/AgentComponents';
import { VerificationView, PreprocessingView, ExtractionView, RollupView, DashboardView } from './components/DataViews';
import { normalizeBackendResult } from './utils/backendNormalizer';
import { useWorkflowSimulation } from './hooks/useWorkflowSimulation';
import './index.css';

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }
  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }
  componentDidCatch(error, errorInfo) {
    console.error("ErrorBoundary caught an error:", error, errorInfo);
  }
  render() {
    if (this.state.hasError) {
      return (
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: '100%', gap: '16px', background: 'var(--bg-main)' }}>
          <h2 style={{ color: 'var(--status-red)' }}>Something went wrong. Restart Pipeline</h2>
          <p style={{ color: 'var(--text-muted)', maxWidth: '600px', textAlign: 'center' }}>{this.state.error?.toString()}</p>
          <button className="btn-primary" onClick={() => window.location.reload()}>Restart Application</button>
        </div>
      );
    }
    return this.props.children;
  }
}

export const DEMO_MODE = false;

function App() {
  const [verificationResult, setVerificationResult] = useState(null);
  const [preprocessingResult, setPreprocessingResult] = useState(null);
  const [extractionResult, setExtractionResult] = useState(null);
  const [rollupResult, setRollupResult] = useState(null);
  const [batchHash, setBatchHash] = useState('');
  const [apiError, setApiError] = useState(null);
  const [fileStats, setFileStats] = useState({ total: 0, pdf: 0, excel: 0, csv: 0, docx: 0, rejected: 0 });
  const [cacheProgress, setCacheProgress] = useState(null);
  const [isRolledUp, setIsRolledUp] = useState('idle');
  const [isProcessing, setIsProcessing] = useState(false);
  const [logs, setLogs] = useState([]);

  const tabs = ['upload', 'verification', 'preprocessing', 'extraction', 'rollup', 'dashboard'];
  const [currentTab, setCurrentTab] = useState('upload');

  // Log simulation definitions
  const verificationLogMessages = [
    "Intake Agent collecting files from upload queue...",
    "Loss Run Detection Agent scanning file metadata and signatures...",
    "Running classification checks for uploaded loss runs...",
    "Verifying document identifiers and carrier formatting...",
    "Completed loss run document verification."
  ];

  const preprocessingLogMessages = [
    "Workflow Router routing file types to parallel processors...",
    "DOC/DOCX Converter converting legacy docs to standard PDF...",
    "PDF to Image Agent converting page vectors at 150 DPI...",
    "Image to Text Agent running OCR models for layout extraction...",
    "Excel Block Detection Agent scanning spreadsheet coordinate grids...",
    "Ingesting tables and cells coordinate matrices..."
  ];

  const extractionLogMessages = [
    "Final Extraction Agent merging PDF text and spreadsheet streams...",
    "Parsing claims attributes (Claim ID, claimant, dates, financials)...",
    "Transformation Agent applying carrier taxonomies and LOB mappings...",
    "Validation Agent executing mandatory field checks...",
    "Detecting duplicate claims and negative financials...",
    "Structured claims database generated and validated."
  ];

  const rollupLogMessages = [
    "Initializing Claimant Rollup Agent...",
    "Loading extracted claims database...",
    "Running name-normalization & fuzzy string matching models...",
    "Fuzzy-merging variations in Claimant identity...",
    "Grouping claims by Claimant identity & policy period...",
    "Aggregating financials (paid, reserve, incurred totals)...",
    "Generating final rollup CSV and Excel formats...",
    "Rollup completed successfully. Ready for download."
  ];

  const runLogSimulation = (messages, onComplete) => {
    setLogs([]);
    let index = 0;
    const interval = setInterval(() => {
      if (index < messages.length) {
        setLogs(prev => [
          ...prev,
          {
            id: Math.random().toString(36).substring(7),
            time: new Date().toLocaleTimeString([], { hour12: false }),
            text: messages[index],
            type: 'info'
          }
        ]);
        index++;
      } else {
        clearInterval(interval);
        if (onComplete) onComplete();
      }
    }, 650);
    return interval;
  };

  // Derive step completion statuses
  const isStep2Completed = !!verificationResult && !(isProcessing && currentTab === 'verification');
  const isStep3Completed = !!preprocessingResult && !(isProcessing && currentTab === 'preprocessing');
  const isStep4Completed = !!extractionResult && !(isProcessing && currentTab === 'extraction');
  const isStep5Completed = (isRolledUp === 'completed' || isRolledUp === true);

  // Trigger step APIs when tab changes
  React.useEffect(() => {
    if (currentTab === 'preprocessing' && !preprocessingResult && !isProcessing && verificationResult) {
      runPreprocessingStep();
    }
  }, [currentTab, preprocessingResult, isProcessing, verificationResult]);

  React.useEffect(() => {
    if (currentTab === 'extraction' && !extractionResult && !isProcessing && preprocessingResult) {
      runExtractionStep();
    }
  }, [currentTab, extractionResult, isProcessing, preprocessingResult]);

  // Trigger rollup automatically when entering rollup tab
  React.useEffect(() => {
    if (currentTab === 'rollup' && !rollupResult && !isProcessing && extractionResult) {
      runRollupStep();
    }
  }, [currentTab, rollupResult, isProcessing, extractionResult]);

  const runPreprocessingStep = async () => {
    setIsProcessing(true);
    setApiError(null);
    
    let logsDone = false;
    let apiDone = false;
    let apiPayload = null;

    const interval = runLogSimulation(preprocessingLogMessages, () => {
      logsDone = true;
      if (apiDone) {
        setPreprocessingResult(apiPayload);
        setIsProcessing(false);
      }
    });

    try {
      const response = await fetch('http://localhost:8000/api/preprocess', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ batchHash })
      });
      if (!response.ok) throw new Error(`Preprocessing failed: ${response.statusText}`);
      const data = await response.json();
      apiPayload = data;
      apiDone = true;
      if (logsDone) {
        setPreprocessingResult(data);
        setIsProcessing(false);
      }
    } catch (err) {
      console.error(err);
      setApiError(`Preprocessing step failed: ${err.message}`);
      clearInterval(interval);
      setIsProcessing(false);
    }
  };

  const runExtractionStep = async () => {
    setIsProcessing(true);
    setApiError(null);
    
    let logsDone = false;
    let apiDone = false;
    let apiPayload = null;

    const interval = runLogSimulation(extractionLogMessages, () => {
      logsDone = true;
      if (apiDone) {
        setExtractionResult(apiPayload);
        setIsProcessing(false);
      }
    });

    try {
      const response = await fetch('http://localhost:8000/api/extract', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ batchHash })
      });
      if (!response.ok) throw new Error(`Extraction failed: ${response.statusText}`);
      const data = await response.json();
      apiPayload = data;
      apiDone = true;
      if (logsDone) {
        setExtractionResult(data);
        setIsProcessing(false);
      }
    } catch (err) {
      console.error(err);
      setApiError(`Extraction step failed: ${err.message}`);
      clearInterval(interval);
      setIsProcessing(false);
    }
  };

  const runRollupStep = async () => {
    setIsProcessing(true);
    setApiError(null);
    setIsRolledUp('processing');
    
    let logsDone = false;
    let apiDone = false;
    let apiPayload = null;

    const interval = runLogSimulation(rollupLogMessages, () => {
      logsDone = true;
      if (apiDone) {
        setRollupResult(apiPayload);
        setIsRolledUp('completed');
        setIsProcessing(false);
      }
    });

    try {
      const response = await fetch('http://localhost:8000/api/rollup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ batchHash })
      });
      if (!response.ok) throw new Error(`Rollup failed: ${response.statusText}`);
      const data = await response.json();
      apiPayload = data;
      apiDone = true;
      if (logsDone) {
        setRollupResult(data);
        setIsRolledUp('completed');
        setIsProcessing(false);
      }
    } catch (err) {
      console.error(err);
      setApiError(`Rollup step failed: ${err.message}`);
      clearInterval(interval);
      setIsProcessing(false);
      setIsRolledUp('idle');
    }
  };

  // Derive display agents with completed status based on real execution state
  const displayAgents = React.useMemo(() => {
    const list = [
      { id: 'intake', name: 'File Intake Agent', status: 'waiting', icon: 'FolderInput', input: '-', output: '-', time: '-', score: null, recordsProcessed: 0 },
      { id: 'detection', name: 'Loss Run Detection Agent', status: 'waiting', icon: 'ShieldCheck', input: '-', output: '-', time: '-', score: null, recordsProcessed: 0 },
      { id: 'router', name: 'Workflow Router Agent', status: 'waiting', icon: 'Network', input: '-', output: '-', time: '-', score: null, recordsProcessed: 0 },
      { id: 'docToPdf', name: 'DOC/DOCX Converter', status: 'waiting', icon: 'FileCog', input: '-', output: '-', time: '-', score: null, recordsProcessed: 0 },
      { id: 'pdfToImage', name: 'PDF to Image Agent', status: 'waiting', icon: 'Image', input: '-', output: '-', time: '-', score: null, recordsProcessed: 0 },
      { id: 'imageToText', name: 'Image to Text Agent', status: 'waiting', icon: 'FileText', input: '-', output: '-', time: '-', score: null, recordsProcessed: 0 },
      { id: 'excelBlock', name: 'Excel Block Detection Agent', status: 'waiting', icon: 'Layout', input: '-', output: '-', time: '-', score: null, recordsProcessed: 0 },
      { id: 'excelText', name: 'Excel Text Extraction Agent', status: 'waiting', icon: 'FileSpreadsheet', input: '-', output: '-', time: '-', score: null, recordsProcessed: 0 },
      { id: 'finalExtract', name: 'Final Extraction Agent', status: 'waiting', icon: 'Cpu', input: '-', output: '-', time: '-', score: null, recordsProcessed: 0 },
      { id: 'transform', name: 'Transformation Agent', status: 'waiting', icon: 'RefreshCw', input: '-', output: '-', time: '-', score: null, recordsProcessed: 0 },
      { id: 'validation', name: 'Validation Agent', status: 'waiting', icon: 'CheckCircle', input: '-', output: '-', time: '-', score: null, recordsProcessed: 0 },
      { id: 'rollup', name: 'Rollup & Export', status: 'waiting', icon: 'BarChart2', input: '-', output: '-', time: '-', score: null, recordsProcessed: 0 },
      { id: 'report', name: 'Report Generator Agent', status: 'waiting', icon: 'FileOutput', input: '-', output: '-', time: '-', score: null, recordsProcessed: 0 }
    ];

    const filesCount = fileStats?.total || 0;
    const claimsCount = extractionResult?.claimsExtracted || 0;

    return list.map(a => {
      let status = 'waiting';
      let input = '-';
      let output = '-';
      let recordsProcessed = 0;
      let time = '-';
      let score = null;

      if (a.id === 'intake') {
        if (filesCount > 0) {
          status = 'completed';
          input = `${filesCount} files`;
          output = `${filesCount} files`;
          recordsProcessed = filesCount;
          time = '0.8s';
          score = '100%';
        }
      } else if (a.id === 'detection') {
        if (verificationResult) {
          status = 'completed';
          input = `${filesCount} files`;
          const valid = verificationResult.validLossRuns || 0;
          output = `${valid} valid, ${filesCount - valid} excluded`;
          recordsProcessed = filesCount;
          time = '1.5s';
          score = '98.7%';
        } else if (isProcessing && currentTab === 'verification') {
          status = 'running';
          input = 'Scanning...';
        }
      } else if (['router', 'docToPdf', 'pdfToImage', 'imageToText', 'excelBlock', 'excelText'].includes(a.id)) {
        const hasPdfStream = (fileStats?.pdf > 0 || fileStats?.docx > 0);
        const hasExcelStream = (fileStats?.excel > 0 || fileStats?.csv > 0);
        
        const isPdfAgent = ['docToPdf', 'pdfToImage', 'imageToText'].includes(a.id);
        const isExcelAgent = ['excelBlock', 'excelText'].includes(a.id);
        
        const isAgentActive = (isPdfAgent && hasPdfStream) || (isExcelAgent && hasExcelStream) || a.id === 'router';

        if (isAgentActive) {
          if (preprocessingResult) {
            status = 'completed';
            if (a.id === 'router') {
              input = `${filesCount} files`;
              output = 'Routed files';
              time = '0.3s';
            } else if (a.id === 'pdfToImage') {
              input = 'PDF files';
              output = 'Images';
              time = '2.5s';
            } else if (a.id === 'imageToText') {
              input = 'Images';
              output = 'Text';
              time = '3.8s';
              score = '98.5%';
            } else if (a.id === 'excelBlock') {
              input = 'Excel files';
              output = 'Tables';
              time = '1.1s';
            } else if (a.id === 'excelText') {
              input = 'Tables';
              output = 'Block JSON';
              time = '0.9s';
              score = '99%';
            } else {
              time = '0.5s';
            }
          } else if (isProcessing && currentTab === 'preprocessing') {
            status = 'running';
            input = 'Processing...';
          }
        }
      } else if (['finalExtract', 'transform', 'validation'].includes(a.id)) {
        if (extractionResult) {
          status = 'completed';
          recordsProcessed = claimsCount;
          score = extractionResult.aiConfidence || '98.7%';
          if (a.id === 'finalExtract') {
            input = 'Combined Streams';
            output = `${claimsCount} Claims`;
            time = '4.2s';
          } else if (a.id === 'transform') {
            input = `${claimsCount} Claims`;
            output = 'Normalized Data';
            time = '1.8s';
          } else if (a.id === 'validation') {
            input = 'Normalized Data';
            output = 'Validated';
            time = '2.1s';
          }
        } else if (isProcessing && currentTab === 'extraction') {
          status = 'running';
          input = 'Extracting...';
        }
      } else if (['rollup', 'report'].includes(a.id)) {
        if (isRolledUp === 'completed' || isRolledUp === true) {
          status = 'completed';
          recordsProcessed = claimsCount;
          if (a.id === 'rollup') {
            input = 'Validated Claims';
            output = 'Business Summaries';
            time = '1.2s';
          } else if (a.id === 'report') {
            input = 'All Data';
            output = 'Final Excel/CSV';
            time = '1.5s';
          }
        } else if (isRolledUp === 'processing') {
          status = 'running';
          input = 'Rolling up...';
        }
      }

      return {
        ...a,
        status,
        input,
        output,
        recordsProcessed,
        time,
        score
      };
    });
  }, [fileStats, verificationResult, preprocessingResult, extractionResult, isProcessing, isRolledUp, currentTab]);

  const handleStartProcessing = async (files, stats) => {
    setFileStats(stats);
    setCurrentTab('verification');
    setApiError(null);
    setVerificationResult(null);
    setPreprocessingResult(null);
    setExtractionResult(null);
    setRollupResult(null);
    setCacheProgress(null);
    setIsRolledUp('idle');
    setBatchHash('');
    
    // Clear localStorage to start fresh
    localStorage.removeItem('loss_run_verificationResult');
    localStorage.removeItem('loss_run_preprocessingResult');
    localStorage.removeItem('loss_run_extractionResult');
    localStorage.removeItem('loss_run_rollupResult');
    localStorage.removeItem('loss_run_batchHash');
    localStorage.setItem('loss_run_isRolledUp', JSON.stringify('idle'));
    
    setIsProcessing(true);
    
    let logsDone = false;
    let apiDone = false;
    let apiPayload = null;

    const interval = runLogSimulation(verificationLogMessages, () => {
      logsDone = true;
      if (apiDone) {
        setVerificationResult(apiPayload);
        setBatchHash(apiPayload.batchHash);
        setIsProcessing(false);
      }
    });

    const formData = new FormData();
    for (let i = 0; i < files.length; i++) {
      formData.append('files', files[i]);
    }

    try {
      const response = await fetch('http://localhost:8000/api/verify', {
        method: 'POST',
        body: formData,
      });
      if (!response.ok) {
        const errData = await response.json().catch(() => null);
        throw new Error(errData?.detail || `Backend error: ${response.statusText}`);
      }
      const data = await response.json();
      apiPayload = data;
      apiDone = true;
      if (logsDone) {
        setVerificationResult(data);
        setBatchHash(data.batchHash);
        setIsProcessing(false);
      }
    } catch (err) {
      console.error('API Error:', err);
      setApiError(`Verification step failed: ${err.message}`);
      clearInterval(interval);
      setIsProcessing(false);
    }
  };

  const handleRunRollup = () => {
    setIsRolledUp('processing');
    setCurrentTab('rollup');
  };

  const handleRollupComplete = () => {
    setIsRolledUp('completed');
  };

  const currentIndex = tabs.indexOf(currentTab);
  
  const handleNext = () => {
    if (currentIndex < tabs.length - 1) {
      setCurrentTab(tabs[currentIndex + 1]);
    }
  };

  const handleBack = () => {
    if (currentIndex > 0) {
      setCurrentTab(tabs[currentIndex - 1]);
    }
  };

  let nextDisabled = false;
  if (currentIndex === tabs.length - 1) {
    nextDisabled = true;
  } else if (currentTab === 'upload' && !verificationResult && !isProcessing) {
    nextDisabled = true;
  } else if (currentTab === 'verification' && !verificationResult) {
    nextDisabled = true;
  } else if (currentTab === 'preprocessing' && !preprocessingResult) {
    nextDisabled = true;
  } else if (currentTab === 'extraction' && !extractionResult) {
    nextDisabled = true;
  } else if (currentTab === 'rollup' && !isStep5Completed) {
    nextDisabled = true;
  } else if (isProcessing) {
    nextDisabled = true;
  }

  return (
    <div className="app-container">
      <Sidebar 
        isProcessing={isProcessing} 
        isComplete={!!extractionResult} 
        currentTab={currentTab} 
        setCurrentTab={setCurrentTab} 
        backendResult={extractionResult} 
        isRolledUp={isRolledUp}
        agents={displayAgents}
      />
      <main className="main-content" style={{ padding: 0, gap: 0, height: '100vh', display: 'flex', flexDirection: 'column' }}>
        <div style={{ height: '230px', borderBottom: '1px solid var(--border-color)', background: 'var(--bg-main)', position: 'relative', overflow: 'hidden', flexShrink: 0 }}>
          <AgentWorkflowView agents={displayAgents} />
        </div>

        <div style={{ flex: 1, overflow: 'hidden', display: 'flex', flexDirection: 'column', position: 'relative' }}>
          <ErrorBoundary>
          {apiError && (
            <div style={{ position: 'absolute', top: 20, left: 40, right: 40, background: 'rgba(239, 68, 68, 0.1)', border: '1px solid var(--status-red)', color: 'var(--status-red)', padding: '12px 16px', borderRadius: '8px', zIndex: 100 }}>
              {apiError}
            </div>
          )}

          {currentTab === 'upload' && (
            <div style={{ padding: '40px', display: 'flex', flexDirection: 'column', justifyContent: 'center', height: '100%', animation: 'fadeIn 0.5s ease-out', overflow: 'hidden' }}>
              <FileUploadPanel startProcessing={handleStartProcessing} isProcessing={isProcessing} isComplete={!!extractionResult} fileStats={fileStats} setFileStats={setFileStats} />
            </div>
          )}

          {currentTab === 'verification' && (
            <div style={{ padding: '24px 40px', display: 'flex', flexDirection: 'column', height: '100%', animation: 'fadeIn 0.5s ease-out', overflow: 'hidden' }}>
              <VerificationView 
                backendResult={verificationResult} 
                fileStats={fileStats} 
                cacheProgress={cacheProgress} 
                logs={logs}
                isProcessing={isProcessing}
                isStep2Completed={isStep2Completed}
              />
            </div>
          )}

          {currentTab === 'preprocessing' && (
            <div style={{ padding: '24px 40px', display: 'flex', flexDirection: 'column', height: '100%', animation: 'fadeIn 0.5s ease-out', overflow: 'hidden' }}>
              <PreprocessingView 
                backendResult={preprocessingResult} 
                fileStats={fileStats} 
                cacheProgress={cacheProgress} 
                logs={logs}
                isProcessing={isProcessing}
                isStep3Completed={isStep3Completed}
              />
            </div>
          )}

          {currentTab === 'extraction' && (
            <div style={{ padding: '24px 40px', display: 'flex', flexDirection: 'column', height: '100%', animation: 'fadeIn 0.5s ease-out', overflow: 'hidden' }}>
              <ExtractionView 
                backendResult={extractionResult} 
                fileStats={fileStats} 
                isRolledUp={isRolledUp} 
                onRunRollup={handleRunRollup} 
                cacheProgress={cacheProgress} 
                logs={logs}
                isProcessing={isProcessing}
                isStep4Completed={isStep4Completed}
              />
            </div>
          )}

          {currentTab === 'rollup' && (
            <div style={{ padding: '24px 40px', display: 'flex', flexDirection: 'column', height: '100%', animation: 'fadeIn 0.5s ease-out', overflow: 'hidden' }}>
              <RollupView 
                backendResult={isStep5Completed ? rollupResult : null} 
                fileStats={fileStats} 
                cacheProgress={cacheProgress} 
                isRolledUp={isRolledUp}
                onRunRollup={handleRunRollup}
                onRollupComplete={handleRollupComplete}
                logs={logs}
              />
            </div>
          )}

          {currentTab === 'dashboard' && (
            <div style={{ padding: '24px 40px', display: 'flex', flexDirection: 'column', height: '100%', animation: 'fadeIn 0.5s ease-out', overflow: 'hidden' }}>
              <DashboardView 
                rollupResult={rollupResult}
                fileStats={fileStats}
              />
            </div>
          )}

          {!tabs.includes(currentTab) && (
            <div style={{ padding: '40px', display: 'flex', flexDirection: 'column', height: '100%', justifyContent: 'center', alignItems: 'center' }}>
               <h2 style={{ color: 'var(--text-main)' }}>Loading view...</h2>
            </div>
          )}
          </ErrorBoundary>
        </div>

        <div style={{ padding: '20px 40px', background: 'rgba(11, 11, 11, 0.8)', backdropFilter: 'blur(16px)', borderTop: '1px solid var(--border-color)', display: 'flex', justifyContent: 'space-between', zIndex: 10 }}>
          <button className="btn-secondary" onClick={handleBack} disabled={currentIndex === 0} style={{ opacity: currentIndex === 0 ? 0.3 : 1 }}>
            Back
          </button>
          <button className="btn-primary" onClick={handleNext} disabled={nextDisabled} style={{ opacity: nextDisabled ? 0.3 : 1 }}>
            Next Step
          </button>
        </div>
      </main>
      <style dangerouslySetInnerHTML={{__html: `
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(10px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}} />
    </div>
  );
}

export default App;
