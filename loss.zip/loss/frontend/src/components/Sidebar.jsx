import React from 'react';
import { UploadCloud, Network, Wand2, ShieldCheck, BarChart2, CheckCircle2, Circle } from 'lucide-react';

export function Sidebar({ isProcessing, isComplete, currentTab, setCurrentTab, backendResult }) {
  const navItems = [
    { id: 'upload', mainIcon: UploadCloud, label: 'Upload Files' },
    { id: 'verification', mainIcon: ShieldCheck, label: 'Loss Run Verification' },
    { id: 'preprocessing', mainIcon: Network, label: 'OCR & Pre-processing' },
    { id: 'extraction', mainIcon: Wand2, label: 'Extracted Claims' },
    { id: 'rollup', mainIcon: BarChart2, label: 'Rollup & Export' },
  ];

  const activeIndex = navItems.findIndex(item => item.id === currentTab);



  return (
    <aside className="premium-sidebar">
      <div className="premium-sidebar-header">
        <div className="premium-sidebar-title">Loss Run AI</div>
        <div className="premium-sidebar-subtitle">Agentic Processing Platform</div>
      </div>



      <nav className="premium-nav">
        {navItems.map((item, index) => {
          let workflowStatus = 'pending';
          let statusText = 'Pending';
          
          if (isComplete) {
            if (index < 4) {
              workflowStatus = 'completed';
              statusText = 'Completed';
            } else if (index === 4) {
              const hasRollup = !!backendResult?.rolledUpRows || !!backendResult?.lobSummary?.length > 0;
              workflowStatus = hasRollup ? 'completed' : 'ready';
              statusText = hasRollup ? 'Completed' : 'Ready to Rollup';
            }
          } else if (isProcessing) {
            if (index === 0) {
              workflowStatus = 'completed';
              statusText = 'Completed';
            } else if (index === 1) {
              workflowStatus = 'processing';
              statusText = 'Verifying...';
            } else if (index === 2) {
              workflowStatus = 'processing';
              statusText = 'Preprocessing...';
            } else if (index === 3) {
              workflowStatus = 'processing';
              statusText = 'Extracting...';
            } else {
              workflowStatus = 'pending';
              statusText = 'Pending';
            }
          } else {
            if (index === 0) {
              workflowStatus = 'processing';
              statusText = 'Waiting...';
            } else {
              workflowStatus = 'pending';
              statusText = 'Pending';
            }
          }

          const isViewing = (index === activeIndex);
          let statusClass = 'pending';

          if (isViewing) {
            statusClass = 'active';
          } else if (workflowStatus === 'completed') {
            statusClass = 'completed';
          } else if (workflowStatus === 'processing' || workflowStatus === 'ready') {
            statusClass = 'active';
          } else {
            statusClass = 'pending';
          }

          return (
            <button
              key={item.id}
              className={`premium-nav-item ${statusClass}`}
              onClick={() => setCurrentTab(item.id)}
            >
              {isViewing && <div className="active-indicator" />}
              
              <div className="status-icon-wrapper">
                {workflowStatus === 'completed' && <CheckCircle2 size={20} className="icon-completed" />}
                {(workflowStatus === 'processing' || workflowStatus === 'ready') && <span className="icon-active" style={{ fontSize: '1.2rem', fontWeight: 'bold' }}>➜</span>}
                {workflowStatus === 'pending' && <Circle size={18} className="icon-pending" />}
              </div>
              
              <div className="item-content">
                <div className="item-label" style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <item.mainIcon size={16} />
                  {item.label}
                </div>
                <div className={`item-status status-${statusClass}-text`}>
                  {statusText}
                </div>
              </div>
            </button>
          );
        })}
      </nav>
    </aside>
  );
}
