import { UploadCloud, Network, Wand2, ShieldCheck, BarChart2, CheckCircle2, Circle, RefreshCw, Layers } from 'lucide-react';

export function Sidebar({ isProcessing, isComplete, currentTab, setCurrentTab, backendResult, isRolledUp, agents }) {
  const navItems = [
    { id: 'upload', mainIcon: UploadCloud, label: 'Upload Files' },
    { id: 'verification', mainIcon: ShieldCheck, label: 'Loss Run Verification' },
    { id: 'preprocessing', mainIcon: Network, label: 'OCR & Pre-processing' },
    { id: 'extraction', mainIcon: Wand2, label: 'Extracted Claims' },
    { id: 'rollup', mainIcon: Layers, label: 'Rollup & Export' },
    { id: 'dashboard', mainIcon: BarChart2, label: 'Analytics Dashboard' },
  ];

  const activeIndex = navItems.findIndex(item => item.id === currentTab);

  return (
    <aside className="premium-sidebar">
      <div className="premium-sidebar-header">
        <div className="premium-sidebar-title">Loss Run AI</div>
        <div className="premium-sidebar-subtitle">Agentic Processing Platform</div>
      </div>

      <nav className="premium-nav">
        {navItems.map((item, index) => {
          let workflowStatus = 'pending';
          let statusText = 'Pending';
          
          const hasData = !!backendResult;
          const isStep2Completed = !!agents.find(a => a.id === 'detection' && a.status === 'completed');
          const isStep3Completed = !!agents.find(a => a.id === 'excelText' && a.status === 'completed');
          const isStep4Completed = !!agents.find(a => a.id === 'validation' && a.status === 'completed');
          const isStep5Completed = (isRolledUp === 'completed' || isRolledUp === true);

          if (index === 0) {
            if (isStep2Completed || isProcessing || isComplete) {
              workflowStatus = 'completed';
              statusText = 'Completed';
            } else {
              workflowStatus = 'processing';
              statusText = 'Waiting...';
            }
          } else if (index === 1) {
            if (isStep2Completed) {
              workflowStatus = 'completed';
              statusText = 'Completed';
            } else if (isProcessing && currentTab === 'verification') {
              workflowStatus = 'processing';
              statusText = 'Verifying...';
            } else {
              workflowStatus = 'pending';
              statusText = 'Pending';
            }
          } else if (index === 2) {
            if (isStep3Completed) {
              workflowStatus = 'completed';
              statusText = 'Completed';
            } else if (isProcessing && currentTab === 'preprocessing') {
              workflowStatus = 'processing';
              statusText = 'Preprocessing...';
            } else {
              workflowStatus = 'pending';
              statusText = 'Pending';
            }
          } else if (index === 3) {
            if (isStep4Completed) {
              workflowStatus = 'completed';
              statusText = 'Completed';
            } else if (isProcessing && currentTab === 'extraction') {
              workflowStatus = 'processing';
              statusText = 'Extracting...';
            } else {
              workflowStatus = 'pending';
              statusText = 'Pending';
            }
          } else if (index === 4) {
            if (isStep5Completed) {
              workflowStatus = 'completed';
              statusText = 'Completed';
            } else if (isRolledUp === 'processing') {
              workflowStatus = 'processing';
              statusText = 'Rolling up...';
            } else if (isStep4Completed) {
              workflowStatus = 'ready';
              statusText = 'Ready';
            } else {
              workflowStatus = 'pending';
              statusText = 'Pending';
            }
          } else if (index === 5) {
            if (isStep5Completed) {
              workflowStatus = 'ready';
              statusText = 'Ready';
            } else {
              workflowStatus = 'pending';
              statusText = 'Pending';
            }
          }

          const isViewing = (index === activeIndex);
          let statusClass = 'pending';

          if (isViewing) {
            statusClass = 'active';
          } else if (workflowStatus === 'completed') {
            statusClass = 'completed';
          } else if (workflowStatus === 'processing' || workflowStatus === 'ready') {
            statusClass = 'active';
          } else {
            statusClass = 'pending';
          }

          // Disable navigating to steps that haven't been unlocked yet
          let isNavigationAllowed = false;
          if (index === 0) isNavigationAllowed = true;
          else if (index === 1) isNavigationAllowed = !!agents.find(a => a.id === 'intake' && a.status === 'completed');
          else if (index === 2) isNavigationAllowed = isStep2Completed;
          else if (index === 3) isNavigationAllowed = isStep3Completed;
          else if (index === 4) isNavigationAllowed = isStep4Completed;
          else if (index === 5) isNavigationAllowed = isStep5Completed;

          const handleNavClick = () => {
            if (isNavigationAllowed && !isProcessing && isRolledUp !== 'processing') {
              setCurrentTab(item.id);
            }
          };

          return (
            <button
              key={item.id}
              className={`premium-nav-item ${statusClass}`}
              onClick={handleNavClick}
              disabled={!isNavigationAllowed}
              style={{
                cursor: isNavigationAllowed && !isProcessing && isRolledUp !== 'processing' ? 'pointer' : 'not-allowed',
                opacity: isNavigationAllowed ? 1 : 0.45
              }}
            >
              {isViewing && <div className="active-indicator" />}
              
              <div className="status-icon-wrapper">
                {workflowStatus === 'completed' && <CheckCircle2 size={20} className="icon-completed" />}
                {(workflowStatus === 'processing' || workflowStatus === 'ready') && <span className="icon-active" style={{ fontSize: '1.2rem', fontWeight: 'bold' }}>➜</span>}
                {workflowStatus === 'pending' && <Circle size={18} className="icon-pending" />}
              </div>
              
              <div className="item-content">
                <div className="item-label" style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <item.mainIcon size={16} />
                  {item.label}
                </div>
                <div className={`item-status status-${statusClass}-text`}>
                  {statusText}
                </div>
              </div>
            </button>
          );
        })}
      </nav>

      {/* Reset Operations */}
      <div style={{ marginTop: 'auto', padding: '20px', borderTop: '1px solid var(--border-color)', display: 'flex', flexDirection: 'column', gap: '10px' }}>
        <button
          className="btn-secondary"
          onClick={() => {
            if (window.confirm("Are you sure you want to clear all processed data and restart the pipeline?")) {
              localStorage.clear();
              window.location.reload();
            }
          }}
          style={{ width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px', fontSize: '0.8rem', padding: '8px 12px' }}
          disabled={isProcessing || isRolledUp === 'processing'}
        >
          <RefreshCw size={14} /> Reset System
        </button>
      </div>
    </aside>
  );
}
