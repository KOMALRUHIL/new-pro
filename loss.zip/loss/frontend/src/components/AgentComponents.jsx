import React, { useMemo, useState } from 'react';
import * as LucideIcons from 'lucide-react';
import ReactFlow, { Background, MarkerType, Handle, Position, Controls, MiniMap, getSmoothStepPath, EdgeLabelRenderer, Panel } from 'reactflow';
import 'reactflow/dist/style.css';

const CustomAgentNode = ({ data }) => {
  const { agent } = data;
  if (!agent || Object.keys(agent).length === 0) return null;
  
  const Icon = LucideIcons[agent.icon] || LucideIcons.Activity;
  
  const statusColors = {
    waiting: 'var(--border-color)',
    running: '#3b82f6', 
    completed: 'var(--status-green)',
    warning: 'var(--status-yellow)',
    failed: 'var(--status-red)'
  };
  
  const bgMap = {
    waiting: 'var(--bg-card-hover)',
    running: 'rgba(59, 130, 246, 0.12)', 
    completed: 'rgba(16, 185, 129, 0.12)',
    warning: 'rgba(245, 158, 11, 0.12)',
    failed: 'rgba(239, 68, 68, 0.12)'
  };

  const StatusIcon = agent.status === 'completed' ? LucideIcons.CheckCircle2 : (agent.status === 'failed' ? LucideIcons.XCircle : (agent.status === 'running' ? LucideIcons.Loader2 : LucideIcons.Circle));
  const color = statusColors[agent.status];
  const width = '220px'; 
  const scaleClass = agent.status === 'running' ? 'pulse-glow-running' : '';
  const transformStyle = agent.status === 'running' ? 'scale(1.03)' : 'scale(1)';

  return (
    <>
      <Handle type="target" position={Position.Left} id="t-left" style={{ opacity: 0 }} />
      <Handle type="target" position={Position.Top} id="t-top" style={{ opacity: 0 }} />
      <Handle type="target" position={Position.Bottom} id="t-bottom" style={{ opacity: 0 }} />
      <Handle type="target" position={Position.Right} id="t-right" style={{ opacity: 0 }} />
      
      <Handle type="source" position={Position.Right} id="s-right" style={{ opacity: 0 }} />
      <Handle type="source" position={Position.Top} id="s-top" style={{ opacity: 0 }} />
      <Handle type="source" position={Position.Bottom} id="s-bottom" style={{ opacity: 0 }} />
      <Handle type="source" position={Position.Left} id="s-left" style={{ opacity: 0 }} />

      <div className={`glass-panel ${scaleClass}`} style={{ 
        width, 
        display: 'flex', 
        flexDirection: 'column', 
        background: 'var(--bg-card)', 
        borderRadius: '8px', 
        border: `1px solid ${color}`, 
        overflow: 'hidden', 
        transform: transformStyle, 
        transition: 'all 0.3s ease', 
        boxShadow: agent.status === 'running' ? `0 0 15px ${color}40` : '0 2px 8px rgba(0,0,0,0.15)' 
      }}>
        <div style={{ padding: '10px 14px', display: 'flex', alignItems: 'center', gap: '10px' }}>
          <div style={{ padding: '6px', borderRadius: '6px', background: bgMap[agent.status], color: color, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
             <Icon size={18} />
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', flex: 1, overflow: 'hidden' }}>
            <h4 style={{ fontSize: '14px', color: 'var(--text-main)', fontWeight: 600, margin: 0, whiteSpace: 'normal', wordBreak: 'break-word', lineHeight: '1.2' }} title={agent.name}>{agent.name}</h4>
            <span style={{ fontSize: '11px', color: 'var(--text-muted)', marginTop: '4px', fontWeight: 600, letterSpacing: '0.3px' }}>{agent.status?.toUpperCase()}</span>
          </div>
          <div style={{ color: color, display: 'flex', alignItems: 'center' }}>
             <StatusIcon size={14} className={agent.status === 'running' ? 'spin-loader' : ''} />
          </div>
        </div>

        <div style={{ 
          background: bgMap[agent.status], 
          padding: '6px 14px', 
          display: 'flex', 
          alignItems: 'center', 
          gap: '6px', 
          borderTop: `1px solid ${color}22`,
          fontSize: '12px',
          color: color,
          overflow: 'hidden'
        }}>
          <span style={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', width: '100%', fontWeight: 500 }} title={agent.output || agent.input}>
            {agent.output || agent.input || 'Waiting...'}
          </span>
        </div>
      </div>
    </>
  );
};

const AnimatedEdge = ({ id, sourceX, sourceY, targetX, targetY, sourcePosition, targetPosition, style = {}, markerEnd, data }) => {
  const [edgePath, labelX, labelY] = getSmoothStepPath({ sourceX, sourceY, sourcePosition, targetX, targetY, targetPosition });

  return (
    <>
      <path id={id} style={style} className="react-flow__edge-path" d={edgePath} markerEnd={markerEnd} fill="none" />
      {data?.animated && (
        <circle r="4" className="data-packet" fill="#3b82f6">
          <animateMotion dur="1s" repeatCount="indefinite" path={edgePath} />
        </circle>
      )}
      {data?.label && (
        <EdgeLabelRenderer>
          <div style={{ position: 'absolute', transform: `translate(-50%, -50%) translate(${labelX}px,${labelY}px)`, background: 'var(--bg-main)', padding: '2px 6px', borderRadius: '4px', border: `1px solid ${style.stroke}`, fontSize: 10, fontWeight: 600, color: style.stroke, pointerEvents: 'all', zIndex: 10, letterSpacing: '0.5px', textTransform: 'uppercase' }} className="nodrag nopan">
            {data.label}
          </div>
        </EdgeLabelRenderer>
      )}
    </>
  );
};

const initialNodes = [
  // Intake & Filter (Col 1)
  { id: 'intake', type: 'agentNode', position: { x: 0, y: 15 } },
  { id: 'detection', type: 'agentNode', position: { x: 0, y: 125 } },
  // Router (Col 2)
  { id: 'router', type: 'agentNode', position: { x: 280, y: 70 } },
  
  // PDF/Word Stream (Col 3, 4, 5 - Row 1)
  { id: 'docToPdf', type: 'agentNode', position: { x: 560, y: 15 } },
  { id: 'pdfToImage', type: 'agentNode', position: { x: 840, y: 15 } },
  { id: 'imageToText', type: 'agentNode', position: { x: 1120, y: 15 } },
  
  // Excel/CSV Stream (Col 3, 4 - Row 2)
  { id: 'excelBlock', type: 'agentNode', position: { x: 560, y: 125 } },
  { id: 'excelText', type: 'agentNode', position: { x: 840, y: 125 } },
  
  // Merge into Final Extract (Col 5 - Row 2)
  { id: 'finalExtract', type: 'agentNode', position: { x: 1120, y: 125 } },
  
  // Post-processing (Col 6 - Row 2 and Row 1)
  { id: 'transform', type: 'agentNode', position: { x: 1400, y: 125 } },
  { id: 'validation', type: 'agentNode', position: { x: 1400, y: 15 } },
  
  // Final steps (Col 7 - Row 1 and Row 2)
  { id: 'rollup', type: 'agentNode', position: { x: 1680, y: 15 } },
  { id: 'report', type: 'agentNode', position: { x: 1680, y: 125 } }
];

const createEdges = (agents) => {
  const safeAgents = agents || [];
  const getStatus = (id) => safeAgents.find(a => a.id === id)?.status || 'waiting';
  const isAnim = (targetId) => getStatus(targetId) === 'running';
  
  const buildEdge = (source, target, label, sHandle, tHandle) => {
    const animated = isAnim(target);
    const targetStatus = getStatus(target);
    
    const edgeColor = targetStatus === 'failed' ? 'var(--status-red)' : 
                      (targetStatus === 'waiting' ? 'var(--border-color)' : 'var(--status-green)');
                      
    return {
      id: `e-${source}-${target}`,
      source,
      target,
      sourceHandle: sHandle,
      targetHandle: tHandle,
      type: 'animatedEdge',
      data: { label, animated },
      style: {
        stroke: animated ? '#3b82f6' : edgeColor,
        strokeWidth: animated ? 3 : 2,
        opacity: 1
      },
      markerEnd: { type: MarkerType.ArrowClosed, color: animated ? '#3b82f6' : edgeColor }
    };
  };

  return [
    buildEdge('intake', 'detection', 'Files', 's-bottom', 't-top'),
    buildEdge('detection', 'router', 'Valid', 's-right', 't-left'),
    
    // PDF/Word Stream (horizontal)
    buildEdge('router', 'docToPdf', 'DOCX', 's-right', 't-left'),
    buildEdge('docToPdf', 'pdfToImage', 'PDF', 's-right', 't-left'),
    buildEdge('pdfToImage', 'imageToText', 'Images', 's-right', 't-left'),
    
    // Excel/CSV Stream (horizontal)
    buildEdge('router', 'excelBlock', 'XLSX', 's-right', 't-left'),
    buildEdge('excelBlock', 'excelText', 'Blocks', 's-right', 't-left'),
    
    // Merge into Final Extract (Excel horizontal, PDF vertical down)
    buildEdge('excelText', 'finalExtract', 'JSON', 's-right', 't-left'),
    buildEdge('imageToText', 'finalExtract', 'Text', 's-bottom', 't-top'),
    
    // Post-processing (serpentine square-wave flow)
    buildEdge('finalExtract', 'transform', 'Unified', 's-right', 't-left'),
    buildEdge('transform', 'validation', 'Claims', 's-top', 't-bottom'),
    buildEdge('validation', 'rollup', 'Valid', 's-right', 't-left'),
    buildEdge('rollup', 'report', 'Rollups', 's-bottom', 't-top'),
  ];
};

export function AgentWorkflowView({ agents }) {
  const nodeTypes = useMemo(() => ({ agentNode: CustomAgentNode }), []);
  const edgeTypes = useMemo(() => ({ animatedEdge: AnimatedEdge }), []);
  
  if (!agents || agents.length === 0) {
    return (
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100%', flexDirection: 'column', gap: '16px' }}>
        <LucideIcons.Loader2 size={48} className="spin-loader" color="var(--accent-color)" />
        <h2 style={{ color: 'var(--text-main)', fontSize: '1.2rem' }}>Initializing Agentic Pipeline...</h2>
      </div>
    );
  }

  const nodes = initialNodes.map(n => ({
    ...n,
    data: { agent: agents.find(a => a.id === n.id) || {} }
  }));

  const edges = createEdges(agents);

  const containerStyle = {
    width: '100%',
    height: '100%',
    borderBottom: '1px solid var(--border-color)',
    background: 'var(--bg-main)',
    overflow: 'hidden',
    position: 'relative'
  };

  return (
    <div style={containerStyle}>
      <ReactFlow 
        nodes={nodes} 
        edges={edges} 
        nodeTypes={nodeTypes} 
        edgeTypes={edgeTypes}
        fitView 
        fitViewOptions={{ padding: 0.04 }}
        panOnDrag={false} 
        zoomOnScroll={false}
        zoomOnDoubleClick={false}
        zoomOnPinch={false}
        nodesDraggable={false}
        nodesConnectable={false}
        elementsSelectable={false}
        preventScrolling={true}
      >
        <Background color="var(--border-color)" gap={20} />
      </ReactFlow>
    </div>
  );
}

