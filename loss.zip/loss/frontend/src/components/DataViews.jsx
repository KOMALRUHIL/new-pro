import React, { useState } from 'react';
import * as LucideIcons from 'lucide-react';
import * as XLSX from 'xlsx';

export function LoadingScreen({ message, progress }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', alignItems: 'center', justifyContent: 'center', gap: '20px' }}>
      <LucideIcons.Loader2 size={48} className="spin-loader" color="var(--accent-color)" />
      <div style={{ textAlign: 'center' }}>
        <h3 style={{ color: 'var(--text-main)', margin: '0 0 8px 0', fontSize: '1.1rem' }}>{message}</h3>
        {progress !== undefined && progress !== null && (
          <div style={{ width: '280px', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '8px', margin: '12px auto 0 auto' }}>
            <div style={{ width: '100%', height: '6px', background: 'var(--border-color)', borderRadius: '3px', overflow: 'hidden' }}>
              <div style={{ width: `${progress}%`, height: '100%', background: 'var(--accent-color)', borderRadius: '3px', transition: 'width 0.1s ease-out' }} />
            </div>
            <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)', fontWeight: 600 }}>{progress}% Completed</span>
          </div>
        )}
      </div>
    </div>
  );
}

export function AwaitingUploadView() {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', alignItems: 'center', justifyContent: 'center', color: 'var(--text-muted)' }}>
      <LucideIcons.UploadCloud size={48} style={{ marginBottom: '16px', color: 'var(--accent-color)', opacity: 0.8 }} />
      <h3 style={{ color: 'var(--text-main)', fontSize: '1.1rem', margin: 0 }}>Awaiting Loss Run Upload</h3>
      <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)', marginTop: '8px' }}>Please upload loss run documents in Step 1 to begin processing.</p>
    </div>
  );
}

export function ConsoleTerminal({ title, logs, isProcessing }) {
  const terminalEndRef = React.useRef(null);

  React.useEffect(() => {
    if (terminalEndRef.current) {
      terminalEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [logs]);

  return (
    <div style={{
      display: 'flex',
      flexDirection: 'column',
      height: '350px',
      overflow: 'hidden',
      marginTop: '16px',
    }}>
      {/* Title Bar */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '0 0 12px 0',
        borderBottom: '1px solid var(--border-color)',
        userSelect: 'none',
        flexShrink: 0,
        marginBottom: '12px'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <LucideIcons.Terminal size={16} color="var(--accent-color)" />
          <span style={{ fontSize: '0.85rem', color: 'var(--text-main)', fontWeight: 600 }}>{title || 'Pipeline System Logs'}</span>
        </div>
        {isProcessing && (
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '0.75rem', color: 'var(--accent-color)' }}>
            <LucideIcons.Loader2 className="spin-loader" size={12} />
            <span style={{ fontWeight: 600 }}>Active</span>
          </div>
        )}
      </div>

      {/* Terminal Content */}
      <div style={{
        flex: 1,
        overflowY: 'auto',
        display: 'flex',
        flexDirection: 'column',
        gap: '8px',
        paddingRight: '6px'
      }}>
        {logs.map((log, idx) => (
          <div key={log.id || idx} style={{ 
            display: 'flex', 
            flexDirection: 'column',
            background: 'var(--bg-card-hover)',
            border: '1px solid var(--border-color)',
            borderLeft: `4px solid ${log.type === 'warning' ? 'var(--status-yellow)' : 'var(--status-green)'}`,
            borderRadius: '6px',
            padding: '12px 16px',
            gap: '6px',
            animation: 'fadeInLog 0.2s ease-out' 
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', width: '100%' }}>
              <span style={{ fontSize: '0.65rem', fontWeight: 700, color: 'rgba(255, 255, 255, 0.4)', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
                {log.type === 'warning' ? 'System Warning' : 'System Activity'}
              </span>
              <span style={{ fontSize: '0.7rem', color: 'rgba(255, 255, 255, 0.4)', fontWeight: 500 }}>
                [{log.time || 'INFO'}]
              </span>
            </div>
            <span style={{ color: 'var(--text-main)', fontSize: '0.85rem', fontWeight: 500, lineHeight: '1.4' }}>
              {log.text}
            </span>
          </div>
        ))}

        {isProcessing && (
          <div style={{ 
            display: 'flex', 
            flexDirection: 'column',
            background: 'rgba(59, 130, 246, 0.05)',
            border: '1px solid rgba(59, 130, 246, 0.2)',
            borderLeft: '4px solid #3b82f6',
            borderRadius: '6px',
            padding: '12px 16px',
            gap: '6px',
            animation: 'pulse 2s infinite' 
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', width: '100%' }}>
              <span style={{ fontSize: '0.65rem', fontWeight: 700, color: 'rgba(59, 130, 246, 0.6)', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
                System Running
              </span>
              <span style={{ fontSize: '0.7rem', color: 'rgba(59, 130, 246, 0.6)', fontWeight: 500 }}>
                [ACTIVE]
              </span>
            </div>
            <span style={{ color: 'var(--text-main)', fontSize: '0.85rem', fontWeight: 500, display: 'flex', alignItems: 'center', gap: '8px' }}>
              <LucideIcons.Loader2 size={14} className="spin-loader" color="#3b82f6" />
              Running agent workflow...
            </span>
          </div>
        )}

        {!isProcessing && logs.length > 0 && (
          <div style={{ 
            display: 'flex', 
            flexDirection: 'column',
            background: 'rgba(16, 185, 129, 0.05)',
            border: '1px solid rgba(16, 185, 129, 0.2)',
            borderLeft: '4px solid var(--status-green)',
            borderRadius: '6px',
            padding: '12px 16px',
            gap: '6px'
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', width: '100%' }}>
              <span style={{ fontSize: '0.65rem', fontWeight: 700, color: 'var(--status-green)', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
                Pipeline Success
              </span>
              <span style={{ fontSize: '0.7rem', color: 'var(--status-green)', fontWeight: 500 }}>
                [COMPLETED]
              </span>
            </div>
            <span style={{ color: 'var(--text-main)', fontSize: '0.85rem', fontWeight: 500 }}>
              All pipeline tasks completed successfully. Click Next Step to view results.
            </span>
          </div>
        )}

        <div ref={terminalEndRef} />
      </div>

      <style dangerouslySetInnerHTML={{__html: `
        @keyframes fadeInLog {
          from { opacity: 0; transform: translateY(4px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}} />
    </div>
  );
}

// STEP 2: LOSS RUN VERIFICATION VIEW
export function VerificationView({ backendResult, fileStats, cacheProgress, logs, isProcessing, isStep2Completed }) {
  const [selectedFile, setSelectedFile] = useState(null);

  if (!fileStats || fileStats.total === 0) {
    return <AwaitingUploadView />;
  }

  if (cacheProgress !== null) {
    return <LoadingScreen message="Retrieving cached verification reports..." progress={cacheProgress} />;
  }

  if (!isStep2Completed) {
    return (
      <div style={{ display: 'flex', flexDirection: 'column', height: '100%', animation: 'fadeIn 0.5s ease-out' }}>
        <div className="section-title">
          <LucideIcons.ShieldCheck color="var(--accent-color)" /> Step 2: Loss Run Verification
        </div>
        <p className="section-subtitle">
          Intake Agent scan complete. The Loss Run Detection Agent is scanning and classifying documents.
        </p>
        <ConsoleTerminal title="verification-agent.sh" logs={logs || []} isProcessing={isProcessing} />
      </div>
    );
  }

  // Use uploaded files list and enrich with detection details from the backend
  const files = fileStats?.uploadedList && fileStats.uploadedList.length > 0 
    ? fileStats.uploadedList.map(f => {
        const detectInfo = backendResult?.detection?.[f.name];
        if (detectInfo) {
          return {
            ...f,
            valid: detectInfo.is_loss_run,
            reason: detectInfo.is_loss_run 
              ? `Verified by Loss Run Detection Agent using ${detectInfo.method} analysis. Verified Loss Run Report.`
              : `Classified as non-loss run and excluded. Excluded Document.`
          };
        }
        return f;
      })
    : [];

  const negativeCheck = backendResult?.validationChecks?.find(c => c.check === 'Negative Value Check');
  const hasNegativeFinancials = negativeCheck ? negativeCheck.status === 'warning' : false;

  const activeFile = files.find(f => f.name === selectedFile?.name) || files[0];

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', animation: 'fadeIn 0.5s ease-out' }}>
      <div className="section-title">
        <LucideIcons.ShieldCheck color="var(--accent-color)" /> Step 2: Loss Run Verification
      </div>
      <p className="section-subtitle">
        Intake Agent scan complete. The Loss Run Detection Agent has verified document types and filtered out invalid files.
      </p>

      {/* Metric Cards Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '16px', marginTop: '16px', marginBottom: '8px' }}>
        {/* Card 1: Files Processed */}
        <div className="glass-panel" style={{ padding: '12px 16px', display: 'flex', alignItems: 'center', gap: '12px', background: 'var(--bg-card-hover)' }}>
          <div style={{ padding: '8px', borderRadius: '8px', background: 'rgba(234, 88, 12, 0.1)', color: 'var(--accent-color)' }}>
            <LucideIcons.FileCheck size={18} />
          </div>
          <div>
            <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.5px' }}>Files Processed</div>
            <div style={{ fontSize: '1.25rem', fontWeight: 700, color: 'var(--text-main)', marginTop: '2px' }}>{backendResult?.filesUploaded || 0}</div>
          </div>
        </div>

        {/* Card 2: Duplicates Found */}
        <div className="glass-panel" style={{ padding: '12px 16px', display: 'flex', alignItems: 'center', gap: '12px', background: 'var(--bg-card-hover)' }}>
          <div style={{ padding: '8px', borderRadius: '8px', background: backendResult?.duplicatesFound > 0 ? 'rgba(245, 158, 11, 0.1)' : 'rgba(16, 185, 129, 0.1)', color: backendResult?.duplicatesFound > 0 ? 'var(--status-yellow)' : 'var(--status-green)' }}>
            <LucideIcons.Copy size={18} />
          </div>
          <div>
            <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.5px' }}>Duplicates Found</div>
            <div style={{ fontSize: '1.25rem', fontWeight: 700, color: backendResult?.duplicatesFound > 0 ? 'var(--status-yellow)' : 'var(--text-main)', marginTop: '2px' }}>
              {backendResult?.duplicatesFound || 0}
            </div>
          </div>
        </div>

        {/* Card 3: Negative Financials */}
        <div className="glass-panel" style={{ padding: '12px 16px', display: 'flex', alignItems: 'center', gap: '12px', background: 'var(--bg-card-hover)' }}>
          <div style={{ padding: '8px', borderRadius: '8px', background: hasNegativeFinancials ? 'rgba(239, 68, 68, 0.1)' : 'rgba(16, 185, 129, 0.1)', color: hasNegativeFinancials ? 'var(--status-red)' : 'var(--status-green)' }}>
            <LucideIcons.AlertTriangle size={18} />
          </div>
          <div>
            <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.5px' }}>Negative Financials</div>
            <div style={{ fontSize: '1.1rem', fontWeight: 700, color: hasNegativeFinancials ? 'var(--status-red)' : 'var(--status-green)', marginTop: '2px' }}>
              {hasNegativeFinancials ? 'Detected' : 'None Detected'}
            </div>
          </div>
        </div>

        {/* Card 4: AI Confidence */}
        <div className="glass-panel" style={{ padding: '12px 16px', display: 'flex', alignItems: 'center', gap: '12px', background: 'var(--bg-card-hover)' }}>
          <div style={{ padding: '8px', borderRadius: '8px', background: 'rgba(16, 185, 129, 0.1)', color: 'var(--status-green)' }}>
            <LucideIcons.Sparkles size={18} />
          </div>
          <div>
            <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.5px' }}>AI Confidence</div>
            <div style={{ fontSize: '1.25rem', fontWeight: 700, color: 'var(--status-green)', marginTop: '2px' }}>{backendResult?.aiConfidence || 'N/A'}</div>
          </div>
        </div>
      </div>

      <div style={{ display: 'flex', gap: '24px', flex: 1, overflow: 'hidden', marginTop: '16px' }}>
        {/* Left list of files */}
        <div style={{ width: '45%', display: 'flex', flexDirection: 'column', gap: '10px', overflowY: 'auto', paddingRight: '8px' }}>
          {files.map((file, i) => (
            <button
              key={i}
              onClick={() => setSelectedFile(file)}
              className="glass-panel"
              style={{
                padding: '16px',
                textAlign: 'left',
                border: activeFile?.name === file.name ? '1px solid var(--accent-color)' : '1px solid var(--border-color)',
                background: activeFile?.name === file.name ? 'rgba(234, 88, 12, 0.05)' : 'var(--bg-card-hover)',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                transition: 'all 0.2s'
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                <span className={`file-ext-badge badge-${file.type}`} style={{ fontSize: '0.7rem' }}>{file.type}</span>
                <div>
                  <div style={{ color: 'var(--text-main)', fontSize: '0.85rem', fontWeight: 600 }}>{file.name}</div>
                  <div style={{ color: 'var(--text-muted)', fontSize: '0.75rem', marginTop: '2px' }}>{file.size}</div>
                </div>
              </div>
              <div>
                {file.valid ? (
                  <div style={{ color: 'var(--status-green)', display: 'flex', alignItems: 'center', gap: '4px', fontSize: '0.8rem', fontWeight: 600 }}>
                    <LucideIcons.CheckCircle2 size={16} /> VERIFIED
                  </div>
                ) : (
                  <div style={{ color: 'var(--status-red)', display: 'flex', alignItems: 'center', gap: '4px', fontSize: '0.8rem', fontWeight: 600 }}>
                    <LucideIcons.XCircle size={16} /> EXCLUDED
                  </div>
                )}
              </div>
            </button>
          ))}
        </div>

        {/* Right Verification Details */}
        <div className="glass-panel" style={{ flex: 1, padding: '24px', display: 'flex', flexDirection: 'column', background: 'var(--bg-card-hover)', overflowY: 'auto' }}>
          {activeFile ? (
            <>
              <div style={{ borderBottom: '1px solid var(--border-color)', paddingBottom: '16px', marginBottom: '16px' }}>
                <span className={`file-ext-badge badge-${activeFile.type}`} style={{ marginBottom: '8px' }}>{activeFile.type.toUpperCase()} File</span>
                <h3 style={{ fontSize: '1.25rem', color: 'var(--text-main)', margin: '4px 0' }}>{activeFile.name}</h3>
                <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>Size: {activeFile.size}</span>
              </div>

              <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: '16px' }}>
                <div>
                  <h4 style={{ fontSize: '0.9rem', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: '8px' }}>Verification Result</h4>
                  <div style={{ 
                    padding: '12px 16px', 
                    borderRadius: '6px', 
                    background: activeFile.valid ? 'rgba(16, 185, 129, 0.08)' : 'rgba(239, 68, 68, 0.08)',
                    color: activeFile.valid ? 'var(--status-green)' : 'var(--status-red)',
                    border: `1px solid ${activeFile.valid ? 'var(--status-green)44' : 'var(--status-red)44'}`,
                    fontWeight: 600,
                    fontSize: '0.9rem',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px'
                  }}>
                    {activeFile.valid ? <LucideIcons.ShieldCheck size={18} /> : <LucideIcons.AlertTriangle size={18} />}
                    {activeFile.valid ? 'Verified Loss Run Report Document' : 'Non-Loss Run Invoice Excluded'}
                  </div>
                </div>

                <div>
                  <h4 style={{ fontSize: '0.9rem', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: '8px' }}>LLM Classification Audit</h4>
                  <p style={{ color: 'var(--text-main)', fontSize: '0.95rem', lineHeight: '1.5', background: 'rgba(255,255,255,0.02)', padding: '16px', borderRadius: '8px', border: '1px solid var(--border-color)' }}>
                    {activeFile.reason}
                  </p>
                </div>
              </div>
            </>
          ) : (
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100%', color: 'var(--text-muted)' }}>
              Select a file on the left to view verification audit logs
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
// STEP 3: OCR & PREPROCESSING (DIVIDED VIEW)
export function PreprocessingView({ backendResult, fileStats, cacheProgress, logs, isProcessing, isStep3Completed }) {
  const [selectedDocIndex, setSelectedDocIndex] = useState(0);
  const [activeSheetTab, setActiveSheetTab] = useState('Claims Data');
  const [hoveredBox, setHoveredBox] = useState(null);

  if (!fileStats || fileStats.total === 0) {
    return <AwaitingUploadView />;
  }

  if (cacheProgress !== null) {
    return <LoadingScreen message="Retrieving cached preprocessing metrics..." progress={cacheProgress} />;
  }

  if (!isStep3Completed) {
    return (
      <div style={{ display: 'flex', flexDirection: 'column', height: '100%', animation: 'fadeIn 0.5s ease-out' }}>
        <div className="section-title">
          <LucideIcons.Network color="var(--accent-color)" /> Step 3: OCR & Pre-processing
        </div>
        <p className="section-subtitle">
          Document parsing and spreadsheet ingestion suites processing files concurrently.
        </p>
        <ConsoleTerminal title="preprocessing-ocr.sh" logs={logs || []} isProcessing={isProcessing} />
      </div>
    );
  }

  const docFiles = fileStats?.uploadedList?.filter(f => f.type === 'pdf' || f.type === 'docx') || [];
  const sheetFiles = fileStats?.uploadedList?.filter(f => f.type === 'xlsx' || f.type === 'csv') || [];

  const hasDocFiles = docFiles.length > 0;
  const hasExcelFiles = sheetFiles.length > 0;

  // Generate dynamic logs based on real files
  const docLogs = [];
  docFiles.forEach((f, index) => {
    const timeOffset = index * 2;
    docLogs.push(`[12:04:${10 + timeOffset}] [docx_conv] Processing document vector structure for: ${f.name}`);
    docLogs.push(`[12:04:${12 + timeOffset}] [pdf_img] Splitting ${f.name} pages at 150 DPI resolution.`);
    docLogs.push(`[12:04:${15 + timeOffset}] [img_txt] Layout-aware OCR completed. Found textual tables.`);
  });

  const sheetLogs = [];
  sheetFiles.forEach((f, index) => {
    const timeOffset = index * 3;
    sheetLogs.push(`[12:04:${10 + timeOffset}] [excel_detect] Scanning grid coordinate dimensions for: ${f.name}`);
    sheetLogs.push(`[12:04:${13 + timeOffset}] [excel_detect] Found claim table block coordinates (A1:G${backendResult?.rawRows?.length || 10})`);
    sheetLogs.push(`[12:04:${16 + timeOffset}] [excel_extract] Parsed table records and cast values to JSON.`);
  });

  // Extract first 2 rows of claims data for the cell matrix mapping visualizer
  const matrixRows = backendResult?.matrixRows || backendResult?.rawRows?.slice(0, 2) || [];

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', animation: 'fadeIn 0.5s ease-out' }}>
      <div className="section-title">
        <LucideIcons.Network color="var(--accent-color)" /> Step 3: OCR & Pre-processing
      </div>
      <p className="section-subtitle">
        Document parsing and spreadsheet ingestion suites processing files concurrently.
      </p>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '24px', flex: 1, overflow: 'hidden', marginTop: '16px' }}>
        
        {/* Left Side: Document Stream (PDF/Word) */}
        <div className="glass-panel" style={{ padding: '20px', display: 'flex', flexDirection: 'column', overflow: 'hidden', borderLeft: '3px solid rgba(239, 68, 68, 0.4)' }}>
          <h4 style={{ color: 'var(--text-main)', fontSize: '1.05rem', borderBottom: '1px solid var(--border-color)', paddingBottom: '10px', marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }}>
            <LucideIcons.FileText color="#ef4444" size={18} /> Document Parsing Suite (PDF & Word)
          </h4>
          
          {hasDocFiles ? (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '16px', flex: 1, overflowY: 'auto', paddingRight: '4px' }}>

              {/* Page rotation preview mockups */}
              <div>
                <div style={{ fontSize: '0.85rem', fontWeight: 600, color: 'var(--text-main)', marginBottom: '10px' }}>Ingested document layouts</div>
                <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap' }}>
                  {docFiles.map((doc, idx) => (
                    <button 
                      key={idx} 
                      onClick={() => setSelectedDocIndex(idx)}
                      style={{ 
                        display: 'flex', 
                        flexDirection: 'column', 
                        alignItems: 'center', 
                        gap: '6px',
                        border: 'none',
                        background: 'none',
                        padding: 0,
                        cursor: 'pointer'
                      }}
                    >
                      <div style={{ 
                        width: '90px', 
                        height: '110px', 
                        background: 'var(--bg-card-hover)', 
                        border: selectedDocIndex === idx ? '2px solid var(--accent-color)' : '1px solid var(--status-green)', 
                        borderRadius: '4px', 
                        display: 'flex', 
                        flexDirection: 'column', 
                        alignItems: 'center', 
                        justifyContent: 'center', 
                        color: selectedDocIndex === idx ? 'var(--accent-color)' : 'var(--status-green)', 
                        position: 'relative', 
                        padding: '8px',
                        transition: 'all 0.2s',
                        transform: selectedDocIndex === idx ? 'scale(1.04)' : 'scale(1)'
                      }}>
                        <LucideIcons.FileText size={24} />
                        <span style={{ fontSize: '0.6rem', fontWeight: 600, color: 'var(--text-main)', marginTop: '8px', textAlign: 'center', width: '100%', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{doc.name}</span>
                        <span style={{ position: 'absolute', bottom: '4px', fontSize: '0.55rem', fontWeight: 600, color: 'var(--text-muted)' }}>{doc.type.toUpperCase()}</span>
                      </div>
                      <span style={{ fontSize: '0.7rem', color: selectedDocIndex === idx ? 'var(--accent-color)' : 'var(--status-green)', fontWeight: 600 }}>
                        {selectedDocIndex === idx ? '[✓] Selected' : '[✓] Parsed'}
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Interactive Bounding Box Canvas */}
              {docFiles[selectedDocIndex] && (
                <div style={{ display: 'flex', gap: '20px', marginTop: '16px', borderTop: '1px solid var(--border-color)', paddingTop: '16px', flexShrink: 0 }}>
                  <div style={{
                    width: '180px',
                    height: '240px',
                    background: 'var(--bg-main)',
                    border: '1px solid var(--border-color)',
                    borderRadius: '6px',
                    position: 'relative',
                    overflow: 'hidden',
                    boxShadow: '0 4px 12px rgba(0,0,0,0.3)',
                    flexShrink: 0
                  }}>
                    {/* Mock Text Lines */}
                    <div style={{ padding: '15px 12px', display: 'flex', flexDirection: 'column', gap: '8px' }}>
                      <div style={{ height: '4px', background: 'rgba(255,255,255,0.08)', width: '60%', borderRadius: '2px' }} />
                      <div style={{ height: '4px', background: 'rgba(255,255,255,0.08)', width: '85%', borderRadius: '2px' }} />
                      <div style={{ height: '4px', background: 'rgba(255,255,255,0.08)', width: '40%', borderRadius: '2px' }} />
                      
                      {/* Table Rows simulator */}
                      <div style={{ display: 'flex', flexDirection: 'column', gap: '6px', margin: '15px 0' }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                          <div style={{ height: '4px', background: 'rgba(255,255,255,0.05)', width: '30%', borderRadius: '2px' }} />
                          <div style={{ height: '4px', background: 'rgba(255,255,255,0.05)', width: '20%', borderRadius: '2px' }} />
                          <div style={{ height: '4px', background: 'rgba(255,255,255,0.05)', width: '25%', borderRadius: '2px' }} />
                        </div>
                        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                          <div style={{ height: '4px', background: 'rgba(255,255,255,0.05)', width: '25%', borderRadius: '2px' }} />
                          <div style={{ height: '4px', background: 'rgba(255,255,255,0.05)', width: '25%', borderRadius: '2px' }} />
                          <div style={{ height: '4px', background: 'rgba(255,255,255,0.05)', width: '20%', borderRadius: '2px' }} />
                        </div>
                        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                          <div style={{ height: '4px', background: 'rgba(255,255,255,0.05)', width: '35%', borderRadius: '2px' }} />
                          <div style={{ height: '4px', background: 'rgba(255,255,255,0.05)', width: '15%', borderRadius: '2px' }} />
                          <div style={{ height: '4px', background: 'rgba(255,255,255,0.05)', width: '30%', borderRadius: '2px' }} />
                        </div>
                      </div>
                      
                      <div style={{ height: '4px', background: 'rgba(255,255,255,0.08)', width: '90%', borderRadius: '2px', marginTop: '15px' }} />
                      <div style={{ height: '4px', background: 'rgba(255,255,255,0.08)', width: '50%', borderRadius: '2px' }} />
                    </div>

                    {/* OVERLAY 1: Header (Blue) */}
                    <div 
                      onMouseEnter={() => setHoveredBox({
                        name: 'Header Region',
                        coords: '[x:10, y:12, w:160, h:45]',
                        confidence: '99.4%',
                        details: 'Discovered Carrier headers, policy periods, and evaluation metadata.'
                      })}
                      onMouseLeave={() => setHoveredBox(null)}
                      style={{
                        position: 'absolute',
                        top: '10px',
                        left: '8px',
                        width: '164px',
                        height: '48px',
                        background: hoveredBox?.name === 'Header Region' ? 'rgba(59, 130, 246, 0.25)' : 'rgba(59, 130, 246, 0.12)',
                        border: '1px solid #3b82f6',
                        borderRadius: '4px',
                        cursor: 'pointer',
                        transition: 'all 0.2s'
                      }}
                    />

                    {/* OVERLAY 2: Claims Table (Green) */}
                    <div 
                      onMouseEnter={() => setHoveredBox({
                        name: 'Claims Table Region',
                        coords: '[x:10, y:65, w:160, h:110]',
                        confidence: '98.7%',
                        details: 'Detected tabular coordinates mapping claim identifiers, dates, and reserves.'
                      })}
                      onMouseLeave={() => setHoveredBox(null)}
                      style={{
                        position: 'absolute',
                        top: '65px',
                        left: '8px',
                        width: '164px',
                        height: '115px',
                        background: hoveredBox?.name === 'Claims Table Region' ? 'rgba(16, 185, 129, 0.25)' : 'rgba(16, 185, 129, 0.12)',
                        border: '1px solid #10b981',
                        borderRadius: '4px',
                        cursor: 'pointer',
                        transition: 'all 0.2s'
                      }}
                    />

                    {/* OVERLAY 3: Totals Region (Orange) */}
                    <div 
                      onMouseEnter={() => setHoveredBox({
                        name: 'Totals Region',
                        coords: '[x:10, y:188, w:160, h:35]',
                        confidence: '99.1%',
                        details: 'Identified financial summaries and block-level carrier totals.'
                      })}
                      onMouseLeave={() => setHoveredBox(null)}
                      style={{
                        position: 'absolute',
                        top: '188px',
                        left: '8px',
                        width: '164px',
                        height: '40px',
                        background: hoveredBox?.name === 'Totals Region' ? 'rgba(245, 158, 11, 0.25)' : 'rgba(245, 158, 11, 0.12)',
                        border: '1px solid #f59e0b',
                        borderRadius: '4px',
                        cursor: 'pointer',
                        transition: 'all 0.2s'
                      }}
                    />
                  </div>

                  {/* Details panel */}
                  <div style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center', background: 'rgba(255,255,255,0.01)', padding: '12px 16px', borderRadius: '6px', border: '1px solid var(--border-color)', height: '240px' }}>
                    <div style={{ fontSize: '0.72rem', textTransform: 'uppercase', color: 'var(--text-muted)', fontWeight: 600, letterSpacing: '0.5px' }}>OCR Spatial Analyzer</div>
                    <div style={{ fontSize: '0.82rem', fontWeight: 700, color: 'var(--text-main)', marginTop: '2px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }} title={docFiles[selectedDocIndex]?.name}>
                      {docFiles[selectedDocIndex]?.name}
                    </div>
                    
                    <div style={{ height: '1px', background: 'var(--border-color)', margin: '10px 0' }} />

                    {hoveredBox ? (
                      <div style={{ display: 'flex', flexDirection: 'column', gap: '6px', animation: 'fadeInLog 0.2s ease-out' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                          <span style={{ width: '8px', height: '8px', borderRadius: '50%', background: hoveredBox.name === 'Header Region' ? '#3b82f6' : (hoveredBox.name === 'Claims Table Region' ? '#10b981' : '#f59e0b') }} />
                          <span style={{ fontSize: '0.8rem', fontWeight: 600, color: 'var(--text-main)' }}>{hoveredBox.name}</span>
                        </div>
                        <div style={{ fontSize: '0.7rem', fontFamily: 'monospace', color: 'var(--text-muted)' }}>Coords: {hoveredBox.coords}</div>
                        <div style={{ fontSize: '0.7rem', color: 'var(--status-green)', fontWeight: 600 }}>Confidence: {hoveredBox.confidence}</div>
                        <p style={{ fontSize: '0.7rem', color: 'var(--text-muted)', lineHeight: '1.3', marginTop: '2px' }}>{hoveredBox.details}</p>
                      </div>
                    ) : (
                      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', flex: 1, color: 'var(--text-muted)', textAlign: 'center', gap: '6px' }}>
                        <span style={{ fontSize: '1.2rem' }}>🎯</span>
                        <span style={{ fontSize: '0.7rem' }}>Hover over the layout canvas Highlights to inspect bounding coordinates & OCR confidence scores.</span>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', flex: 1, color: 'var(--text-muted)', fontSize: '0.9rem' }}>
              No PDF or Word documents uploaded in this batch.
            </div>
          )}
        </div>

        {/* Right Side: Spreadsheet Stream (Excel/CSV) */}
        <div className="glass-panel" style={{ padding: '20px', display: 'flex', flexDirection: 'column', overflow: 'hidden', borderLeft: '3px solid rgba(16, 185, 129, 0.4)' }}>
          <h4 style={{ color: 'var(--text-main)', fontSize: '1.05rem', borderBottom: '1px solid var(--border-color)', paddingBottom: '10px', marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }}>
            <LucideIcons.FileSpreadsheet color="#10b981" size={18} /> Spreadsheet Ingestion Suite (Excel & CSV)
          </h4>

          {hasExcelFiles ? (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '12px', flex: 1, overflowY: 'auto', paddingRight: '4px' }}>

              {/* Dynamic Grid Layout Preview based on Active Tab */}
              <div style={{ display: 'flex', flexDirection: 'column', flex: 1 }}>
                <div style={{ fontSize: '0.85rem', fontWeight: 600, color: 'var(--text-main)', marginBottom: '8px' }}>Active Sheet Grid Matrix Preview</div>
                
                {(() => {
                  const colKeys = matrixRows.length > 0 ? Object.keys(matrixRows[0]).slice(0, 5) : [];
                  const getExcelColLetter = (index) => String.fromCharCode(65 + index);

                  if (activeSheetTab === 'Claims Data') {
                    return (
                      <div style={{ border: '1px solid var(--border-color)', padding: '6px', borderRadius: '6px', background: 'var(--bg-main)', overflow: 'hidden' }}>
                        {colKeys.length > 0 ? (
                          <div style={{
                            display: 'grid',
                            gridTemplateColumns: `40px repeat(${colKeys.length}, 1fr)`,
                            gap: '1px',
                            background: 'var(--border-color)',
                            fontFamily: 'monospace',
                            fontSize: '0.75rem',
                          }}>
                            {/* Excel letters header row */}
                            <div style={{ background: 'var(--bg-card-hover)', color: 'var(--text-muted)', padding: '4px', textAlign: 'center', fontWeight: 'bold' }}></div>
                            {colKeys.map((_, colIdx) => (
                              <div key={colIdx} style={{ background: 'var(--bg-card-hover)', color: 'var(--text-muted)', padding: '4px', textAlign: 'center', fontWeight: 'bold' }}>
                                {getExcelColLetter(colIdx)}
                              </div>
                            ))}

                            {/* Excel Row 1 (Actual Headers) */}
                            <div style={{ background: 'var(--bg-card-hover)', color: 'var(--text-muted)', padding: '4px', textAlign: 'center', fontWeight: 'bold' }}>1</div>
                            {colKeys.map((key, colIdx) => (
                              <div key={colIdx} style={{ background: 'var(--bg-card-hover)', color: 'var(--text-main)', padding: '4px', fontWeight: 'bold', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                                {key.startsWith('Unnamed:') ? '' : key}
                              </div>
                            ))}

                            {/* Excel Data Rows */}
                            {matrixRows.map((row, rowIdx) => (
                              <React.Fragment key={rowIdx}>
                                <div style={{ background: 'var(--bg-card-hover)', color: 'var(--text-muted)', padding: '4px', textAlign: 'center' }}>
                                  {rowIdx + 2}
                                </div>
                                {colKeys.map((key, colIdx) => {
                                  const val = row[key];
                                  return (
                                    <div key={colIdx} style={{ background: 'var(--bg-card-hover)', color: 'var(--status-green)', padding: '4px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                                      {val !== null && val !== undefined ? String(val) : ''}
                                    </div>
                                  );
                                })}
                              </React.Fragment>
                            ))}
                          </div>
                        ) : (
                          <div style={{ padding: '16px', color: 'var(--text-muted)', textAlign: 'center', fontSize: '0.8rem' }}>
                            Ingesting raw claims records...
                          </div>
                        )}
                        <div style={{ fontSize: '0.65rem', color: 'var(--text-muted)', marginTop: '8px', textAlign: 'right' }}>
                          Found: {sheetFiles.length} active sheet{sheetFiles.length > 1 ? 's' : ''}. Extracted: {backendResult?.claimsExtracted || 0} records
                        </div>
                      </div>
                    );
                  } else if (activeSheetTab === 'Summary Pivot') {
                    return (
                      <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                        <div style={{ border: '1px solid var(--border-color)', padding: '8px', borderRadius: '6px', background: 'var(--bg-main)' }}>
                          <div style={{ fontSize: '0.72rem', fontWeight: 700, color: 'var(--status-yellow)', display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '8px' }}>
                            <LucideIcons.AlertTriangle size={14} /> EXCLUDED FROM TRANSACTION EXTRACTION (PRE-AGGREGATED DATA)
                          </div>
                          <div style={{
                            display: 'grid',
                            gridTemplateColumns: '40px 1.5fr 1fr 1fr 1fr',
                            gap: '1px',
                            background: 'var(--border-color)',
                            fontFamily: 'monospace',
                            fontSize: '0.7rem',
                          }}>
                            {/* Headers */}
                            <div style={{ background: 'var(--bg-card-hover)', color: 'var(--text-muted)', padding: '4px', textAlign: 'center' }}></div>
                            <div style={{ background: 'var(--bg-card-hover)', color: 'var(--text-muted)', padding: '4px', fontWeight: 'bold' }}>Policy Year</div>
                            <div style={{ background: 'var(--bg-card-hover)', color: 'var(--text-muted)', padding: '4px', fontWeight: 'bold', textAlign: 'right' }}>Claims</div>
                            <div style={{ background: 'var(--bg-card-hover)', color: 'var(--text-muted)', padding: '4px', fontWeight: 'bold', textAlign: 'right' }}>Total Incurred</div>
                            <div style={{ background: 'var(--bg-card-hover)', color: 'var(--text-muted)', padding: '4px', fontWeight: 'bold', textAlign: 'right' }}>Total Paid</div>

                            {/* Row 1 */}
                            <div style={{ background: 'var(--bg-card-hover)', color: 'var(--text-muted)', padding: '4px', textAlign: 'center' }}>1</div>
                            <div style={{ background: 'var(--bg-card-hover)', color: 'var(--text-main)', padding: '4px' }}>2022 Policy Year</div>
                            <div style={{ background: 'var(--bg-card-hover)', color: 'var(--text-main)', padding: '4px', textAlign: 'right' }}>14</div>
                            <div style={{ background: 'var(--bg-card-hover)', color: 'var(--text-main)', padding: '4px', textAlign: 'right' }}>$182,500</div>
                            <div style={{ background: 'var(--bg-card-hover)', color: 'var(--text-main)', padding: '4px', textAlign: 'right' }}>$120,400</div>

                            {/* Row 2 */}
                            <div style={{ background: 'var(--bg-card-hover)', color: 'var(--text-muted)', padding: '4px', textAlign: 'center' }}>2</div>
                            <div style={{ background: 'var(--bg-card-hover)', color: 'var(--text-main)', padding: '4px' }}>2023 Policy Year</div>
                            <div style={{ background: 'var(--bg-card-hover)', color: 'var(--text-main)', padding: '4px', textAlign: 'right' }}>22</div>
                            <div style={{ background: 'var(--bg-card-hover)', color: 'var(--text-main)', padding: '4px', textAlign: 'right' }}>$345,100</div>
                            <div style={{ background: 'var(--bg-card-hover)', color: 'var(--text-main)', padding: '4px', textAlign: 'right' }}>$210,900</div>

                            {/* Row 3 */}
                            <div style={{ background: 'var(--bg-card-hover)', color: 'var(--text-muted)', padding: '4px', textAlign: 'center' }}>3</div>
                            <div style={{ background: 'var(--bg-card-hover)', color: 'var(--text-main)', padding: '4px' }}>2024 Policy Year</div>
                            <div style={{ background: 'var(--bg-card-hover)', color: 'var(--text-main)', padding: '4px', textAlign: 'right' }}>18</div>
                            <div style={{ background: 'var(--bg-card-hover)', color: 'var(--text-main)', padding: '4px', textAlign: 'right' }}>$290,000</div>
                            <div style={{ background: 'var(--bg-card-hover)', color: 'var(--text-main)', padding: '4px', textAlign: 'right' }}>$185,000</div>

                            {/* Total */}
                            <div style={{ background: 'var(--bg-card-hover)', color: 'var(--text-muted)', padding: '4px', textAlign: 'center' }}>4</div>
                            <div style={{ background: 'var(--bg-card-hover)', color: 'var(--text-main)', padding: '4px', fontWeight: 'bold' }}>Grand Total</div>
                            <div style={{ background: 'var(--bg-card-hover)', color: 'var(--text-main)', padding: '4px', fontWeight: 'bold', textAlign: 'right' }}>54</div>
                            <div style={{ background: 'var(--bg-card-hover)', color: 'var(--text-main)', padding: '4px', fontWeight: 'bold', textAlign: 'right' }}>$817,600</div>
                            <div style={{ background: 'var(--bg-card-hover)', color: 'var(--text-main)', padding: '4px', fontWeight: 'bold', textAlign: 'right' }}>$516,300</div>
                          </div>
                        </div>
                        <span style={{ fontSize: '0.68rem', color: 'var(--text-muted)', lineHeight: '1.4' }}>
                          ℹ️ <strong>Excel Pivot Table:</strong> Contains pre-aggregated yearly totals. Ingestion agent identified and skipped this sheet for claim-level extraction to avoid double-counting transactions.
                        </span>
                      </div>
                    );
                  } else {
                    return (
                      <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                        <div style={{ border: '1px solid var(--border-color)', padding: '12px', borderRadius: '6px', background: 'var(--bg-main)', maxHeight: '150px', overflowY: 'auto' }}>
                          <div style={{ fontSize: '0.72rem', fontWeight: 700, color: 'var(--text-muted)', display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '8px' }}>
                            <LucideIcons.Info size={14} /> EXCLUDED FROM EXTRACTION (INSTRUCTIONS & DOCUMENTATION)
                          </div>
                          <div style={{ fontSize: '0.75rem', color: 'var(--text-main)', display: 'flex', flexDirection: 'column', gap: '6px', lineHeight: '1.4' }}>
                            <div><strong>1. Scope of Data:</strong> Transactions reflect claims registered under commercial packages between 2022 and 2024.</div>
                            <div><strong>2. Column Guidelines:</strong> Columns must map to standard identifiers. `Claim Number` (Col A), `Loss Date` (Col B), `Paid Amount` (Col D).</div>
                            <div><strong>3. Carrier Contact:</strong> For format discrepancies, reach out to the carrier support desk.</div>
                          </div>
                        </div>
                        <span style={{ fontSize: '0.68rem', color: 'var(--text-muted)', lineHeight: '1.4' }}>
                          ℹ️ <strong>User Guide Tab:</strong> Instructions and documentation content. Skipped by the extraction workflow router since it does not contain claim transaction records.
                        </span>
                      </div>
                    );
                  }
                })()}

                {/* Excel Workbook Tabs Bar */}
                <div style={{ display: 'flex', border: '1px solid var(--border-color)', borderRadius: '6px', background: 'var(--bg-main)', overflow: 'hidden', marginTop: '12px' }}>
                  {[
                    { name: 'Claims Data', status: 'parsed' },
                    { name: 'Summary Pivot', status: 'ignored' },
                    { name: 'User Guide', status: 'skipped' }
                  ].map((tab) => {
                    const isActive = activeSheetTab === tab.name;
                    const dotColor = tab.status === 'parsed' ? 'var(--status-green)' : (tab.status === 'ignored' ? 'var(--status-yellow)' : 'var(--status-grey)');
                    return (
                      <button
                        key={tab.name}
                        onClick={() => setActiveSheetTab(tab.name)}
                        style={{
                          flex: 1,
                          padding: '8px 10px',
                          fontSize: '0.72rem',
                          fontWeight: 600,
                          background: isActive ? 'var(--bg-card-hover)' : 'transparent',
                          color: isActive ? 'var(--text-main)' : 'var(--text-muted)',
                          borderRight: '1px solid var(--border-color)',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          gap: '6px',
                          cursor: 'pointer',
                          transition: 'all 0.2s',
                          borderBottom: isActive ? '2px solid var(--accent-color)' : 'none'
                        }}
                      >
                        <span style={{ width: '6px', height: '6px', borderRadius: '50%', background: dotColor }} />
                        {tab.name}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          ) : (
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', flex: 1, color: 'var(--text-muted)', fontSize: '0.9rem' }}>
              No Excel or CSV spreadsheets uploaded in this batch.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}


// STEP 4: UNIFIED CLAIMS OUTPUT
export function ExtractionView({ backendResult, fileStats, isRolledUp, onRunRollup, cacheProgress, logs, isProcessing, isStep4Completed }) {
  const [page, setPage] = useState(0);
  const itemsPerPage = 6;

  if (!fileStats || fileStats.total === 0) {
    return <AwaitingUploadView />;
  }

  if (cacheProgress !== null) {
    return <LoadingScreen message="Retrieving cached claims extraction..." progress={cacheProgress} />;
  }

  if (!isStep4Completed) {
    return (
      <div style={{ display: 'flex', flexDirection: 'column', height: '100%', animation: 'fadeIn 0.5s ease-out' }}>
        <div className="section-title">
          <LucideIcons.Wand2 color="var(--accent-color)" /> Step 4: Extracted Claims File
        </div>
        <p className="section-subtitle">
          Flat list of claims extracted from PDF documents, DOCX vectors, and Excel spreadsheets.
        </p>
        <ConsoleTerminal title="claims-extractor.sh" logs={logs || []} isProcessing={isProcessing} />
      </div>
    );
  }

  const dataToUse = backendResult?.rawRows || [];
  const totalPages = Math.ceil(dataToUse.length / itemsPerPage);
  const currentItems = dataToUse.slice(page * itemsPerPage, (page + 1) * itemsPerPage);
  const columns = dataToUse.length > 0 ? Object.keys(dataToUse[0]) : [];

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', animation: 'fadeIn 0.5s ease-out' }}>
      <div>
        <div className="section-title">
          <LucideIcons.Wand2 color="var(--accent-color)" /> Step 4: Extracted Claims File
        </div>
        <p className="section-subtitle">
          Flat list of claims extracted from PDF documents, DOCX vectors, and Excel spreadsheets.
        </p>
      </div>

      <div className="glass-panel" style={{ marginTop: '16px', display: 'flex', flexDirection: 'column', flex: 1, overflow: 'hidden' }}>
        <div style={{ flex: 1, overflowX: 'auto', overflowY: 'auto', width: '100%' }}>
          <table className="data-table" style={{ whiteSpace: 'nowrap', minWidth: 'max-content' }}>
            <thead>
              <tr>
                {columns.map(key => (
                  <th key={key}>{key.replace(/_/g, ' ').toUpperCase()}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {currentItems.map((c, i) => (
                <tr key={i}>
                  {columns.map((key, j) => {
                    const isStrong = ['claim_id', 'claim_number', 'total_incurred', 'incurred'].includes(key);
                    const isGreen = ['total_paid', 'paid'].includes(key);
                    return (
                      <td key={j} style={{ 
                        fontWeight: isStrong ? 600 : 'normal',
                        color: isGreen ? 'var(--status-green)' : 'inherit'
                      }}>
                        {c[key] !== undefined && c[key] !== null ? String(c[key]) : ''}
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {totalPages > 1 && (
          <div style={{ padding: '12px 20px', display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '16px', borderTop: '1px solid var(--border-color)', background: 'var(--bg-card-hover)', flexShrink: 0 }}>
            <button className="btn-secondary" disabled={page === 0} onClick={() => setPage(p => p - 1)} style={{ padding: '4px 12px' }}>Previous</button>
            <span style={{ fontSize: '0.85rem', color: 'var(--text-muted)' }}>Page {page + 1} of {totalPages}</span>
            <button className="btn-secondary" disabled={page === totalPages - 1} onClick={() => setPage(p => p + 1)} style={{ padding: '4px 12px' }}>Next</button>
          </div>
        )}
      </div>
    </div>
  );
}

// STEP 5: ROLLUP & FINAL EXPORT VIEW
export function RollupView({ backendResult, fileStats, cacheProgress, isRolledUp, onRunRollup, onRollupComplete }) {
  const [toastMessage, setToastMessage] = useState(null);
  const [isExporting, setIsExporting] = useState(false);

  const [localLogs, setLocalLogs] = useState([]);
  const [logIndex, setLogIndex] = useState(0);

  const [page, setPage] = useState(0);
  const itemsPerPage = 6;

  const rollupLogMessages = [
    "Initializing Claimant Rollup Agent...",
    "Loading extracted claims database...",
    "Running name-normalization & fuzzy string matching models...",
    "Fuzzy-merging variations: 'John Doe', 'JOHN DOE', 'John A. Doe'...",
    "Grouping claims by Claimant identity & policy period...",
    "Aggregating financials (paid, reserve, incurred totals)...",
    "Resolving 2 Line of Business classification conflicts...",
    "Generating LOB summary and year-wise breakdown matrix...",
    "Packaging final deliverables (CSV export & Master Excel package)...",
    "Rollup completed successfully. Ready for download."
  ];

  // Simulating Rollup Agent logs
  React.useEffect(() => {
    if (isRolledUp !== 'processing') return;

    setLocalLogs([]);
    setLogIndex(0);

    const timer = setInterval(() => {
      setLogIndex(prevIndex => {
        if (prevIndex < rollupLogMessages.length) {
          const newMsg = rollupLogMessages[prevIndex];
          setLocalLogs(prev => [
            ...prev,
            {
              id: Math.random().toString(36).substring(7),
              time: new Date().toLocaleTimeString([], { hour12: false }),
              text: newMsg,
              type: 'info'
            }
          ]);
          return prevIndex + 1;
        } else {
          clearInterval(timer);
          // Complete rollup!
          onRollupComplete();
          return prevIndex;
        }
      });
    }, 400); // 400ms per log entry (4.0s total)

    return () => clearInterval(timer);
  }, [isRolledUp]);

  if (!fileStats || fileStats.total === 0) {
    return <AwaitingUploadView />;
  }

  if (cacheProgress !== null) {
    return <LoadingScreen message="Retrieving cached rollup and analysis dashboard..." progress={cacheProgress} />;
  }

  // If rollup is in progress
  if (isRolledUp === 'processing') {
    return (
      <div style={{ display: 'flex', flexDirection: 'column', height: '100%', animation: 'fadeIn 0.5s ease-out' }}>
        <div className="section-title">
          <LucideIcons.Layers color="var(--accent-color)" /> Step 5: Rollup & Export
        </div>
        <p className="section-subtitle">
          The Rollup Agent is consolidating and grouping claims across all carriers and lines of business.
        </p>
        <ConsoleTerminal title="rollup-agent.sh" logs={localLogs} isProcessing={true} />
      </div>
    );
  }

  // If completed but backendResult is not fully loaded (precautionary)
  if (!backendResult) {
    return <LoadingScreen message="Rollup Agent completing consolidation..." />;
  }

  const dataToUse = backendResult?.rollupRows || [];
  const totalPages = Math.ceil(dataToUse.length / itemsPerPage);
  const currentItems = dataToUse.slice(page * itemsPerPage, (page + 1) * itemsPerPage);
  const columns = dataToUse.length > 0 ? Object.keys(dataToUse[0]) : [];

  const showToast = (msg) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleDownloadCSV = async () => {
    setIsExporting(true);
    try {
      const response = await fetch('http://localhost:8000/api/download/rollup-csv');
      if (!response.ok) throw new Error("Failed to fetch Rollup CSV");
      const csvText = await response.text();
      const blob = new Blob([csvText], { type: 'text/csv' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `sample_Rolled_up_claims.csv`;
      a.click();
      URL.revokeObjectURL(url);
      showToast(`Downloaded Rollup CSV successfully`);
    } catch (e) {
      console.error(e);
      alert("Failed to download Rollup CSV from backend.");
    }
    setIsExporting(false);
  };

  const handleExportExcel = async () => {
    setIsExporting(true);
    try {
      const response = await fetch('http://localhost:8000/api/download/rollup-csv');
      if (!response.ok) throw new Error("Failed to fetch Rollup CSV");
      const csvText = await response.text();
      const wb = XLSX.read(csvText, { type: 'string' });
      const jsonData = XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]]);
      
      const newWb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(newWb, XLSX.utils.json_to_sheet(jsonData), "ROLLED_UP_CLAIMS");
      
      XLSX.writeFile(newWb, "loss_run_rollup_package.xlsx");
      showToast('Exported Rollup Excel package successfully');
    } catch (e) {
      console.error(e);
      alert("Failed to download spreadsheet from backend.");
    }
    setIsExporting(false);
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', position: 'relative', animation: 'fadeIn 0.5s ease-out' }}>
      <div className="section-title">
        <LucideIcons.Layers color="var(--accent-color)" /> Step 5: Rollup & Export
      </div>
      <p className="section-subtitle">
        Consolidated claimant portfolios compiled by the Rollup Agent (`sample_Rolled_up_claims.csv`).
      </p>

      {toastMessage && (
        <div style={{
          position: 'absolute', top: '0', right: '0', background: 'var(--status-green)', color: 'var(--bg-main)',
          padding: '8px 16px', borderRadius: '6px', fontSize: '0.85rem', display: 'flex', alignItems: 'center', gap: '6px',
          zIndex: 100, boxShadow: '0 4px 12px rgba(16, 185, 129, 0.3)', fontWeight: 600
        }}>
          <LucideIcons.CheckCircle2 size={16} /> {toastMessage}
        </div>
      )}

      {/* Full-width scrollable table for Rollup CSV */}
      <div className="glass-panel" style={{ marginTop: '16px', display: 'flex', flexDirection: 'column', flex: 1, overflow: 'hidden' }}>
        <div style={{ flex: 1, overflowX: 'auto', overflowY: 'auto', width: '100%' }}>
          <table className="data-table" style={{ whiteSpace: 'nowrap', minWidth: 'max-content' }}>
            <thead>
              <tr>
                {columns.map(key => (
                  <th key={key}>{key.replace(/_/g, ' ').toUpperCase()}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {currentItems.map((c, i) => (
                <tr key={i}>
                  {columns.map((key, j) => {
                    const isStrong = ['roll_no', 'claim_id', 'claim_number', 'total_incurred', 'incurred'].includes(key);
                    const isGreen = ['total_paid', 'paid'].includes(key);
                    return (
                      <td key={j} style={{ 
                        fontWeight: isStrong ? 600 : 'normal',
                        color: isGreen ? 'var(--status-green)' : 'inherit'
                      }}>
                        {c[key] !== undefined && c[key] !== null ? String(c[key]) : ''}
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {totalPages > 1 && (
          <div style={{ padding: '12px 20px', display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '16px', borderTop: '1px solid var(--border-color)', background: 'var(--bg-card-hover)', flexShrink: 0 }}>
            <button className="btn-secondary" disabled={page === 0} onClick={() => setPage(p => p - 1)} style={{ padding: '4px 12px' }}>Previous</button>
            <span style={{ fontSize: '0.85rem', color: 'var(--text-muted)' }}>Page {page + 1} of {totalPages}</span>
            <button className="btn-secondary" disabled={page === totalPages - 1} onClick={() => setPage(p => p + 1)} style={{ padding: '4px 12px' }}>Next</button>
          </div>
        )}
      </div>

      {/* Actions & Export Panel */}
      <div className="glass-panel" style={{ padding: '16px', display: 'flex', gap: '12px', marginTop: '16px', flexShrink: 0, justifyContent: 'flex-end' }}>
        <button className="btn-secondary" style={{ padding: '10px 20px', fontSize: '0.85rem', display: 'flex', alignItems: 'center', gap: '6px' }} onClick={handleDownloadCSV} disabled={isExporting}>
          <LucideIcons.FileDown size={16} /> Download Rollup CSV
        </button>
        <button className="btn-primary" style={{ padding: '10px 20px', fontSize: '0.85rem', display: 'flex', alignItems: 'center', gap: '6px' }} onClick={handleExportExcel} disabled={isExporting}>
          <LucideIcons.FileSpreadsheet size={16} /> Export Master Excel
        </button>
      </div>
    </div>
  );
}
