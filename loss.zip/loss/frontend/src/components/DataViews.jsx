import React, { useState } from 'react';
import * as LucideIcons from 'lucide-react';
import * as XLSX from 'xlsx';

export function LoadingScreen({ message, progress }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', alignItems: 'center', justifyContent: 'center', gap: '20px' }}>
      <LucideIcons.Loader2 size={48} className="spin-loader" color="var(--accent-color)" />
      <div style={{ textAlign: 'center' }}>
        <h3 style={{ color: 'var(--text-main)', margin: '0 0 8px 0', fontSize: '1.1rem' }}>{message}</h3>
        {progress !== undefined && progress !== null && (
          <div style={{ width: '280px', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '8px', margin: '12px auto 0 auto' }}>
            <div style={{ width: '100%', height: '6px', background: 'var(--border-color)', borderRadius: '3px', overflow: 'hidden' }}>
              <div style={{ width: `${progress}%`, height: '100%', background: 'var(--accent-color)', borderRadius: '3px', transition: 'width 0.1s ease-out' }} />
            </div>
            <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)', fontWeight: 600 }}>{progress}% Completed</span>
          </div>
        )}
      </div>
    </div>
  );
}

export function AwaitingUploadView() {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', alignItems: 'center', justifyContent: 'center', color: 'var(--text-muted)' }}>
      <LucideIcons.UploadCloud size={48} style={{ marginBottom: '16px', color: 'var(--accent-color)', opacity: 0.8 }} />
      <h3 style={{ color: 'var(--text-main)', fontSize: '1.1rem', margin: 0 }}>Awaiting Loss Run Upload</h3>
      <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)', marginTop: '8px' }}>Please upload loss run documents in Step 1 to begin processing.</p>
    </div>
  );
}

export function ConsoleTerminal({ title, logs, isProcessing }) {
  const terminalEndRef = React.useRef(null);

  React.useEffect(() => {
    if (terminalEndRef.current) {
      terminalEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [logs]);

  return (
    <div style={{
      display: 'flex',
      flexDirection: 'column',
      background: '#0a0a0a',
      borderRadius: '8px',
      border: '1px solid var(--border-color)',
      boxShadow: '0 8px 24px rgba(0,0,0,0.5)',
      fontFamily: '"Courier New", Courier, monospace',
      height: '350px',
      overflow: 'hidden',
      marginTop: '16px',
      borderLeft: '4px solid var(--accent-color)'
    }}>
      {/* Terminal Title Bar */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '10px 16px',
        background: '#121212',
        borderBottom: '1px solid #222',
        userSelect: 'none',
        flexShrink: 0
      }}>
        <div style={{ display: 'flex', gap: '6px' }}>
          <span style={{ width: '12px', height: '12px', borderRadius: '50%', background: '#ff5f56', display: 'inline-block' }} />
          <span style={{ width: '12px', height: '12px', borderRadius: '50%', background: '#ffbd2e', display: 'inline-block' }} />
          <span style={{ width: '12px', height: '12px', borderRadius: '50%', background: '#27c93f', display: 'inline-block' }} />
        </div>
        <span style={{ fontSize: '0.75rem', color: '#888', fontWeight: 600 }}>{title || 'agent-pipeline.sh'}</span>
        <div style={{ width: '40px' }} />
      </div>

      {/* Terminal Content */}
      <div style={{
        flex: 1,
        padding: '16px',
        overflowY: 'auto',
        color: '#10b981',
        fontSize: '0.8rem',
        lineHeight: '1.5',
        display: 'flex',
        flexDirection: 'column',
        gap: '6px'
      }}>
        {logs.map((log, idx) => (
          <div key={log.id || idx} style={{ display: 'flex', gap: '10px', animation: 'fadeInLog 0.2s ease-out' }}>
            <span style={{ color: '#888', flexShrink: 0 }}>[{log.time || 'INFO'}]</span>
            <span style={{ color: log.type === 'warning' ? 'var(--status-yellow)' : '#10b981', wordBreak: 'break-all' }}>
              {log.text}
            </span>
          </div>
        ))}

        {isProcessing && (
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginTop: '4px' }}>
            <span style={{ color: '#888' }}>&gt;</span>
            <span style={{ color: 'var(--accent-color)', fontWeight: 600 }}>Running agent workflow...</span>
            <span className="blinking-cursor" style={{ width: '8px', height: '15px', background: 'var(--accent-color)', display: 'inline-block' }} />
          </div>
        )}

        {!isProcessing && logs.length > 0 && (
          <div style={{ color: 'var(--status-green)', fontWeight: 600, marginTop: '8px' }}>
            [pipeline] All tasks completed successfully. Ready to view.
          </div>
        )}

        <div ref={terminalEndRef} />
      </div>

      <style dangerouslySetInnerHTML={{__html: `
        @keyframes fadeInLog {
          from { opacity: 0; transform: translateX(-4px); }
          to { opacity: 1; transform: translateX(0); }
        }
        .blinking-cursor {
          animation: blink 1s step-end infinite;
        }
        @keyframes blink {
          from, to { background-color: transparent }
          50% { background-color: var(--accent-color) }
        }
      `}} />
    </div>
  );
}

// STEP 2: LOSS RUN VERIFICATION VIEW
export function VerificationView({ backendResult, fileStats, cacheProgress, logs, isProcessing, isStep2Completed }) {
  const [selectedFile, setSelectedFile] = useState(null);

  if (!fileStats || fileStats.total === 0) {
    return <AwaitingUploadView />;
  }

  if (cacheProgress !== null) {
    return <LoadingScreen message="Retrieving cached verification reports..." progress={cacheProgress} />;
  }

  if (!isStep2Completed) {
    return (
      <div style={{ display: 'flex', flexDirection: 'column', height: '100%', animation: 'fadeIn 0.5s ease-out' }}>
        <div className="section-title">
          <LucideIcons.ShieldCheck color="var(--accent-color)" /> Step 2: Loss Run Verification
        </div>
        <p className="section-subtitle">
          Intake Agent scan complete. The Loss Run Detection Agent is scanning and classifying documents.
        </p>
        <ConsoleTerminal title="verification-agent.sh" logs={logs || []} isProcessing={isProcessing} />
      </div>
    );
  }

  // Use uploaded files list and enrich with detection details from the backend
  const files = fileStats?.uploadedList && fileStats.uploadedList.length > 0 
    ? fileStats.uploadedList.map(f => {
        const detectInfo = backendResult?.detection?.[f.name];
        if (detectInfo) {
          return {
            ...f,
            valid: detectInfo.is_loss_run,
            reason: detectInfo.is_loss_run 
              ? `Verified by Loss Run Detection Agent using ${detectInfo.method} analysis. Verified Loss Run Report.`
              : `Classified as non-loss run and excluded. Excluded Document.`
          };
        }
        return f;
      })
    : [];

  const negativeCheck = backendResult?.validationChecks?.find(c => c.check === 'Negative Value Check');
  const hasNegativeFinancials = negativeCheck ? negativeCheck.status === 'warning' : false;

  const activeFile = files.find(f => f.name === selectedFile?.name) || files[0];

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', animation: 'fadeIn 0.5s ease-out' }}>
      <div className="section-title">
        <LucideIcons.ShieldCheck color="var(--accent-color)" /> Step 2: Loss Run Verification
      </div>
      <p className="section-subtitle">
        Intake Agent scan complete. The Loss Run Detection Agent has verified document types and filtered out invalid files.
      </p>

      {/* Metric Cards Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '16px', marginTop: '16px', marginBottom: '8px' }}>
        {/* Card 1: Files Processed */}
        <div className="glass-panel" style={{ padding: '12px 16px', display: 'flex', alignItems: 'center', gap: '12px', background: 'var(--bg-card-hover)' }}>
          <div style={{ padding: '8px', borderRadius: '8px', background: 'rgba(234, 88, 12, 0.1)', color: 'var(--accent-color)' }}>
            <LucideIcons.FileCheck size={18} />
          </div>
          <div>
            <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.5px' }}>Files Processed</div>
            <div style={{ fontSize: '1.25rem', fontWeight: 700, color: 'var(--text-main)', marginTop: '2px' }}>{backendResult?.filesUploaded || 0}</div>
          </div>
        </div>

        {/* Card 2: Duplicates Found */}
        <div className="glass-panel" style={{ padding: '12px 16px', display: 'flex', alignItems: 'center', gap: '12px', background: 'var(--bg-card-hover)' }}>
          <div style={{ padding: '8px', borderRadius: '8px', background: backendResult?.duplicatesFound > 0 ? 'rgba(245, 158, 11, 0.1)' : 'rgba(16, 185, 129, 0.1)', color: backendResult?.duplicatesFound > 0 ? 'var(--status-yellow)' : 'var(--status-green)' }}>
            <LucideIcons.Copy size={18} />
          </div>
          <div>
            <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.5px' }}>Duplicates Found</div>
            <div style={{ fontSize: '1.25rem', fontWeight: 700, color: backendResult?.duplicatesFound > 0 ? 'var(--status-yellow)' : 'var(--text-main)', marginTop: '2px' }}>
              {backendResult?.duplicatesFound || 0}
            </div>
          </div>
        </div>

        {/* Card 3: Negative Financials */}
        <div className="glass-panel" style={{ padding: '12px 16px', display: 'flex', alignItems: 'center', gap: '12px', background: 'var(--bg-card-hover)' }}>
          <div style={{ padding: '8px', borderRadius: '8px', background: hasNegativeFinancials ? 'rgba(239, 68, 68, 0.1)' : 'rgba(16, 185, 129, 0.1)', color: hasNegativeFinancials ? 'var(--status-red)' : 'var(--status-green)' }}>
            <LucideIcons.AlertTriangle size={18} />
          </div>
          <div>
            <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.5px' }}>Negative Financials</div>
            <div style={{ fontSize: '1.1rem', fontWeight: 700, color: hasNegativeFinancials ? 'var(--status-red)' : 'var(--status-green)', marginTop: '2px' }}>
              {hasNegativeFinancials ? 'Detected' : 'None Detected'}
            </div>
          </div>
        </div>

        {/* Card 4: AI Confidence */}
        <div className="glass-panel" style={{ padding: '12px 16px', display: 'flex', alignItems: 'center', gap: '12px', background: 'var(--bg-card-hover)' }}>
          <div style={{ padding: '8px', borderRadius: '8px', background: 'rgba(16, 185, 129, 0.1)', color: 'var(--status-green)' }}>
            <LucideIcons.Sparkles size={18} />
          </div>
          <div>
            <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.5px' }}>AI Confidence</div>
            <div style={{ fontSize: '1.25rem', fontWeight: 700, color: 'var(--status-green)', marginTop: '2px' }}>{backendResult?.aiConfidence || 'N/A'}</div>
          </div>
        </div>
      </div>

      <div style={{ display: 'flex', gap: '24px', flex: 1, overflow: 'hidden', marginTop: '16px' }}>
        {/* Left list of files */}
        <div style={{ width: '45%', display: 'flex', flexDirection: 'column', gap: '10px', overflowY: 'auto', paddingRight: '8px' }}>
          {files.map((file, i) => (
            <button
              key={i}
              onClick={() => setSelectedFile(file)}
              className="glass-panel"
              style={{
                padding: '16px',
                textAlign: 'left',
                border: activeFile?.name === file.name ? '1px solid var(--accent-color)' : '1px solid var(--border-color)',
                background: activeFile?.name === file.name ? 'rgba(234, 88, 12, 0.05)' : 'var(--bg-card-hover)',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                transition: 'all 0.2s'
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                <span className={`file-ext-badge badge-${file.type}`} style={{ fontSize: '0.7rem' }}>{file.type}</span>
                <div>
                  <div style={{ color: 'var(--text-main)', fontSize: '0.85rem', fontWeight: 600 }}>{file.name}</div>
                  <div style={{ color: 'var(--text-muted)', fontSize: '0.75rem', marginTop: '2px' }}>{file.size}</div>
                </div>
              </div>
              <div>
                {file.valid ? (
                  <div style={{ color: 'var(--status-green)', display: 'flex', alignItems: 'center', gap: '4px', fontSize: '0.8rem', fontWeight: 600 }}>
                    <LucideIcons.CheckCircle2 size={16} /> VERIFIED
                  </div>
                ) : (
                  <div style={{ color: 'var(--status-red)', display: 'flex', alignItems: 'center', gap: '4px', fontSize: '0.8rem', fontWeight: 600 }}>
                    <LucideIcons.XCircle size={16} /> EXCLUDED
                  </div>
                )}
              </div>
            </button>
          ))}
        </div>

        {/* Right Verification Details */}
        <div className="glass-panel" style={{ flex: 1, padding: '24px', display: 'flex', flexDirection: 'column', background: 'var(--bg-card-hover)', overflowY: 'auto' }}>
          {activeFile ? (
            <>
              <div style={{ borderBottom: '1px solid var(--border-color)', paddingBottom: '16px', marginBottom: '16px' }}>
                <span className={`file-ext-badge badge-${activeFile.type}`} style={{ marginBottom: '8px' }}>{activeFile.type.toUpperCase()} File</span>
                <h3 style={{ fontSize: '1.25rem', color: 'var(--text-main)', margin: '4px 0' }}>{activeFile.name}</h3>
                <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>Size: {activeFile.size}</span>
              </div>

              <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: '16px' }}>
                <div>
                  <h4 style={{ fontSize: '0.9rem', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: '8px' }}>Verification Result</h4>
                  <div style={{ 
                    padding: '12px 16px', 
                    borderRadius: '6px', 
                    background: activeFile.valid ? 'rgba(16, 185, 129, 0.08)' : 'rgba(239, 68, 68, 0.08)',
                    color: activeFile.valid ? 'var(--status-green)' : 'var(--status-red)',
                    border: `1px solid ${activeFile.valid ? 'var(--status-green)44' : 'var(--status-red)44'}`,
                    fontWeight: 600,
                    fontSize: '0.9rem',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px'
                  }}>
                    {activeFile.valid ? <LucideIcons.ShieldCheck size={18} /> : <LucideIcons.AlertTriangle size={18} />}
                    {activeFile.valid ? 'Verified Loss Run Report Document' : 'Non-Loss Run Invoice Excluded'}
                  </div>
                </div>

                <div>
                  <h4 style={{ fontSize: '0.9rem', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: '8px' }}>LLM Classification Audit</h4>
                  <p style={{ color: 'var(--text-main)', fontSize: '0.95rem', lineHeight: '1.5', background: 'rgba(255,255,255,0.02)', padding: '16px', borderRadius: '8px', border: '1px solid var(--border-color)' }}>
                    {activeFile.reason}
                  </p>
                </div>
              </div>
            </>
          ) : (
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100%', color: 'var(--text-muted)' }}>
              Select a file on the left to view verification audit logs
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
// STEP 3: OCR & PREPROCESSING (DIVIDED VIEW)
export function PreprocessingView({ backendResult, fileStats, cacheProgress, logs, isProcessing, isStep3Completed }) {
  if (!fileStats || fileStats.total === 0) {
    return <AwaitingUploadView />;
  }

  if (cacheProgress !== null) {
    return <LoadingScreen message="Retrieving cached preprocessing metrics..." progress={cacheProgress} />;
  }

  if (!isStep3Completed) {
    return (
      <div style={{ display: 'flex', flexDirection: 'column', height: '100%', animation: 'fadeIn 0.5s ease-out' }}>
        <div className="section-title">
          <LucideIcons.Network color="var(--accent-color)" /> Step 3: OCR & Pre-processing
        </div>
        <p className="section-subtitle">
          Document parsing and spreadsheet ingestion suites processing files concurrently.
        </p>
        <ConsoleTerminal title="preprocessing-ocr.sh" logs={logs || []} isProcessing={isProcessing} />
      </div>
    );
  }

  const docFiles = fileStats?.uploadedList?.filter(f => f.type === 'pdf' || f.type === 'docx') || [];
  const sheetFiles = fileStats?.uploadedList?.filter(f => f.type === 'xlsx' || f.type === 'csv') || [];

  const hasDocFiles = docFiles.length > 0;
  const hasExcelFiles = sheetFiles.length > 0;

  // Generate dynamic logs based on real files
  const docLogs = [];
  docFiles.forEach((f, index) => {
    const timeOffset = index * 2;
    docLogs.push(`[12:04:${10 + timeOffset}] [docx_conv] Processing document vector structure for: ${f.name}`);
    docLogs.push(`[12:04:${12 + timeOffset}] [pdf_img] Splitting ${f.name} pages at 150 DPI resolution.`);
    docLogs.push(`[12:04:${15 + timeOffset}] [img_txt] Layout-aware OCR completed. Found textual tables.`);
  });

  const sheetLogs = [];
  sheetFiles.forEach((f, index) => {
    const timeOffset = index * 3;
    sheetLogs.push(`[12:04:${10 + timeOffset}] [excel_detect] Scanning grid coordinate dimensions for: ${f.name}`);
    sheetLogs.push(`[12:04:${13 + timeOffset}] [excel_detect] Found claim table block coordinates (A1:G${backendResult?.rawRows?.length || 10})`);
    sheetLogs.push(`[12:04:${16 + timeOffset}] [excel_extract] Parsed table records and cast values to JSON.`);
  });

  // Extract first 2 rows of claims data for the cell matrix mapping visualizer
  const matrixRows = backendResult?.matrixRows || backendResult?.rawRows?.slice(0, 2) || [];

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', animation: 'fadeIn 0.5s ease-out' }}>
      <div className="section-title">
        <LucideIcons.Network color="var(--accent-color)" /> Step 3: OCR & Pre-processing
      </div>
      <p className="section-subtitle">
        Document parsing and spreadsheet ingestion suites processing files concurrently.
      </p>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '24px', flex: 1, overflow: 'hidden', marginTop: '16px' }}>
        
        {/* Left Side: Document Stream (PDF/Word) */}
        <div className="glass-panel" style={{ padding: '20px', display: 'flex', flexDirection: 'column', overflow: 'hidden', borderLeft: '3px solid rgba(239, 68, 68, 0.4)' }}>
          <h4 style={{ color: 'var(--text-main)', fontSize: '1.05rem', borderBottom: '1px solid var(--border-color)', paddingBottom: '10px', marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }}>
            <LucideIcons.FileText color="#ef4444" size={18} /> Document Parsing Suite (PDF & Word)
          </h4>
          
          {hasDocFiles ? (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '16px', flex: 1, overflowY: 'auto', paddingRight: '4px' }}>
              <div style={{ background: 'var(--bg-card-hover)', padding: '12px', borderRadius: '6px', border: '1px solid var(--border-color)' }}>
                <div style={{ fontSize: '0.85rem', fontWeight: 600, color: 'var(--text-main)', marginBottom: '8px' }}>Active Conversion Logs</div>
                <div style={{ fontFamily: 'monospace', fontSize: '0.75rem', color: '#10b981', display: 'flex', flexDirection: 'column', gap: '4px' }}>
                  {docLogs.map((log, idx) => (
                    <div key={idx}>{log}</div>
                  ))}
                </div>
              </div>

              {/* Page rotation preview mockups */}
              <div>
                <div style={{ fontSize: '0.85rem', fontWeight: 600, color: 'var(--text-main)', marginBottom: '10px' }}>Ingested document layouts</div>
                <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap' }}>
                  {docFiles.map((doc, idx) => (
                    <div key={idx} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '6px' }}>
                      <div style={{ width: '90px', height: '110px', background: 'var(--bg-card-hover)', border: '1px solid var(--status-green)', borderRadius: '4px', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', color: 'var(--status-green)', position: 'relative', padding: '8px' }}>
                        <LucideIcons.FileText size={24} />
                        <span style={{ fontSize: '0.6rem', fontWeight: 600, color: 'var(--text-main)', marginTop: '8px', textAlign: 'center', width: '100%', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{doc.name}</span>
                        <span style={{ position: 'absolute', bottom: '4px', fontSize: '0.55rem', fontWeight: 600, color: 'var(--text-muted)' }}>{doc.type.toUpperCase()}</span>
                      </div>
                      <span style={{ fontSize: '0.7rem', color: 'var(--status-green)', fontWeight: 600 }}>[✓] Parsed</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', flex: 1, color: 'var(--text-muted)', fontSize: '0.9rem' }}>
              No PDF or Word documents uploaded in this batch.
            </div>
          )}
        </div>

        {/* Right Side: Spreadsheet Stream (Excel/CSV) */}
        <div className="glass-panel" style={{ padding: '20px', display: 'flex', flexDirection: 'column', overflow: 'hidden', borderLeft: '3px solid rgba(16, 185, 129, 0.4)' }}>
          <h4 style={{ color: 'var(--text-main)', fontSize: '1.05rem', borderBottom: '1px solid var(--border-color)', paddingBottom: '10px', marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }}>
            <LucideIcons.FileSpreadsheet color="#10b981" size={18} /> Spreadsheet Ingestion Suite (Excel & CSV)
          </h4>

          {hasExcelFiles ? (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '16px', flex: 1, overflowY: 'auto', paddingRight: '4px' }}>
              <div style={{ background: 'var(--bg-card-hover)', padding: '12px', borderRadius: '6px', border: '1px solid var(--border-color)' }}>
                <div style={{ fontSize: '0.85rem', fontWeight: 600, color: 'var(--text-main)', marginBottom: '8px' }}>Active Extraction Logs</div>
                <div style={{ fontFamily: 'monospace', fontSize: '0.75rem', color: '#10b981', display: 'flex', flexDirection: 'column', gap: '4px' }}>
                  {sheetLogs.map((log, idx) => (
                    <div key={idx}>{log}</div>
                  ))}
                </div>
              </div>

              {/* Sheet block visualizer */}
              <div>
                <div style={{ fontSize: '0.85rem', fontWeight: 600, color: 'var(--text-main)', marginBottom: '10px' }}>Spreadsheet cell grid matrix mapping</div>
                <div style={{ border: '1px dashed var(--border-color)', padding: '12px', borderRadius: '6px', background: 'var(--bg-card-hover)' }}>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: '4px', textAlign: 'center', fontFamily: 'monospace', fontSize: '0.7rem' }}>
                    <div style={{ border: '1px solid var(--border-color)', padding: '4px', background: 'var(--bg-main)' }}>ClaimID</div>
                    <div style={{ border: '1px solid var(--border-color)', padding: '4px', background: 'var(--bg-main)' }}>Date</div>
                    <div style={{ border: '1px solid var(--border-color)', padding: '4px', background: 'var(--bg-main)' }}>Claimant</div>
                    <div style={{ border: '1px solid var(--border-color)', padding: '4px', background: 'var(--bg-main)' }}>Paid</div>
                    <div style={{ border: '1px solid var(--border-color)', padding: '4px', background: 'var(--bg-main)' }}>Reserve</div>

                    {matrixRows.length > 0 ? (
                      matrixRows.map((row, idx) => (
                        <React.Fragment key={idx}>
                          <div style={{ border: '1px solid var(--status-green)', padding: '4px', color: 'var(--status-green)', background: 'rgba(16,185,129,0.05)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                            {row.claim_id || row.claim_number || 'N/A'}
                          </div>
                          <div style={{ border: '1px solid var(--status-green)', padding: '4px', color: 'var(--status-green)', background: 'rgba(16,185,129,0.05)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                            {row.accident_date || row.loss_date || 'N/A'}
                          </div>
                          <div style={{ border: '1px solid var(--status-green)', padding: '4px', color: 'var(--status-green)', background: 'rgba(16,185,129,0.05)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                            {row.claimant || 'N/A'}
                          </div>
                          <div style={{ border: '1px solid var(--status-green)', padding: '4px', color: 'var(--status-green)', background: 'rgba(16,185,129,0.05)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                            {row.total_paid || row.paid || '$0'}
                          </div>
                          <div style={{ border: '1px solid var(--status-green)', padding: '4px', color: 'var(--status-green)', background: 'rgba(16,185,129,0.05)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                            {row.total_reserve || row.reserve || '$0'}
                          </div>
                        </React.Fragment>
                      ))
                    ) : (
                      <div style={{ gridColumn: 'span 5', padding: '12px', color: 'var(--text-muted)' }}>
                        Ingesting raw claims records...
                      </div>
                    )}
                  </div>
                  <div style={{ fontSize: '0.65rem', color: 'var(--text-muted)', marginTop: '8px', textAlign: 'right' }}>
                    Found: {sheetFiles.length} table block{sheetFiles.length > 1 ? 's' : ''}. Extracted: {backendResult?.claimsExtracted || 0} records
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', flex: 1, color: 'var(--text-muted)', fontSize: '0.9rem' }}>
              No Excel or CSV spreadsheets uploaded in this batch.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}


// STEP 4: UNIFIED CLAIMS OUTPUT
export function ExtractionView({ backendResult, fileStats, isRolledUp, onRunRollup, cacheProgress, logs, isProcessing, isStep4Completed }) {
  const [page, setPage] = useState(0);
  const itemsPerPage = 6;

  if (!fileStats || fileStats.total === 0) {
    return <AwaitingUploadView />;
  }

  if (cacheProgress !== null) {
    return <LoadingScreen message="Retrieving cached claims extraction..." progress={cacheProgress} />;
  }

  if (!isStep4Completed) {
    return (
      <div style={{ display: 'flex', flexDirection: 'column', height: '100%', animation: 'fadeIn 0.5s ease-out' }}>
        <div className="section-title">
          <LucideIcons.Wand2 color="var(--accent-color)" /> Step 4: Extracted Claims File
        </div>
        <p className="section-subtitle">
          Flat list of claims extracted from PDF documents, DOCX vectors, and Excel spreadsheets.
        </p>
        <ConsoleTerminal title="claims-extractor.sh" logs={logs || []} isProcessing={isProcessing} />
      </div>
    );
  }

  const dataToUse = backendResult?.rawRows || [];
  const totalPages = Math.ceil(dataToUse.length / itemsPerPage);
  const currentItems = dataToUse.slice(page * itemsPerPage, (page + 1) * itemsPerPage);

  const [isRunningRollup, setIsRunningRollup] = useState(false);

  const handleTriggerRollup = () => {
    setIsRunningRollup(true);
    setTimeout(() => {
      onRunRollup();
      setIsRunningRollup(false);
    }, 1800);
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', animation: 'fadeIn 0.5s ease-out' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <div className="section-title">
            <LucideIcons.Wand2 color="var(--accent-color)" /> Step 4: Extracted Claims File
          </div>
          <p className="section-subtitle">
            Flat list of claims extracted from PDF documents, DOCX vectors, and Excel spreadsheets.
          </p>
        </div>
        <div>
          <button
            onClick={handleTriggerRollup}
            disabled={isRolledUp === 'completed' || isRolledUp === 'processing' || isRolledUp === true || isRunningRollup}
            className="btn-primary"
            style={{
              padding: '10px 20px',
              fontSize: '0.9rem',
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              background: (isRolledUp === 'completed' || isRolledUp === true) ? 'var(--status-green)' : 'var(--accent-color)',
              borderColor: (isRolledUp === 'completed' || isRolledUp === true) ? 'var(--status-green)' : 'var(--accent-color)',
              opacity: (isRolledUp === 'completed' || isRolledUp === 'processing' || isRolledUp === true || isRunningRollup) && !(isRolledUp === 'completed' || isRolledUp === true) ? 0.6 : 1
            }}
          >
            {isRunningRollup || isRolledUp === 'processing' ? (
              <>
                <LucideIcons.Loader2 size={16} className="spin-loader" /> Running Rollup Agent...
              </>
            ) : (isRolledUp === 'completed' || isRolledUp === true) ? (
              <>
                <LucideIcons.Check size={16} /> Claimant Rollup Done
              </>
            ) : (
              <>
                <LucideIcons.GitMerge size={16} /> Run Claimant Rollup
              </>
            )}
          </button>
        </div>
      </div>

      <div className="glass-panel" style={{ marginTop: '16px', display: 'flex', flexDirection: 'column', flex: 1, overflow: 'hidden' }}>
        <div style={{ flex: 1, overflowY: 'auto' }}>
          <table className="data-table">
            <thead>
              <tr>
                <th>Claim ID</th>
                <th>Accident Date</th>
                <th>Claimant</th>
                <th>LOB</th>
                <th>State</th>
                <th>Paid</th>
                <th>Reserve</th>
                <th>Incurred</th>
              </tr>
            </thead>
            <tbody>
              {currentItems.map((c, i) => (
                <tr key={i}>
                  <td style={{ fontWeight: 600 }}>{c.claim_id || c.claim_number}</td>
                  <td>{c.accident_date || c.loss_date}</td>
                  <td>{c.claimant}</td>
                  <td>{c.line_of_business || c.lob}</td>
                  <td>{c.accident_state || c.state}</td>
                  <td style={{ color: 'var(--status-green)' }}>{c.total_paid || c.paid}</td>
                  <td>{c.total_reserve || c.reserve}</td>
                  <td style={{ fontWeight: 600 }}>{c.total_incurred || c.incurred}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {totalPages > 1 && (
          <div style={{ padding: '12px 20px', display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '16px', borderTop: '1px solid var(--border-color)', background: 'var(--bg-card-hover)', flexShrink: 0 }}>
            <button className="btn-secondary" disabled={page === 0} onClick={() => setPage(p => p - 1)} style={{ padding: '4px 12px' }}>Previous</button>
            <span style={{ fontSize: '0.85rem', color: 'var(--text-muted)' }}>Page {page + 1} of {totalPages}</span>
            <button className="btn-secondary" disabled={page === totalPages - 1} onClick={() => setPage(p => p + 1)} style={{ padding: '4px 12px' }}>Next</button>
          </div>
        )}
      </div>
    </div>
  );
}

// STEP 5: ROLLUP & FINAL EXPORT VIEW
export function RollupView({ backendResult, fileStats, cacheProgress, isRolledUp, onRunRollup, onRollupComplete }) {
  const [showYearModal, setShowYearModal] = useState(false);
  const [toastMessage, setToastMessage] = useState(null);
  const [isExporting, setIsExporting] = useState(false);

  const [localLogs, setLocalLogs] = useState([]);
  const [logIndex, setLogIndex] = useState(0);

  const rollupLogMessages = [
    "Initializing Claimant Rollup Agent...",
    "Loading extracted claims database...",
    "Running name-normalization & fuzzy string matching models...",
    "Fuzzy-merging variations: 'John Doe', 'JOHN DOE', 'John A. Doe'...",
    "Grouping claims by Claimant identity & policy period...",
    "Aggregating financials (paid, reserve, incurred totals)...",
    "Resolving 2 Line of Business classification conflicts...",
    "Generating LOB summary and year-wise breakdown matrix...",
    "Packaging final deliverables (CSV export & Master Excel package)...",
    "Rollup completed successfully. Ready for download."
  ];

  // Simulating Rollup Agent logs
  React.useEffect(() => {
    if (isRolledUp !== 'processing') return;

    setLocalLogs([]);
    setLogIndex(0);

    const timer = setInterval(() => {
      setLogIndex(prevIndex => {
        if (prevIndex < rollupLogMessages.length) {
          const newMsg = rollupLogMessages[prevIndex];
          setLocalLogs(prev => [
            ...prev,
            {
              id: Math.random().toString(36).substring(7),
              time: new Date().toLocaleTimeString([], { hour12: false }),
              text: newMsg,
              type: 'info'
            }
          ]);
          return prevIndex + 1;
        } else {
          clearInterval(timer);
          // Complete rollup!
          onRollupComplete();
          return prevIndex;
        }
      });
    }, 400); // 400ms per log entry (4.0s total)

    return () => clearInterval(timer);
  }, [isRolledUp]);

  if (!fileStats || fileStats.total === 0) {
    return <AwaitingUploadView />;
  }

  if (cacheProgress !== null) {
    return <LoadingScreen message="Retrieving cached rollup and analysis dashboard..." progress={cacheProgress} />;
  }

  // If we haven't run rollup yet
  if (!isRolledUp || isRolledUp === 'idle') {
    return (
      <div style={{ display: 'flex', flexDirection: 'column', height: '100%', position: 'relative', animation: 'fadeIn 0.5s ease-out' }}>
        <div className="section-title">
          <LucideIcons.Layers color="var(--accent-color)" /> Step 5: Rollup & Export Dashboard
        </div>
        <p className="section-subtitle">
          Aggregate extracted claims by unique claimant entities and generate analytical financial portfolios.
        </p>
        
        <div className="glass-panel" style={{ padding: '60px 40px', textAlign: 'center', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: '20px', marginTop: '16px', borderStyle: 'dashed' }}>
          <div style={{ padding: '16px', borderRadius: '50%', background: 'rgba(234, 88, 12, 0.1)', color: 'var(--accent-color)', width: 'fit-content' }}>
            <LucideIcons.Layers size={32} />
          </div>
          <div>
            <h3 style={{ color: 'var(--text-main)', fontSize: '1.25rem', marginBottom: '8px' }}>Awaiting Rollup Agent Execution</h3>
            <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem', maxWidth: '500px', margin: '0 auto' }}>
              The claims must be consolidated and grouped by claimant names using our fuzzy-matching AI models before the export package can be generated.
            </p>
          </div>
          
          <button
            onClick={onRunRollup}
            className="btn-primary"
            style={{
              padding: '12px 24px',
              fontSize: '1rem',
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              marginTop: '12px',
              boxShadow: '0 4px 14px rgba(234, 88, 12, 0.3)'
            }}
          >
            <LucideIcons.PlayCircle size={18} /> Execute Claimant Rollup Agent
          </button>
        </div>
      </div>
    );
  }

  // If rollup is in progress
  if (isRolledUp === 'processing') {
    return (
      <div style={{ display: 'flex', flexDirection: 'column', height: '100%', animation: 'fadeIn 0.5s ease-out' }}>
        <div className="section-title">
          <LucideIcons.Layers color="var(--accent-color)" /> Step 5: Rollup & Export Dashboard
        </div>
        <p className="section-subtitle">
          The Rollup Agent is consolidating and grouping claims across all carriers and lines of business.
        </p>
        <ConsoleTerminal title="rollup-agent.sh" logs={localLogs} isProcessing={true} />
      </div>
    );
  }

  // If completed but backendResult is not fully loaded (precautionary)
  if (!backendResult) {
    return <LoadingScreen message="Rollup Agent completing consolidation..." />;
  }

  const totalClaims = backendResult?.claimsExtracted || 0;
  const byLob = backendResult?.lobSummary || [];
  const years = backendResult?.yearWiseSummary || [];
  const rawRows = backendResult?.rawRows || [];

  const totalPaid = years.length > 0 ? years.reduce((sum, y) => sum + parseFloat(y.totalPaid.replace(/[^0-9.-]+/g,"")), 0) : 0;
  const totalIncurred = years.length > 0 ? years.reduce((sum, y) => sum + parseFloat(y.totalIncurred.replace(/[^0-9.-]+/g,"")), 0) : 0;
  const totalReserve = years.length > 0 ? years.reduce((sum, y) => sum + parseFloat(y.totalReserve.replace(/[^0-9.-]+/g,"")), 0) : 0;

  const formatCurrency = (val) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(val);

  const showToast = (msg) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const fetchFullCSV = async () => {
    try {
      const response = await fetch('http://localhost:8000/api/download/csv');
      if (!response.ok) throw new Error("Failed to fetch CSV");
      return await response.text();
    } catch (e) {
      console.error(e);
      return null;
    }
  };

  const handleDownloadCSV = async () => {
    setIsExporting(true);
    const csvText = await fetchFullCSV();
    if (csvText) {
      const blob = new Blob([csvText], { type: 'text/csv' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `loss_run_claims.csv`;
      a.click();
      URL.revokeObjectURL(url);
      showToast(`Downloaded CSV report successfully`);
    } else {
      alert("Failed to download CSV from backend.");
    }
    setIsExporting(false);
  };

  const handleExportExcel = async () => {
    setIsExporting(true);
    const csvText = await fetchFullCSV();
    if (csvText) {
      const wb = XLSX.read(csvText, { type: 'string' });
      const jsonData = XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]]);
      
      const newWb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(newWb, XLSX.utils.json_to_sheet(jsonData), "CLAIMS");
      XLSX.utils.book_append_sheet(newWb, XLSX.utils.json_to_sheet(byLob), "LOB_SUMMARY");
      
      XLSX.writeFile(newWb, "loss_run_master_package.xlsx");
      showToast('Exported Master Excel package successfully');
    } else {
      alert("Failed to download spreadsheet from backend.");
    }
    setIsExporting(false);
  };

  // Fuzzy-grouped claimant records
  // We aggregate rawRows by claimant matching rollup key logic
  const rollupGroups = React.useMemo(() => {
    const groups = {};
    rawRows.forEach(row => {
      const name = row.claimant || '';
      // Simple fuzzy key: titlecase + strip whitespace
      const cleanKey = name.toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 8);
      if (!groups[cleanKey]) {
        groups[cleanKey] = {
          name: name,
          namesMerged: new Set([name]),
          count: 0,
          incurred: 0,
          paid: 0,
          claims: []
        };
      }
      const p = parseFloat(String(row.total_paid || row.paid || 0).replace(/[^0-9.-]+/g,"")) || 0;
      const inc = parseFloat(String(row.total_incurred || row.incurred || 0).replace(/[^0-9.-]+/g,"")) || 0;
      
      groups[cleanKey].namesMerged.add(name);
      groups[cleanKey].count++;
      groups[cleanKey].incurred += inc;
      groups[cleanKey].paid += p;
      groups[cleanKey].claims.push(row);
    });

    return Object.values(groups).sort((a,b) => b.incurred - a.incurred);
  }, [rawRows]);


  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', position: 'relative', animation: 'fadeIn 0.5s ease-out' }}>
      <div className="section-title">
        <LucideIcons.Layers color="var(--accent-color)" /> Step 5: Rollup & Export Dashboard
      </div>

      {toastMessage && (
        <div style={{
          position: 'absolute', top: '0', right: '0', background: 'var(--status-green)', color: 'var(--bg-main)',
          padding: '8px 16px', borderRadius: '6px', fontSize: '0.85rem', display: 'flex', alignItems: 'center', gap: '6px',
          zIndex: 100, boxShadow: '0 4px 12px rgba(16, 185, 129, 0.3)', fontWeight: 600
        }}>
          <LucideIcons.CheckCircle2 size={16} /> {toastMessage}
        </div>
      )}

      {/* Main Grid View */}
      <div style={{ display: 'grid', gridTemplateColumns: '3fr 4fr', gap: '16px', marginTop: '12px', flex: 1, overflow: 'hidden' }}>
        
        {/* Left Side: Consolidated Claimant Rollup List */}
        <div className="glass-panel" style={{ padding: '16px', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
          <h4 style={{ color: 'var(--text-main)', fontSize: '0.9rem', fontWeight: 600, borderBottom: '1px solid var(--border-color)', paddingBottom: '10px', marginBottom: '12px', display: 'flex', alignItems: 'center', gap: '8px' }}>
            <LucideIcons.Users color="var(--accent-color)" size={16} /> Consolidated Claimant Rollups
          </h4>

          <div style={{ flex: 1, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: '8px', paddingRight: '4px' }}>
            {rollupGroups.map((g, idx) => (
              <div key={idx} style={{ border: '1px solid var(--border-color)', borderRadius: '6px', padding: '10px', background: 'var(--bg-card-hover)' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <div>
                    <span style={{ fontSize: '0.85rem', fontWeight: 600, color: 'var(--text-main)' }}>{g.name}</span>
                    {g.namesMerged.size > 1 && (
                      <span style={{ fontSize: '0.65rem', color: 'var(--status-yellow)', background: 'rgba(245, 158, 11, 0.1)', padding: '2px 6px', borderRadius: '4px', marginLeft: '8px', fontWeight: 600 }}>
                        Fuzzy Merged ({g.namesMerged.size})
                      </span>
                    )}
                  </div>
                  <div style={{ fontSize: '0.85rem', fontWeight: 600, color: 'var(--status-green)' }}>
                    {formatCurrency(g.incurred)}
                  </div>
                </div>

                <div style={{ display: 'flex', justifyItems: 'space-between', gap: '16px', fontSize: '0.7rem', color: 'var(--text-muted)', marginTop: '6px', borderTop: '1px solid var(--border-color)11', paddingTop: '4px' }}>
                  <span>Claims: {g.count}</span>
                  <span>Paid: {formatCurrency(g.paid)}</span>
                  <span>Names: {Array.from(g.namesMerged).join(', ')}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right Side: Visuals & Export */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '16px', overflow: 'hidden' }}>
          
          {/* Executive Stats Card */}
          <div className="glass-panel" style={{ padding: '20px', display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', background: 'linear-gradient(135deg, rgba(234, 88, 12, 0.04) 0%, rgba(11, 11, 11, 0) 100%)', flexShrink: 0 }}>
            <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '1px' }}>Total Grouped Losses</span>
            <h2 style={{ fontSize: '2rem', color: 'var(--status-green)', margin: '4px 0' }}>{formatCurrency(totalIncurred)}</h2>
            <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Across {totalClaims} Claims</span>
          </div>

          {/* LOB Distribution Progress Bars (Visual Chart) */}
          <div className="glass-panel" style={{ padding: '16px', flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
            <h4 style={{ color: 'var(--text-main)', fontSize: '0.85rem', borderBottom: '1px solid var(--border-color)', paddingBottom: '8px', marginBottom: '10px', display: 'flex', alignItems: 'center', gap: '6px' }}>
              <LucideIcons.BarChart3 size={16} color="var(--accent-color)" /> Loss Distribution by Line of Business
            </h4>
            <div style={{ flex: 1, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: '10px', paddingRight: '4px' }}>
              {byLob.map((lob, i) => {
                const incNum = parseFloat(lob.incurred.replace(/[^0-9.-]+/g,"")) || 0;
                const pct = totalIncurred > 0 ? Math.round((incNum / totalIncurred) * 100) : 0;
                return (
                  <div key={i} style={{ fontSize: '0.75rem' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4px' }}>
                      <span style={{ fontWeight: 600, color: 'var(--text-main)' }}>{lob.lob} ({pct}%)</span>
                      <span style={{ color: 'var(--text-muted)' }}>{lob.incurred}</span>
                    </div>
                    <div style={{ width: '100%', height: '8px', background: 'var(--border-color)', borderRadius: '4px', overflow: 'hidden' }}>
                      <div style={{ width: `${pct}%`, height: '100%', background: 'var(--accent-color)', borderRadius: '4px' }} />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Actions & Export Panel */}
          <div className="glass-panel" style={{ padding: '16px', display: 'flex', gap: '12px', flexShrink: 0 }}>
            <button className="btn-secondary" style={{ flex: 1, padding: '10px', fontSize: '0.8rem', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px' }} onClick={() => setShowYearModal(true)}>
              <LucideIcons.Calendar size={14} /> Year-wise Summary
            </button>
            <button className="btn-secondary" style={{ flex: 1, padding: '10px', fontSize: '0.8rem', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px' }} onClick={handleDownloadCSV} disabled={isExporting}>
              <LucideIcons.FileDown size={14} /> Download CSV
            </button>
            <button className="btn-primary" style={{ flex: 1, padding: '10px', fontSize: '0.8rem', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px' }} onClick={handleExportExcel} disabled={isExporting}>
              <LucideIcons.FileSpreadsheet size={14} /> Master Excel
            </button>
          </div>
        </div>
      </div>

      {showYearModal && (
        <div style={{ position: 'absolute', top: '-24px', left: '-40px', right: '-40px', bottom: '-20px', background: 'rgba(0,0,0,0.85)', backdropFilter: 'blur(4px)', display: 'flex', justifyContent: 'center', alignItems: 'center', zIndex: 100 }}>
          <div className="glass-panel" style={{ width: '80%', maxHeight: '80%', display: 'flex', flexDirection: 'column', background: 'var(--bg-main)', overflow: 'hidden' }}>
            <div style={{ padding: '20px', borderBottom: '1px solid var(--border-color)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <h3 style={{ display: 'flex', alignItems: 'center', gap: '8px', color: 'var(--text-main)', fontSize: '1.1rem' }}><LucideIcons.Calendar size={18} color="var(--accent-color)" /> Year-wise Breakdown</h3>
              <button onClick={() => setShowYearModal(false)} style={{ background: 'var(--bg-card-hover)', border: '1px solid var(--border-color)', borderRadius: '4px', padding: '4px', color: 'var(--text-muted)', cursor: 'pointer', display: 'flex', alignItems: 'center' }}><LucideIcons.X size={18} /></button>
            </div>
            <div style={{ padding: '20px', overflowY: 'auto' }}>
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Year</th><th>Claims</th><th>Paid</th><th>Reserve</th><th>Incurred</th>
                  </tr>
                </thead>
                <tbody>
                  {years.map((y, i) => (
                    <tr key={i} style={{ fontWeight: y.year === 'Total' ? 'bold' : 'normal', background: y.year === 'Total' ? 'var(--bg-card-hover)' : 'transparent' }}>
                      <td>{y.year}</td><td>{y.claimCount.toLocaleString()}</td><td>{y.totalPaid}</td><td>{y.totalReserve}</td><td>{y.totalIncurred}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
