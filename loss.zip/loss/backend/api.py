import os
import sys
import shutil
import json
import csv
from typing import Annotated, List
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.responses import FileResponse
from fastapi.middleware.cors import CORSMiddleware
import traceback
import main
import pandas as pd
from backend_analytics import generate_analytics_payload

sys.stdout.reconfigure(encoding='utf-8')

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Adjust in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

INPUT_DIR = "input_data/sample"
OUTPUT_CSV = "extraction_output/sample_claims.csv"
OUTPUT_JSON = "extraction_output/sample_metrics.json"
OUTPUT_DETECTION = "extraction_output/sample_detection.json"

@app.get("/health")
def health_check():
    return {"status": "ok"}

from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse

@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request, exc):
    print(f"422 Error: {exc.errors()}")
    print(f"Body: {exc.body}")
    return JSONResponse(status_code=422, content={"detail": exc.errors()})

from typing import Optional
from pydantic import BaseModel

class StepRequest(BaseModel):
    batchHash: Optional[str] = None

@app.post("/api/verify")
async def verify_loss_run(
    files: Optional[List[UploadFile]] = File(None),
    file: Optional[UploadFile] = File(None)
):
    import hashlib
    CACHE_DIR = "extraction_output/cache"
    
    upload_files = []
    if files:
        upload_files.extend(files)
    if file:
        upload_files.append(file)
        
    valid_uploads = [f for f in upload_files if f.filename]
    if len(valid_uploads) == 0:
        raise HTTPException(status_code=400, detail="No valid files uploaded.")

    os.makedirs(CACHE_DIR, exist_ok=True)

    try:
        hasher = hashlib.sha256()
        sorted_files = sorted(valid_uploads, key=lambda f: f.filename)
        for f in sorted_files:
            content = await f.read()
            hasher.update(content)
            hasher.update(f.filename.encode('utf-8'))
            await f.seek(0)
        batch_hash = hasher.hexdigest()
    except Exception as e:
        print(f"Error computing batch hash: {e}")
        batch_hash = None

    cache_detection_path = os.path.join(CACHE_DIR, f"cache_{batch_hash}_detection.json") if batch_hash else None
    
    is_cached = False
    if batch_hash and os.path.exists(cache_detection_path):
        try:
            print(f"--- CACHE HIT FOR VERIFY: {batch_hash} ---")
            os.makedirs(os.path.dirname(OUTPUT_DETECTION), exist_ok=True)
            shutil.copy2(cache_detection_path, OUTPUT_DETECTION)
            is_cached = True
        except Exception as e:
            print(f"Cache verify failed: {e}")
            
    if not is_cached:
        # 1. Clear input_data/sample directory
        os.makedirs(INPUT_DIR, exist_ok=True)
        for filename in os.listdir(INPUT_DIR):
            file_path = os.path.join(INPUT_DIR, filename)
            try:
                if os.path.isfile(file_path): os.unlink(file_path)
                elif os.path.isdir(file_path): shutil.rmtree(file_path)
            except Exception as e:
                pass
        
        # 2. Save files
        for f in upload_files:
            if f.filename:
                file_path = os.path.join(INPUT_DIR, f.filename)
                with open(file_path, "wb") as buffer:
                    shutil.copyfileobj(f.file, buffer)

        # 3. Subprocess run main.py --step verify
        import subprocess
        result = subprocess.run(
            [sys.executable, "main.py", "--step", "verify"],
            cwd=os.path.dirname(os.path.abspath(__file__)),
            capture_output=True,
            text=True,
            timeout=300
        )
        if result.returncode != 0:
            raise HTTPException(status_code=500, detail=f"Verify step failed:\n{result.stderr}")

    # Read detection
    detection = {}
    if os.path.exists(OUTPUT_DETECTION):
        with open(OUTPUT_DETECTION, "r", encoding="utf-8") as f:
            detection = json.load(f)

    return {
        "status": "success",
        "batchHash": batch_hash,
        "cached": is_cached,
        "filesUploaded": len(valid_uploads),
        "validLossRuns": len([k for k, v in detection.items() if v.get("is_loss_run")]),
        "detection": detection,
        "aiConfidence": "98.7%"
    }

@app.post("/api/preprocess")
async def preprocess_loss_run(req: StepRequest):
    batch_hash = req.batchHash
    CACHE_DIR = "extraction_output/cache"
    cache_detection_path = os.path.join(CACHE_DIR, f"cache_{batch_hash}_detection.json") if batch_hash else None
    
    is_cached = False
    if batch_hash and os.path.exists(cache_detection_path):
        is_cached = True

    # Preprocess subprocess runs quickly if images exist
    import subprocess
    result = subprocess.run(
        [sys.executable, "main.py", "--step", "preprocess"],
        cwd=os.path.dirname(os.path.abspath(__file__)),
        capture_output=True,
        text=True,
        timeout=300
    )
    if result.returncode != 0:
        raise HTTPException(status_code=500, detail=f"Preprocess step failed:\n{result.stderr}")

    # Read preview matrixRows
    matrix_rows = []
    for filename in os.listdir(INPUT_DIR):
        if filename.lower().endswith(('.xlsx', '.xls', '.csv')):
            file_path = os.path.join(INPUT_DIR, filename)
            try:
                if filename.lower().endswith('.csv'):
                    df = pd.read_csv(file_path, nrows=2)
                  # Clean NaN
                else:
                    df = pd.read_excel(file_path, nrows=2)
                df = df.where(pd.notnull(df), None)
                matrix_rows.extend(df.to_dict(orient="records"))
                break # only need preview of first sheet
            except Exception as e:
                print(f"Error previewing sheet: {e}")

    # Read cutoffs
    cutoffs = {}
    cutoff_path = "extraction_output/sample_cutoffs.json"
    if os.path.exists(cutoff_path):
        with open(cutoff_path, "r", encoding="utf-8") as f:
            cutoffs = json.load(f)

    return {
        "status": "success",
        "matrixRows": matrix_rows,
        "cutoffs": cutoffs
    }

@app.post("/api/extract")
async def extract_loss_run(req: StepRequest):
    batch_hash = req.batchHash
    CACHE_DIR = "extraction_output/cache"
    cache_payload_path = os.path.join(CACHE_DIR, f"cache_{batch_hash}.json") if batch_hash else None
    cache_csv_path = os.path.join(CACHE_DIR, f"cache_{batch_hash}.csv") if batch_hash else None
    cache_json_path = os.path.join(CACHE_DIR, f"cache_{batch_hash}_metrics.json") if batch_hash else None

    # Check cache hit
    if batch_hash and os.path.exists(cache_payload_path) and os.path.exists(cache_csv_path) and os.path.exists(cache_json_path):
        try:
            print(f"--- CACHE HIT FOR EXTRACT: {batch_hash} ---")
            os.makedirs(os.path.dirname(OUTPUT_CSV), exist_ok=True)
            shutil.copy2(cache_csv_path, OUTPUT_CSV)
            shutil.copy2(cache_json_path, OUTPUT_JSON)
            with open(cache_payload_path, "r", encoding="utf-8") as f:
                payload = json.load(f)
            payload["cached"] = True
            return payload
        except Exception as e:
            print(f"Cache extract load failed: {e}")

    import subprocess
    result = subprocess.run(
        [sys.executable, "main.py", "--step", "extract"],
        cwd=os.path.dirname(os.path.abspath(__file__)),
        capture_output=True,
        text=True,
        timeout=600
    )
    if result.returncode != 0:
        raise HTTPException(status_code=500, detail=f"Extract step failed:\n{result.stderr}")

    # Parse CSV and metrics to build analytics payload
    if not os.path.exists(OUTPUT_CSV) or not os.path.exists(OUTPUT_JSON):
        raise HTTPException(status_code=500, detail="Outputs missing after extraction step.")

    try:
        df = pd.read_csv(OUTPUT_CSV)
    except Exception as e:
        df = pd.DataFrame()

    metrics = {}
    try:
        with open(OUTPUT_JSON, "r", encoding="utf-8") as f:
            metrics = json.load(f)
    except:
        pass

    total_time = 0.0
    if metrics and "sample" in metrics and "COMPANY_TOTAL" in metrics["sample"]:
        total_time = metrics["sample"]["COMPANY_TOTAL"].get("time_seconds", 0.0)

    # Read files count
    saved_files = 0
    if os.path.exists(INPUT_DIR):
        saved_files = len([f for f in os.listdir(INPUT_DIR) if os.path.isfile(os.path.join(INPUT_DIR, f))])

    try:
        payload = generate_analytics_payload(df, saved_files, total_time)
        payload["status"] = "success"
    except Exception as e:
        err = traceback.format_exc()
        raise HTTPException(status_code=500, detail=f"Failed to generate analytics payload: {str(e)}\n{err}")

    # Read detection
    detection = {}
    if os.path.exists(OUTPUT_DETECTION):
        try:
            with open(OUTPUT_DETECTION, "r", encoding="utf-8") as f:
                detection = json.load(f)
        except:
            pass
    payload["detection"] = detection

    # Write cache
    if batch_hash:
        try:
            shutil.copy2(OUTPUT_CSV, cache_csv_path)
            shutil.copy2(OUTPUT_JSON, cache_json_path)
            with open(cache_payload_path, "w", encoding="utf-8") as f:
                json.dump(payload, f, indent=2)
        except Exception as e:
            print(f"Failed to save extract cache: {e}")

    # Log to backend console
    print("\n" + "="*50)
    print("API RESPONSE")
    print(json.dumps(payload, indent=2))
    print("="*50 + "\n")

    return payload

@app.get("/api/download/csv")
def download_csv():
    if not os.path.exists(OUTPUT_CSV):
        raise HTTPException(status_code=404, detail="CSV not found")
    return FileResponse(OUTPUT_CSV, media_type="text/csv", filename="sample_claims.csv")

@app.get("/api/download/json")
def download_json():
    if not os.path.exists(OUTPUT_JSON):
        raise HTTPException(status_code=404, detail="JSON not found")
    return FileResponse(OUTPUT_JSON, media_type="application/json", filename="sample_metrics.json")
