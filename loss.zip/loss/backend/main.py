import os
import sys
import shutil
from docx_to_pdf import convert_docx_to_pdf
from detect_loss_runs import detect_loss_runs
from pdf_to_images import turn_pdf_to_images
from determine_pdf_cutoff import determine_page_cutoffs
from extract import extract_claims
from clean_extraction_output import process_claims_df
from detect_duplicates import detect_duplicate_claims_across_files
from metrics import save_metrics_json, reset_metrics

sys.stdout.reconfigure(encoding='utf-8')

def prepare_input_files(input_data_dir, output_data_dir, company_names):
    """
    Finds Excel, CSV, and PDF files in the input_data folder and copies them
    to the output_data folder under excel_sheets/, csvs/, and pdf folders
    as expected by the downstream detection and extraction steps.
    For PDFs, it creates the folder and extracts text to page_response.json.
    """
    import fitz # PyMuPDF
    import json
    from pdf_to_images import _safe_subfolder_name, MAX_WINDOWS_PATH, _as_extended_path
    
    for company in company_names:
        company_input_dir = os.path.join(input_data_dir, company)
        if not os.path.isdir(company_input_dir):
            continue
            
        company_output_dir = os.path.join(output_data_dir, company)
        excel_out_dir = os.path.join(company_output_dir, "excel_sheets")
        csv_out_dir = os.path.join(company_output_dir, "csvs")
        
        for root, _, files in os.walk(company_input_dir):
            for file in files:
                file_lower = file.lower()
                src_path = os.path.join(root, file)
                
                if file_lower.endswith((".xls", ".xlsx", ".xlsm", ".xlsb")):
                    os.makedirs(excel_out_dir, exist_ok=True)
                    shutil.copy2(src_path, os.path.join(excel_out_dir, file))
                    print(f"Copied Excel: {file} to output_data")
                elif file_lower.endswith(".csv"):
                    os.makedirs(csv_out_dir, exist_ok=True)
                    shutil.copy2(src_path, os.path.join(csv_out_dir, file))
                    print(f"Copied CSV: {file} to output_data")
                elif file_lower.endswith(".pdf"):
                    # Calculate safe subfolder name
                    base_path_len = len(os.path.abspath(company_output_dir))
                    max_image_filename = "image-page-999.jpg"
                    available_len = MAX_WINDOWS_PATH - base_path_len - len(os.path.sep) - len(max_image_filename)
                    available_len = max(16, available_len)
                    
                    subfolder_name = _safe_subfolder_name(file, max_len=available_len)
                    output_dir = os.path.join(company_output_dir, subfolder_name)
                    
                    if len(os.path.abspath(output_dir)) > MAX_WINDOWS_PATH:
                        import hashlib
                        digest = hashlib.md5(file.encode("utf-8")).hexdigest()[:16]
                        subfolder_name = f"file_{digest}"
                        output_dir = os.path.join(company_output_dir, subfolder_name)
                        
                    os.makedirs(output_dir, exist_ok=True)
                    print(f"Created PDF folder: {subfolder_name}")
                    
                    # Extract page text to page_response.json
                    pdf_abs = os.path.abspath(src_path)
                    pdf_path_for_open = _as_extended_path(pdf_abs)
                    try:
                        doc = fitz.open(pdf_path_for_open)
                        page_text_map = {}
                        for i, page in enumerate(doc):
                            page_text_map[str(i+1)] = page.get_text()
                        
                        json_path = os.path.join(output_dir, "page_response.json")
                        with open(json_path, "w", encoding="utf-8") as f:
                            json.dump(page_text_map, f, indent=2)
                        print(f"Extracted PDF text to: {json_path}")
                        doc.close()
                    except Exception as e:
                        print(f"Failed to extract PDF text for {file}: {e}")

def main():
    import argparse
    import json
    
    parser = argparse.ArgumentParser()
    parser.add_argument("--step", type=str, choices=["verify", "preprocess", "extract", "all"], default="all")
    args = parser.parse_args()
    
    input_data_dir = "input_data"
    output_data_dir = "output_data"
    extraction_data_dir = "extraction_output"
    company_names = ["sample"]
    file_path_prefix = "sample_"
    
    detection_output_path = f"{extraction_data_dir}/{file_path_prefix}detection.json"
    cutoff_output_path = f"{extraction_data_dir}/{file_path_prefix}cutoffs.json"
    
    if args.step in ["verify", "all"]:
        reset_metrics()
        
        # 1. Convert Word (.docx) documents to PDF
        print("\nConverting DOCX to PDF....\n")
        convert_docx_to_pdf(input_data_dir, company_names)
        
        # 2. Copy and preprocess raw Excel/CSV/PDF files to output folders
        print("\nPreparing Excel, CSV and PDF files to output_data....\n")
        prepare_input_files(input_data_dir, output_data_dir, company_names)
        
        # 3. Detect which documents are loss runs
        print("\nDetecting which input files are loss runs....\n")
        is_file_loss_run_dict = detect_loss_runs(output_data_dir, company_names)
        
        # Save detection decision JSON
        os.makedirs(extraction_data_dir, exist_ok=True)
        serializable_detection = {}
        for (company, filename), val in is_file_loss_run_dict.items():
            serializable_detection[filename] = val
        with open(detection_output_path, "w", encoding="utf-8") as f:
            json.dump(serializable_detection, f, indent=2)
        print(f"Detection results saved to: {detection_output_path}")
        
    if args.step in ["preprocess", "all"]:
        # Reconstruct is_file_loss_run_dict
        is_file_loss_run_dict = {}
        if os.path.exists(detection_output_path):
            with open(detection_output_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                for filename, val in data.items():
                    is_file_loss_run_dict[("sample", filename)] = val
        
        # 4. Convert PDF pages to image sheets (handles rotation check)
        print("\nCreating images of each PDF page...")
        turn_pdf_to_images(company_names, input_data_dir, output_data_dir, is_file_loss_run_dict)
        
        # 5. Calculate page cutoff boundaries
        print("\nDetermining PDF page groupings based on context limits...")
        pages_to_join_dict = determine_page_cutoffs(output_data_dir, company_names, is_file_loss_run_dict)
        
        # Save cutoff dictionary
        os.makedirs(extraction_data_dir, exist_ok=True)
        serializable_cutoffs = {}
        for (company, pdf_name), val in pages_to_join_dict.items():
            serializable_cutoffs[pdf_name] = val
        with open(cutoff_output_path, "w", encoding="utf-8") as f:
            json.dump(serializable_cutoffs, f, indent=2)
        print(f"Page cutoffs saved to: {cutoff_output_path}")
        
    if args.step in ["extract", "all"]:
        # Reconstruct is_file_loss_run_dict
        is_file_loss_run_dict = {}
        if os.path.exists(detection_output_path):
            with open(detection_output_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                for filename, val in data.items():
                    is_file_loss_run_dict[("sample", filename)] = val
                    
        # Reconstruct pages_to_join_dict
        pages_to_join_dict = {}
        if os.path.exists(cutoff_output_path):
            with open(cutoff_output_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                for pdf_name, val in data.items():
                    pages_to_join_dict[("sample", pdf_name)] = val
                    
        # 6. Extract structured claims JSON
        print("\nBeginning Loss Run Extraction....\n")
        claims_df = extract_claims(output_data_dir, company_names, pages_to_join_dict, is_file_loss_run_dict)
        
        # 7. Clean and normalize the output DataFrame
        print("\n Cleaning Claims Dataframe and Implementing Logic")
        claims_df = process_claims_df(claims_df)
        
        # 9. Save CSV output
        os.makedirs(extraction_data_dir, exist_ok=True)
        claims_df.to_csv(f"{extraction_data_dir}/{file_path_prefix}claims.csv", index=False)
        print(f"\nFinal claims CSV saved to: {extraction_data_dir}/{file_path_prefix}claims.csv")
        
        # 10. Save metrics JSON
        metrics_output_path = f"{extraction_data_dir}/{file_path_prefix}metrics.json"
        save_metrics_json(metrics_output_path)
        print(f"Metrics saved to: {metrics_output_path}")

if __name__ == "__main__":
    main()
