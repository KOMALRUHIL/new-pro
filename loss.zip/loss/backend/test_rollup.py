import os
import pandas as pd
from post_process_rollup import run_rollup_post_processing

# Create mock claims data matching the schema
mock_claims = [
    {
        "claimant": "Suman Kumar",
        "driver": "Suman Kumar",
        "policy_number": "POL12345-A",
        "accident_date": "2024-03-12",
        "accident_state": "IL",
        "total_incurred": 12000.00,
        "total_paid": 8000.00,
        "incurred_alae": 500.00,
        "paid_alae": 300.00,
        "total_recoveries": 0.00,
        "status": "Closed",
        "claim_id": "CLM-001",
        "claim_description": "Left knee injury"
    },
    {
        "claimant": "Suman Kumar",
        "driver": "Suman Kumar",
        "policy_number": "POL12345-B",
        "accident_date": "2024-03-12",
        "accident_state": "IL",
        "total_incurred": 5000.00,
        "total_paid": 3000.00,
        "incurred_alae": 100.00,
        "paid_alae": 50.00,
        "total_recoveries": 0.00,
        "status": "Closed",
        "claim_id": "CLM-002",
        "claim_description": "Right elbow injury from same event"
    },
    {
        "claimant": "John Smith",
        "driver": "John Smith",
        "policy_number": "POL99999",
        "accident_date": "2024-05-15",
        "accident_state": "TX",
        "total_incurred": 45000.00,
        "total_paid": 25000.00,
        "incurred_alae": 1200.00,
        "paid_alae": 800.00,
        "total_recoveries": 1000.00,
        "status": "Open",
        "claim_id": "CLM-003",
        "claim_description": "Rear-end collision"
    }
]

df = pd.DataFrame(mock_claims)

# Ensure directories exist
os.makedirs("extraction_output", exist_ok=True)
input_file = "extraction_output/sample_claims.csv"
output_detailed = "extraction_output/sample_claims.csv"
output_rollup = "extraction_output/sample_Rolled_up_claims.csv"

# Write mock input
print(f"Saving mock data to {input_file}...")
df.to_csv(input_file, index=False)

# Run post processing
print("\nRunning post-processing...")
run_rollup_post_processing(input_file, output_detailed, output_rollup)

# Inspect outputs
print("\n=== Detailed Claims CSV (with roll_no) ===")
detailed_res = pd.read_csv(output_detailed)
print(detailed_res[["roll_no", "claimant", "accident_date", "total_incurred", "claim_id"]])

print("\n=== Rolled Up Claims CSV ===")
rollup_res = pd.read_csv(output_rollup)
print(rollup_res[["roll_no", "claimant", "accident_date", "total_incurred", "claim_id"]])
